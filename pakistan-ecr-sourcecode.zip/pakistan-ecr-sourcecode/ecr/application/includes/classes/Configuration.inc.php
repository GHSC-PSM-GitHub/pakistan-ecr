<?php

// enter db credentials here
 
?>