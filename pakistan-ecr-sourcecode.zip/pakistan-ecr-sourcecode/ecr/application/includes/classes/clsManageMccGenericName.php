<?php

/**
 * clsManageStatus
 * @package includes/class
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
class clsManageMccGenericName {
    //npkId
    var $m_npkId;
    //pk_id
    var $m_pk_id;
    //category_name
    var $m_generic_name;
    
    var $m_dosage_form;
    
    var $m_strength;
    
    var $m_volume;
    
    var $m_mcc_category_id;
/**
 * AddItemStatus
 * @return int
 */
    function AddMccList() {
        if ($this->m_generic_name == '') {
            $this->m_generic_name = 'NULL';
        }
        if ($this->m_mcc_category_id == '') {
            $this->m_mcc_category_id = 'NULL';
        }
        //add query
        $strSql = "INSERT INTO mcc_generic_name(generic_name,mcc_category_id,dosage_form,strength,volume) VALUES('" . $this->m_generic_name . "','" . $this->m_mcc_category_id . "','" . $this->m_dosage_form . "','" . $this->m_strength . "','" . $this->m_volume . "')";
//        echo $strSql;exit;
        //query result
        $rsSql = mysql_query($strSql) or die("Error AddItemStatus");
        if (mysql_insert_id() > 0) {
            return mysql_insert_id();
        } else {
            return 0;
        }
    }
/**
 * EditItemStatus
 * @return boolean
 */
    function EditMccList() {
        //edit query
        $strSql = "UPDATE mcc_generic_name SET pk_id=" . $this->m_npkId;

        $generic_name = ",generic_name='" . $this->m_generic_name . "'";
        if ($this->m_generic_name != '') {
            $strSql .=$generic_name;
        }

        $dosage_form= ",dosage_form='" . $this->m_dosage_form . "'";
        if ($this->m_dosage_form != '') {
            $strSql .=$dosage_form;
        }
        
        $strength = ",strength='" . $this->m_strength . "'";
        if ($this->m_strength != '') {
            $strSql .=$strength;
        }
        
        $volume = ",volume='" . $this->m_volume . "'";
        if ($this->m_volume != '') {
            $strSql .=$volume;
        }
        
        $mcc_category_id = ",mcc_category_id='" . $this->m_mcc_category_id . "'";
        if ($this->m_mcc_category_id != '') {
            $strSql .=$mcc_category_id;
        }
        
        $strSql .=" WHERE pk_id=" . $this->m_npkId;
        //query result
        $rsSql = mysql_query($strSql) or die("Error EditItemStatus");
        if (mysql_affected_rows()) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }
/**
 * DeleteItemStatus
 * @return boolean
 */
    function DeleteItemStatus() {
        //delete query
        $strSql = "DELETE FROM mcc_generic_name WHERE pk_id=" . $this->m_npkId;
        $rsSql = mysql_query($strSql) or die("Error DeleteItemStatus");
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
/**
 * GetAllItemStatus
 * @return boolean
 */
    function GetAllMccLists() {
        //select query
        $strSql = "SELECT
                        *
                        FROM
                        mcc_generic_name";

        //query result
        $rsSql = mysql_query($strSql) or die("Error GetAllMccLists");

        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }
/**
 * GetItemStatusById
 * @return boolean
 */
    function GetItemStatusById() {
        //select query
        $strSql = "
				SELECT
					*
					FROM
					mcc_generic_name
					WHERE mcc_generic_name.pk_id=" . $this->m_npkId;
        //query result
        $rsSql = mysql_query($strSql) or die("Error GetItemStatusById");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }

    function GetMccListStatusById() {
        //select query
        $strSql = "SELECT
                            *,
                            mcc_list_categories.category_name 
                    FROM
                            mcc_generic_name
                            INNER JOIN mcc_list_categories ON mcc_generic_name.mcc_category_id = mcc_list_categories.pk_id
                            WHERE mcc_generic_name.pk_id=" . $this->m_npkId;
        //query result
        $rsSql = mysql_query($strSql) or die("Error GetMccListStatusById");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }
}

?>
