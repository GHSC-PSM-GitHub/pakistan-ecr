<?php

/**
 * clsManageStatus
 * @package includes/class
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
class clsManageMccList {
    //npkId
    var $m_npkId;
    //pk_id
    var $m_pk_id;
    //category_name
    var $m_category_name;
/**
 * AddItemStatus
 * @return int
 */
    function AddMccList() {
        if ($this->m_category_name == '') {
            $this->m_category_name = 'NULL';
        }
        //add query
        $strSql = "INSERT INTO mcc_list_categories(category_name) VALUES('" . $this->m_category_name . "')";
        //query result
        $rsSql = mysql_query($strSql) or die("Error AddItemStatus");
        if (mysql_insert_id() > 0) {
            return mysql_insert_id();
        } else {
            return 0;
        }
    }
/**
 * EditItemStatus
 * @return boolean
 */
    function EditMccList() {
        //edit query
        $strSql = "UPDATE mcc_list_categories SET pk_id=" . $this->m_npkId;

        $category_name = ",category_name='" . $this->m_category_name . "'";
        if ($this->m_category_name != '') {
            $strSql .=$category_name;
        }

        $strSql .=" WHERE pk_id=" . $this->m_npkId;
        //query result
        $rsSql = mysql_query($strSql) or die("Error EditItemStatus");
        if (mysql_affected_rows()) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }
/**
 * DeleteItemStatus
 * @return boolean
 */
    function DeleteItemStatus() {
        //delete query
        $strSql = "DELETE FROM mcc_list_categories WHERE pk_id=" . $this->m_npkId;
        $rsSql = mysql_query($strSql) or die("Error DeleteItemStatus");
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
/**
 * GetAllItemStatus
 * @return boolean
 */
    function GetAllMccLists() {
        //select query
        $strSql = "SELECT
                        *
                        FROM
                        mcc_list_categories";

        //query result
        $rsSql = mysql_query($strSql) or die("Error GetAllMccLists");

        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }
/**
 * GetItemStatusById
 * @return boolean
 */
    function GetItemStatusById() {
        //select query
        $strSql = "
				SELECT
					mcc_list_categories.pk_id,
					mcc_list_categories.category_name
					FROM
					mcc_list_categories
					WHERE mcc_list_categories.pk_id=" . $this->m_npkId;
        //query result
        $rsSql = mysql_query($strSql) or die("Error GetItemStatusById");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }

    function GetMccListStatusById() {
        //select query
        $strSql = "
				SELECT
					*
					FROM
					mcc_list_categories
					WHERE pk_id=" . $this->m_npkId;
        //query result
        $rsSql = mysql_query($strSql) or die("Error GetMccListStatusById");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }
}

?>
