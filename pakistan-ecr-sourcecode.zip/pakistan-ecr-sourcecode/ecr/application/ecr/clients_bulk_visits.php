<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Clients with multiple visits recorded  ( Possible wrong entries ) To be verified by relevant persons </h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    


                                </form>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        
                                        $qry = "
                                         SELECT
	ecr_clients.pk_id, 
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.contact_number, 
	ecr_clients.cnic, 
	count(ecr_client_visits.pk_id) as total_visits
FROM
	ecr_clients
	INNER JOIN
	ecr_client_visits
	ON 
		ecr_clients.pk_id = ecr_client_visits.client_id
                
	INNER JOIN
	tbl_warehouse
	ON 
		ecr_client_visits.wh_id = tbl_warehouse.wh_id
		where 	tbl_warehouse.stkid = '".$_SESSION['user_stakeholder1']."'  and prov_id ='".$_SESSION['user_province1']."' 
		group by ecr_clients.pk_id
		having count(ecr_client_visits.pk_id) > 12
		order by count(ecr_client_visits.pk_id) desc
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
//                                        echo '<pre>';
//                                        print_r($data_arr);
//                                        echo '</pre>';    

                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                            echo '<tr>';
                                            echo '<td>#</td>';
                                            echo '<td>Serial Number</td>';
                                            echo '<td>Name</td>';
                                            echo '<td>F/H Name</td>';
                                            echo '<td>CNIC</td>';
                                            echo '<td>Contact</td>';
                                            echo '<td>No of Visits</td>';
                                            echo '<td>Action</td>';
                                            echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {
                                            
                                           
                                           
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['total_visits'] . '<span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['pk_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';
                                           
                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>