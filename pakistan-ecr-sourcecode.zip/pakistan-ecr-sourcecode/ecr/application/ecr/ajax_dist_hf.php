<?php
include("../includes/classes/AllClasses.php");
$stakeholder = $_POST['stk'];
$district = $_POST['dist'];

$prov_id = $_SESSION['user_province1'];
$hf_arr = array();
$qry = "SELECT 
                                                                tbl_warehouse.wh_id,tbl_warehouse.wh_name, 
                                                                tbl_locations.LocName as dist_name FROM
                                                            tbl_warehouse
                                                                INNER JOIN
                                                                tbl_locations
                                                                ON 
                                                                        tbl_warehouse.dist_id = tbl_locations.PkLocID
                                                            WHERE
                                                            tbl_warehouse.stkid = '" . $stakeholder . "'
                                                            AND tbl_warehouse.prov_id= '" . $prov_id . "' 
                                                            AND tbl_warehouse.dist_id= '" . $district . "' 
                                                            AND tbl_warehouse.is_active = 1 
                                                            and ecr_start_month is not null ";
if ($_SESSION['user_level'] == '3'){
    $qry .=" AND tbl_warehouse.dist_id= '" . $_SESSION['user_district'] . "'  ";
}
$qry .="
                                                    ORDER BY tbl_locations.LocName,tbl_warehouse.wh_name        

                                                    ";
//                                        echo $qry;exit;
$qryRes = mysql_query($qry);
while ($row = mysql_fetch_assoc($qryRes)) {
    $hf_arr[] = $row;
}
$hf_count = count($hf_arr);
?>
<select required id="wh_id" name="wh_id" class="input-large  select2me">


    <?php
    $wh_id = $_REQUEST['sel_hf'];
    $wh_name = '';
    if (!empty($hf_count) && $hf_count > 1) {
        echo '<option value=""> SELECT </option>';
    }
    foreach ($hf_arr as $k => $val) {
        if($val['wh_id'] == $wh_id){
            $wh_name = $val['wh_name'];
            $sel =' selected ';
        }else{
            $sel = '';
        }

        echo ' <option '.$sel.' value="' . $val['wh_id'] . '">'.$val['dist_name'].' - ' . $val['wh_name'] . '</option>';
    }
    ?>
</select>