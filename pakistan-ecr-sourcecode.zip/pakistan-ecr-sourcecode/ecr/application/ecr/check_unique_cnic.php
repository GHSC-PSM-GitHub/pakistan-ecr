<?php

include("../includes/classes/AllClasses.php");

$cnic       = $_REQUEST['cnic'];
@$mode       = $_REQUEST['mode'];
@$client_id  = $_REQUEST['client_id'];

$ret=array();
        
if(!isset($cnic) || $cnic == '' || $cnic == '0' || (int)$cnic == '0'){
    // force override 00000-0000000-0
    $cnic = '00000-0000000-0';
    $ret['exists'] = 'no';
}
else{
    ////// now the cnic format supports both with and without dashes.

    if (preg_match('/^\d{5}-\d{7}-\d{1}$/', $cnic)) {
        $ret['format']= 'matched_format';
    } elseif (preg_match('/^\d{13}$/', $cnic)) {
        $ret['format']= 'matched_format';
    } else {
        $ret['format']=  'wrong_format';
    }

    if($ret['format'] == 'matched_format')
    {
        $temp_cnic = explode('-',$cnic);
        @$comb_cnic = $temp_cnic[0].$temp_cnic[1].$temp_cnic[2];
        $formatted_cnic = substr($comb_cnic,0,5).'-'.substr($comb_cnic,5,7).'-'.substr($comb_cnic,12,1);

        $qry="SELECT count(*) as cnt from ecr_clients where cnic = '".$formatted_cnic."' ";
        if(!empty($mode)  && $mode == 'edit' && !empty($client_id)){
            $qry .= " and pk_id <> '".$client_id."' ";
        }
        $qryRes = mysql_query($qry);
        $row = mysql_fetch_assoc($qryRes);
        $ret['count'] = $row['cnt'];
        if(!empty($row['cnt']) && $row['cnt'] > 0){

            $ret['exists'] = 'yes';
        }else{

            $ret['exists'] = 'no';
        }
        $ret['what'] = 'client exists or not';
    }
}
header('Content-Type:application/json');
echo json_encode($ret);
exit;
?>