<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Welcome</h3>
                            </div>
                            <div class="widget-body">
                                <form method="POST" name="add_client" id="add_client" action="add_client_action.php"  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                        </div>
                                    </div>


                                </form>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->
 
</body>
</html>