<?php

include("../includes/classes/AllClasses.php");
include "ecr_common.php";


$visit_id = $_POST['visit_id'];
if (!empty($visit_id)) {
    
    
    $qry = "SELECT * FROM
                    ecr_client_visits
                WHERE 
                    pk_id = '" . $visit_id . "'
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $visit_arr = $row;
    }
}


if(!((!empty($visit_arr['wh_id']) && $visit_arr['wh_id']==$_SESSION['user_warehouse']) || $_SESSION['user_id'] == '9744'))
{
    echo 'Un-Authorized Access. You do NOT have authorization to perform this action !';
    exit;
}

//    
//echo '<pre>OK:';
//print_r($_POST);
//echo '</pre>';
//exit;


    $wh_id = $_POST['wh_id'];
    $client_id = $_POST['client_id'];
    $outcome_last_preg = $_POST['outcome_last_preg'];
    $period_from_last_preg = $_POST['period_from_last_preg'];
    $fp_method = $_POST['fp_method'];
    //if(empty($fp_method) || $fp_method =='') $fp_method = '0';
    $fp_method_name = $_POST['fp_method_name'];
    $fp_qty = $_POST['fp_qty'];
    if(empty($fp_qty) || $fp_qty =='') $fp_qty = '0';

    $additional_item = $_POST['additional_item'];
    $additional_item_qty = $_POST['additional_item_qty'];
    //if(empty($additional_item) || $additional_item =='') $additional_item = '0';
    //if(empty($additional_item_qty) || $additional_item_qty =='') $additional_item_qty = '0';

    $fp_referred_from = $_POST['fp_referred_from'];

    $fp_referred_from_desig = $_POST['fp_referred_from_desig'];
    $fp_reason_of_referral  = $_POST['fp_reason_of_referral'];
    $activity_uc            = $_POST['activity_uc'];
    $activity_num           = $_POST['activity_num'];
    $visit_purpose          = $_POST['visit_purpose'];


    $fp_counseling = $_POST['fp_counseling'];
    $fp_referred_to = $_POST['fp_referred_to'];
    $fp_referred_for = $_POST['fp_referred_for'];


    $gen_health_patient_type = $_POST['gen_health_patient_type'];
    $fp_category = $_POST['fp_category'];
    $gen_health_category = $_POST['gen_health_category'];
    $gen_health_diagnosis = $_POST['gen_health_diagnosis'];
    $gen_health_treatment = $_POST['gen_health_treatment'];
    $gen_health_referred_to = $_POST['gen_health_referred_to'];
    $larc_method = $_POST['larc_method'];
    $larc_method_name = $_POST['larc_method_name'];
    $larc_period = $_POST['larc_period'];
    $larc_reason = $_POST['larc_reason'];
    $activity_under = $_POST['activity_under'];

    $parity_alive = $_POST['parity_alive'];
    $parity_death = $_POST['parity_death'];

    $date_of_visit = $_POST['date_of_visit'];
    $remarks_of_date = $_POST['remarks_of_date'];


    $strSql = " UPDATE `ecr_client_visits` SET ";
    $strSql .= " `date_of_visit`= '".$date_of_visit."',`remarks_of_date`='".$remarks_of_date."', ";
    $strSql .= " `outcome_last_preg` = '".$outcome_last_preg."',  ";
    $strSql .= " `period_from_last_preg`='".$period_from_last_preg."', `fp_method`='".$fp_method."', ";
    $strSql .= " `fp_method_name`='".$fp_method_name."',  ";
    $strSql .= " `fp_qty`='".$fp_qty."',`additional_item`='".$additional_item."',`additional_item_qty`='".$additional_item_qty."', ";
    $strSql .= "  `fp_referred_from`='".$fp_referred_from."', `fp_counseling`='".$fp_counseling."',  ";
    $strSql .= " `fp_referred_to`='".$fp_referred_to."', `gen_health_patient_type`='".$gen_health_patient_type."',  ";
    $strSql .= " `fp_category`='".$fp_category."',`gen_health_category`='".$gen_health_category."', ";
    $strSql .= " `gen_health_diagnosis`='".$gen_health_diagnosis."',  ";
    $strSql .= " `gen_health_treatment`='".$gen_health_treatment."', `gen_health_referred_to`='".$gen_health_referred_to."',  ";
    $strSql .= " `larc_method`='".$larc_method."', `larc_method_name`='".$larc_method_name."', `larc_period`='".$larc_period."',  ";
    $strSql .= " `larc_reason`='".$larc_reason."', `activity_under`='".$activity_under."', ";
    $strSql .= " `parity_alive`='".$parity_alive."', `parity_death`='".$parity_death."',`fp_referred_for`='".$fp_referred_for."', ";
    $strSql .= " `fp_referred_from_desig`='".$fp_referred_from_desig."',`fp_reason_of_referral`='".$fp_reason_of_referral."', ";
    $strSql .= "`activity_uc`='".$activity_uc."',`activity_num`='".$activity_num."',`visit_purpose`='".$visit_purpose."' ";
    $strSql .= " WHERE `client_id`= '".$client_id."' AND `wh_id` = '".$wh_id."' and pk_id = '".$visit_id."' ; ";
//    echo $strSql;exit;
    $rsSql = mysql_query($strSql) or die("ERROR in saving data");


    $strSql2 = " INSERT INTO `ecr_client_visits_log` SET ";
    $strSql2 .= " visit_id='".$visit_id."',`client_id`= '".$client_id."' ,`wh_id` = '".$wh_id."' ,user_id='".$_SESSION['user_id']."' ,";
    $strSql2 .= " `date_of_visit`= '".$date_of_visit."',`remarks_of_date`='".$remarks_of_date."', ";
    $strSql2 .= " `outcome_last_preg` = '".$outcome_last_preg."',  ";
    $strSql2 .= " `period_from_last_preg`='".$period_from_last_preg."', `fp_method`='".$fp_method."', ";
    $strSql2 .= " `fp_method_name`='".$fp_method_name."',  ";
    $strSql2 .= " `fp_qty`='".$fp_qty."',`additional_item`='".$additional_item."',`additional_item_qty`='".$additional_item_qty."', ";
    $strSql2 .= "  `fp_referred_from`='".$fp_referred_from."', `fp_counseling`='".$fp_counseling."',  ";
    $strSql2 .= " `fp_referred_to`='".$fp_referred_to."', `gen_health_patient_type`='".$gen_health_patient_type."',  ";
    $strSql2 .= " `fp_category`='".$fp_category."',`gen_health_category`='".$gen_health_category."', ";
    $strSql2 .= " `gen_health_diagnosis`='".$gen_health_diagnosis."',  ";
    $strSql2 .= " `gen_health_treatment`='".$gen_health_treatment."', `gen_health_referred_to`='".$gen_health_referred_to."',  ";
    $strSql2 .= " `larc_method`='".$larc_method."', `larc_method_name`='".$larc_method_name."', `larc_period`='".$larc_period."',  ";
    $strSql2 .= " `larc_reason`='".$larc_reason."', `activity_under`='".$activity_under."', ";
    $strSql2 .= " `parity_alive`='".$parity_alive."', `parity_death`='".$parity_death."',`fp_referred_for`='".$fp_referred_for."', ";
    $strSql2 .= " `fp_referred_from_desig`='".$fp_referred_from_desig."',`fp_reason_of_referral`='".$fp_reason_of_referral."', ";
    $strSql2 .= "`activity_uc`='".$activity_uc."',`activity_num`='".$activity_num."',`visit_purpose`='".$visit_purpose."'; ";
//    echo $strSql2;exit;
    $rsSql = mysql_query($strSql2) or die("ERROR in saving log");
    
    
    header("location:edit_visit.php?update=done&visit_id=".$visit_id);

exit;
?>