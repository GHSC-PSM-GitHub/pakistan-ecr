<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";


if(empty($_REQUEST['ids'])){
    echo 'invalid request';
    exit;
}
$ids= $_REQUEST['ids'];

if($_SESSION['user_id']!='9744'){
    echo 'Un Authorized Access !!';
    exit;
}
//echo '<pre>';
//print_r($_REQUEST);
//echo '</pre>';
//exit;
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Merge </h3>
                            </div>
                            <div class="widget-body">
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        
                                        $qry = "
                                          SELECT 
                                            ecr_clients.*,
                                            tbl_warehouse.wh_name,
                                            (select count(*) from ecr_client_visits where client_id = ecr_clients.pk_id) as visits
                                        FROM
                                                ecr_clients
                                        INNER JOIN
                                        tbl_warehouse
                                        ON 
                                        ecr_clients.registered_at = tbl_warehouse.wh_id
                                        Where pk_id in (".$ids." )
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
//                                        echo '<pre>';
//                                        print_r($data_arr);
//                                        echo '</pre>';    
//                                        exit;

                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                               echo '<tr class="info">';
                                        echo ' 
                                                <th>#</th>
                                                <th>System Registration No.</th>
                                                <th>Clients Name</th>
                                                <th>Father/Husband</th>
                                                <th>CNIC</th>
                                                <th>Contact</th>
                                                <th>System ID</th>
                                                <th> ---------- Merge Status ---------- </th>
                                                
                                            ';
                                        echo '</tr>';
                                        
                                        $master_id = 0 ;
                                        if(!empty($data_arr)){
                                            foreach ($data_arr as $k => $v) {

                                                echo '<tr>';
                                                echo '<td>' . $c++ . '</td>';
                                                echo '<td>' . $v['serial_number'] . '</td>';
                                                echo '<td>' . $v['client_name'] . '</td>';
                                                echo '<td>' . $v['father_name'] . '</td>';
                                                echo '<td>' . $v['cnic'] . '</td>';
                                                echo '<td>' . $v['contact_number'] . '</td>';
                                                echo '<td>' . $v['pk_id'] . '</td>';


                                                if($k == 0){
                                                    $st = 'Marking this ID: '.$v['pk_id'].' as master Record.';
                                                    $master_id = $v['pk_id'];
                                                }
                                                else{
                                                    
                                                    $st = '?';
                                                    if(!empty($master_id) && $master_id>0){
                                                        $qry4 = "Update ecr_client_visits SET client_id = '".$master_id."' where client_id = '".$v['pk_id']."' ";
                                                        mysql_query($qry4);
                                                        
                                                        
//                                                        $qry5 = "INSERT into ecr_clients_duplicates  Select *,'".$master_id."' from ecr_clients where ecr_clients.pk_id = '".$v['pk_id']."' ";
//                                                        mysql_query($qry5);
                                                        
                                                        
                                                        $qry6 = "DELETE from ecr_clients where ecr_clients.pk_id = '".$v['pk_id']."' ";
                                                        mysql_query($qry6);
                                                        
                                                        $st = 'Merged '.$v['pk_id'].' into master';
                                                        
                                                    }
                                                }
                                                echo '<td>'.$st.'</td>';
                                                echo '</tr>';
                                            }
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>