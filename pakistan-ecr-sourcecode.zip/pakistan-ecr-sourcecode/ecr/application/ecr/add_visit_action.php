<?php

include("../includes/classes/AllClasses.php");
include "ecr_common.php";

//echo '<pre>';
//print_r($_REQUEST);
//echo '</pre>';
//exit;

$wh_id = $_REQUEST['wh_id'];
$client_id = $_REQUEST['client_id'];
$outcome_last_preg = $_REQUEST['outcome_last_preg'];
$period_from_last_preg = $_REQUEST['period_from_last_preg'];
$fp_method = $_REQUEST['fp_method'];
//if(empty($fp_method) || $fp_method =='') $fp_method = '0';
$fp_method_name = $_REQUEST['fp_method_name'];
$fp_qty = $_REQUEST['fp_qty'];
if(empty($fp_qty) || $fp_qty =='') $fp_qty = '0';

$additional_item = $_REQUEST['additional_item'];
$additional_item_qty = $_REQUEST['additional_item_qty'];
//if(empty($additional_item) || $additional_item =='') $additional_item = '0';
//if(empty($additional_item_qty) || $additional_item_qty =='') $additional_item_qty = '0';

$fp_referred_from = $_REQUEST['fp_referred_from'];

$fp_referred_from_desig = $_REQUEST['fp_referred_from_desig'];
$fp_reason_of_referral  = $_REQUEST['fp_reason_of_referral'];
$activity_uc            = $_REQUEST['activity_uc'];
$activity_num           = $_REQUEST['activity_num'];
$visit_purpose          = $_REQUEST['visit_purpose'];


$fp_counseling = $_REQUEST['fp_counseling'];
$fp_referred_to = $_REQUEST['fp_referred_to'];
$fp_referred_for = $_REQUEST['fp_referred_for'];


$gen_health_patient_type = $_REQUEST['gen_health_patient_type'];
$fp_category = $_REQUEST['fp_category'];
$gen_health_category = $_REQUEST['gen_health_category'];
$gen_health_diagnosis = $_REQUEST['gen_health_diagnosis'];
$gen_health_treatment = $_REQUEST['gen_health_treatment'];
$gen_health_referred_to = $_REQUEST['gen_health_referred_to'];
$larc_method = $_REQUEST['larc_method'];
$larc_method_name = $_REQUEST['larc_method_name'];
$larc_period = $_REQUEST['larc_period'];
$larc_reason = $_REQUEST['larc_reason'];
$activity_under = $_REQUEST['activity_under'];

$parity_alive = $_REQUEST['parity_alive'];
$parity_death = $_REQUEST['parity_death'];

$date_of_visit = $_REQUEST['date_of_visit'];
$remarks_of_date = $_REQUEST['remarks_of_date'];


$ref_to_fac = $_REQUEST['ref_to_fac'];
$ref_to_fac_name = (!empty($_SESSION['wh_list'][$ref_to_fac]['wh_name'])?$_SESSION['wh_list'][$ref_to_fac]['wh_name']:'');
$type_of_visit = $_REQUEST['type_of_visit'];

//////overriding fp cols if category is followup

if(!empty($fp_category) && ( $fp_category == 'Follow up' || $fp_category == 'Counselling')) {
    $fp_method='';
    $fp_method_name='';
    $fp_qty='';
}



$qry = " SELECT * FROM ecr_client_visits where 
    client_id = '".$client_id."'
    and wh_id = '".$wh_id."'
    and date_of_visit = '".$date_of_visit."'
    and visit_purpose = '".$visit_purpose."'
    and fp_method = '".$fp_method."'; ";
$qryRes = mysql_query($qry);
$visit_data=array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $visit_data = $row;
}


if(!empty($visit_data['pk_id']) && $visit_data['pk_id'] > 0){
    /// client info already exists
    $visit_id = $visit_data['pk_id'];
    
    if(!empty($visit_id)){
        header("location:view_visit.php?visit_id=".$visit_id."&show_msg=visit_duplicate");
    }
    exit;
}


//fetch name of wh
$qry = " SELECT 
	tbl_warehouse.wh_name FROM
        tbl_warehouse
	WHERE 
        tbl_warehouse.wh_id = '".$wh_id."'
        LIMIT 1 ";
$qryRes = mysql_query($qry);
$wh_data = mysql_fetch_assoc($qryRes);
$wh_name = $wh_data['wh_name'];


$strSql = " INSERT INTO `ecr_client_visits` ";
$strSql .= " ( `client_id`,`wh_id`,`wh_name`,`date_of_visit`,`remarks_of_date`, `outcome_last_preg`,  ";
$strSql .= " `period_from_last_preg`, `fp_method`, `fp_method_name`,  ";
$strSql .= " `fp_qty`,`additional_item`,`additional_item_qty`, ";
$strSql .= "  `fp_referred_from`, `fp_counseling`,  ";
$strSql .= " `fp_referred_to`, `gen_health_patient_type`,  ";
$strSql .= " `fp_category`,`gen_health_category`, `gen_health_diagnosis`,  ";
$strSql .= " `gen_health_treatment`, `gen_health_referred_to`,  ";
$strSql .= " `larc_method`, `larc_method_name`, `larc_period`,  ";
$strSql .= " `larc_reason`, `activity_under`, `parity_alive`, `parity_death`,`fp_referred_for`, ";
$strSql .= " `fp_referred_from_desig`,`fp_reason_of_referral`,`activity_uc`,`activity_num`,`visit_purpose`, ";
$strSql .= " `ref_to_fac`,`ref_to_fac_name`,`type_of_visit` ";
$strSql .= " )  ";
$strSql .= " VALUES (  '".$client_id."','".$wh_id."','".$wh_name."','".$date_of_visit."','".$remarks_of_date."', '".$outcome_last_preg."',  ";
$strSql .= " '".$period_from_last_preg."', '".$fp_method."', '".$fp_method_name."',  ";
$strSql .= " '".$fp_qty."','".$additional_item."','".$additional_item_qty."',  ";
$strSql .= " '".$fp_referred_from."', '".$fp_counseling."',  ";
$strSql .= " '".$fp_referred_to."', '".$gen_health_patient_type."',  ";
$strSql .= " '".$fp_category."','".$gen_health_category."', '".$gen_health_diagnosis."',  ";
$strSql .= " '".$gen_health_treatment."', '".$gen_health_referred_to."',  ";
$strSql .= " '".$larc_method."', '".$larc_method_name."', '".$larc_period."',  ";
$strSql .= " '".$larc_reason."', '".$activity_under."','".$parity_alive."','".$parity_death."','".$fp_referred_for."',  ";
$strSql .= " '".$fp_referred_from_desig."','".$fp_reason_of_referral."','".$activity_uc."','".$activity_num."','".$visit_purpose."',  ";
$strSql .= " '".$ref_to_fac."','".$ref_to_fac_name."','".$type_of_visit."'  ";
$strSql .= " ) ";
//echo $strSql;
//echo '<pre>';
//print_r($_REQUEST);
//echo '</pre>';
//exit;
//exit;
$rsSql = mysql_query($strSql) or die("ERROR in saving data");

//echo $client_id;
//exit;
        if(isset($_REQUEST['save_only'])){
            header("location:view_client.php?client_id=".$client_id."&show_msg=visit_added");
        }

        if(isset($_REQUEST['save_n_search'])){
            header("location:search_clients.php?show_msg=visit_added");
        }
        if(isset($_REQUEST['save_n_add_visit'])){
            header("location:add_visit.php?client_id=".$client_id."&show_msg=visit_added");
        }
exit;
?>