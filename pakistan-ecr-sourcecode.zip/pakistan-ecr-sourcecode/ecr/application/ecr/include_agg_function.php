<?php

/// NOTE : please only run this script for single month
//echo $param_month;exit;

if(!empty($param_month) && $param_month > ''){
	
$count_i=$count_u = 0;

$qry = '
select itm,
	mm,
	a.wh_id,
	sum(qty) as qty 
FROM 

(
(SELECT
	ecr_client_visits.fp_method as itm, 

	DATE_FORMAT(date_of_visit, "%Y-%m-01") as mm,
	ecr_client_visits.wh_id,
	sum(ecr_client_visits.fp_qty) as qty
FROM
	ecr_client_visits 	
        INNER JOIN	tbl_warehouse	ON ecr_client_visits.wh_id = tbl_warehouse.wh_id
	where fp_method is not null and fp_method  > 0 and
	fp_method not in (31,32) AND fp_qty > 0 and ecr_client_visits.wh_id > 0
	and DATE_FORMAT(ecr_client_visits.date_of_visit, "%Y-%m-01") = \''.$param_month.'\'
            ';
if(!empty($wh_id) && $wh_id > 0){
    $qry .= ' and ecr_client_visits.wh_id = \''.$wh_id.'\'  ';
}
$qry .= ' GROUP BY ecr_client_visits.wh_id,mm,fp_method

	)

UNION ALL

(SELECT

	ecr_client_visits.additional_item as itm, 
	
	DATE_FORMAT(date_of_visit, "%Y-%m-01") as mm,
	ecr_client_visits.wh_id,
	sum(ecr_client_visits.additional_item_qty) as qty
FROM
	ecr_client_visits
        	INNER JOIN	tbl_warehouse	ON ecr_client_visits.wh_id = tbl_warehouse.wh_id
	where additional_item is not null and additional_item > 0 and additional_item_qty > 0 
	AND ecr_client_visits.wh_id > 0 
	and DATE_FORMAT(ecr_client_visits.date_of_visit, "%Y-%m-01") = \''.$param_month.'\'';
if(!empty($wh_id) && $wh_id > 0){
    $qry .= ' and ecr_client_visits.wh_id = \''.$wh_id.'\'  ';
}
$qry .= ' 
	group by ecr_client_visits.wh_id,mm,additional_item
	)
)as a
inner join tbl_warehouse on a.wh_id = tbl_warehouse.wh_id
WHERE tbl_warehouse.ecr_start_month is not null
group by a.wh_id,mm,itm
order by itm,a.wh_id,mm

';
//echo $qry;exit;
$qryRes = mysql_query($qry);
$cons_data = $wh_arr = array();
while ($row = mysql_fetch_array($qryRes)) {
	$cons_data[$row['wh_id']][$row['mm']][$row['itm']] = $row['qty'];
	$wh_arr[$row['wh_id']] = $row['wh_id'];
}
//echo '<pre>';
//print_r($cons_data);
//exit;

if(!empty($wh_arr)){
    $updateQry = "UPDATE tbl_hf_data SET issue_balance='0' , opening_balance= '0', closing_balance = '0' WHERE warehouse_id in (".implode(',',$wh_arr).")  AND reporting_date = '".$param_month."' ; ";
    mysql_query($updateQry) or die(" Error in update query ".$updateQry);
}
$qry_larc = 'SELECT
			ecr_client_visits.larc_method AS itm,
			DATE_FORMAT( date_of_visit, "%Y-%m-01" ) AS mm,
			wh_id,
			count( ecr_client_visits.pk_id ) AS qty 
		FROM
			ecr_client_visits 
		WHERE
			larc_method IS NOT NULL 
			AND larc_method != \'\'
			AND wh_id > 0 
			AND DATE_FORMAT( ecr_client_visits.date_of_visit, "%Y-%m-01" ) = \''.$param_month.'\'
                               ';
            if(!empty($wh_id) && $wh_id > 0){
                $qry_larc .= ' and ecr_client_visits.wh_id = \''.$wh_id.'\'  ';
            }
            $qry_larc .= ' 
		GROUP BY
			wh_id,
			mm,
			larc_method ';
//echo $qry_larc;exit;
$res_larc = mysql_query($qry_larc);
$larc_data = array();
while ($row = mysql_fetch_array($res_larc)) {
	$larc_data[$row['wh_id']][$row['mm']][$row['itm']] = $row['qty'];
}
/// fetching all values of last months closing balance
$last_m = date('Y-m-01',strtotime('-1 month',strtotime($param_month)));
$qry_last = " SELECT 	pk_id, 
    item_id, 
    opening_balance, 
    received_balance, 
    issue_balance, 
    closing_balance, 
    adjustment_positive, 
    adjustment_negative
    from tbl_hf_data WHERE warehouse_id = '".$wh_id."' AND reporting_date = '".$last_m."'  ; ";	
//echo $qry_last;exit;
$qryRes_last = mysql_query($qry_last);
$array_last_cb = array();
while($row_last = mysql_fetch_array($qryRes_last))
{
    $array_last_cb[$row_last['item_id']] = $row_last['closing_balance'];
    if(!isset($cons_data[$wh_id][$param_month][$row_last['item_id']])){
        $cons_data[$wh_id][$param_month][$row_last['item_id']]=0;
    }
}
//echo '<pre>';
//print_r($cons_data);
//print_r($array_last_cb);
//echo '</pre>';
//exit;

    foreach($cons_data as $wh_id => $wh_data){
        foreach($wh_data as $month => $m_data){

            
            
            
            foreach($m_data as $itm_id => $qty){

                $qry2 = " SELECT pk_id from tbl_hf_data WHERE warehouse_id = '".$wh_id."' AND item_id = '". $itm_id."' AND reporting_date = '".$month."' ; ";		
                $qryRes2 = mysql_query($qry2);
                $row2 = mysql_fetch_array($qryRes2);

                if(!empty($row2) && $row2 > 0)
                {
                    $ob = (!empty($array_last_cb[$itm_id])?$array_last_cb[$itm_id]:'0');
                    $updateQry = "UPDATE tbl_hf_data SET issue_balance='".$qty."' , opening_balance= '".$ob."', closing_balance = '".$ob."' + IFNULL(received_balance,0) - '".$qty."' + IFNULL(adjustment_positive,0) - IFNULL(adjustment_negative,0) WHERE warehouse_id = '".$wh_id."'AND item_id = '". $itm_id."' AND reporting_date = '".$month."' ; ";
                    mysql_query($updateQry) or die(" Error in update query ".$updateQry);
                    $count_u++;
                }
                else{
                    $ob = (!empty($array_last_cb[$itm_id])?$array_last_cb[$itm_id]:'0');
                    $cb = $ob - $qty  ;
                    $updateQry = "INSERT INTO tbl_hf_data SET warehouse_id = '".$wh_id."', item_id = '". $itm_id."', reporting_date = '".$month."', issue_balance='".$qty."', opening_balance='".$ob."', closing_balance='".$cb."', created_by='1' ; ";
                    mysql_query($updateQry) or die(" Error in insert query ".$updateQry);
                    $count_i++;
                }

                if(!empty($debug) && $debug == 'yes'){
                    echo '<br/>'.$updateQry;
                }
            }
        }
    }
}
else{
echo 'Invalid Params';
}

?>