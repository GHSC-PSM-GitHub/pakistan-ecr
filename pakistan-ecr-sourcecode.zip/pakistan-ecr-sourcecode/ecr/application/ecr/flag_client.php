<?php
include("../includes/classes/AllClasses.php");

$client_id = $_REQUEST['client_id'];
if(!empty($client_id)){
    
    $qry = " SELECT *  FROM ecr_clients where ecr_clients.pk_id = '".$client_id."'  ";
    $qryRes = mysql_query($qry);
    $client_data  =array();
    $row = mysql_fetch_assoc($qryRes);
    $client_data = $row;
   
     if(!( (!empty($client_data['registered_at']) && $client_data['registered_at']==$_SESSION['user_warehouse'] ) || $_SESSION['user_id'] == '9744' ))
    {
        ////access denied
        echo 'Un-Authorized Access. You do NOT have authorization for this action. !';
        exit;
     }
     
    /// status 
     /// 1 = active
     /// 0 = disabled
     /// 2 = flagged for review
     ///
    $strSql = " UPDATE ecr_clients SET ";
    $strSql .= "  `status`='2' ";
    $strSql .= "   WHERE pk_id = '".$client_id."' ;";
//    echo $strSql;exit;
    $rsSql = mysql_query($strSql) or die("ERROR in updating data");
    
    
    $strSql2 = " INSERT INTO ecr_clients_log SET ";
    $strSql2 .= "  `status`='2', ";
    $strSql2 .= "   client_id = '".$client_id."',user_id='".$_SESSION['user_id']."' ;";
//    echo $strSql2;exit;
    $rsSql = mysql_query($strSql2) or die($strSql2."ERROR in inserting log");
    
    
    if(!empty($_REQUEST['redirect'])){
        header("location:".$_REQUEST['redirect'].".php?show_msg=client_flagged");
    }
    else{
        header("location:search_clients.php?show_msg=client_flagged");
    }
}
exit;
?>