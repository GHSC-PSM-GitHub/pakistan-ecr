<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;

$id = '';

if (!empty($_REQUEST['visit_id']))
    $visit_id = htmlspecialchars($_REQUEST['visit_id']);


$qry = "SELECT
                list_detail.pk_id,
                list_detail.list_value,
                list_detail.description,
                list_detail.rank,
                list_detail.reference_id,
                list_detail.parent_id,
                list_detail.list_master_id
            FROM
                list_detail
            ORDER BY
                list_detail.rank ,
                list_detail.list_value ASC
        ";
$qryRes = mysql_query($qry);
$list_arr = array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $list_arr[$row['list_master_id']][$row['pk_id']]['name'] = $row['list_value'];
    $list_arr[$row['list_master_id']][$row['pk_id']]['description'] = $row['description'];
}

$client_arr = array();

if (!empty($visit_id)) {
    
    
    $qry = "SELECT * FROM
                    ecr_client_visits
                WHERE 
                    pk_id = '" . $visit_id . "'
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $visit_arr = $row;
    }
    
    
    $client_id = $visit_arr['client_id'];
    
    $qry = "SELECT * FROM
                    ecr_clients
                WHERE 
                    pk_id = '" . $client_id . "'
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $client_arr = $row;
    }
    
//    echo '<pre>';
//    print_r($visit_arr);
////    print_r($client_arr);
//    echo '</pre>';
//    exit;
}


$prov_id = $_SESSION['user_province1'];
$stk_id = $_SESSION['user_stakeholder1'];
$user_id = $_SESSION['user_id'];
$hf_arr = array();
$qry = "SELECT 
	tbl_warehouse.wh_id,tbl_warehouse.wh_name FROM
                    tbl_warehouse
	INNER JOIN
	wh_user
	ON 
		tbl_warehouse.wh_id = wh_user.wh_id
	INNER JOIN
	stakeholder
	ON 
		tbl_warehouse.stkofficeid = stakeholder.stkid
                WHERE 
                    wh_user.sysusrrec_id = '" . $user_id . "' 
                    AND stakeholder.lvl > 4 
                    AND tbl_warehouse.stkid = '" . $stk_id . "'
                    AND tbl_warehouse.prov_id= '" . $prov_id . "' 
                    AND tbl_warehouse.is_active = 1 
                    and ecr_start_month is not null
            ORDER BY tbl_warehouse.wh_name        

            ";
$qryRes = mysql_query($qry);
while ($row = mysql_fetch_assoc($qryRes)) {
    $hf_arr[] = $row;
}
$hf_count=count($hf_arr);
//echo '<pre>';
//print_r($hf_arr);
//echo '</pre>';
//exit; 
?>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                 
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Edit Visit <?php echo (!empty($client_arr['serial_number'])?'(Registration Number of Client : '.$client_arr['serial_number'].')':'')?></h3>
                            </div>
                            <div class="widget-body">
                                <?php
                                
                                ///////access control check
                            if(!((!empty($visit_arr['wh_id']) && $visit_arr['wh_id']==$_SESSION['user_warehouse']) || $_SESSION['user_id'] == '9744'))
                            {
                                    ////access denied
                                    $show = false;
                                    echo '<br/>';
                                    echo '<span class="note note-danger">Access Denied : You are NOT authorized to edit this information.</span>';
                                    echo '<br/>';
                                    echo '<br/>';
                            }
                            else
                                {
                                    $show = true;
                                    ////access allowed
                                ?>
                                
                                <div class="row">
                                    
                                    <div class="col-md-12 table-responsive">
 <?php
                                                if(!empty($_REQUEST['update']) && $_REQUEST['update'] == 'done' ){
                                            ?>
                                            <div class="col-md-12 col-lg-12">
                                                <div class="note note-success" >Visit Details Updated  <i class="fa fa-check font-green"></i></div>  
                                            </div>
                                            <?php
                                                }
                                            ?>
                                        
                                        <h3 class="font-blue-madison">Edit Visit Information - <?php echo ' of "'.$client_arr['client_name'].'" at "'.$visit_arr['wh_name'].'" on "'.date('Y-M-d',strtotime($visit_arr['date_of_visit'])).'"'; ?> </h3>
                                        <hr/>
                                        <?php
                                        if(strtotime($min_date) > strtotime($visit_arr['date_of_visit'])){
                                            echo '<h4 class="font-red"> <i class="fa fa-exclamation-triangle"></i>ALERT !!! You can NOT Edit this Visit Information, Because Data before the date of '.date('jS M Y',strtotime($min_date)).' has been locked for this facility.</h4>';
                                        }else{
                                            echo '<form method="POST" name="add_client" id="add_client" action="edit_visit_action.php" >';
                                        }
                                        ?>     
                                        
                                            <input type="hidden" name="client_id" value ="<?= $client_id ?>" >

                                            <div class="row well">
                                                <div class="col-md-2 ">
                                                    <div class=""><h4 class="alert alert-warning">Visit Info *</h4></div>
                                                </div>
                                                <div class="col-md-10 ">

                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="selectbasic">Health Facility of This Visit </label>
                                                            <div class="controls">
                                                                <select required id="wh_id" name="wh_id" class="form-control">

                                                                    
                                                                    <?php
                                                                    if(!empty($hf_count) && $hf_count>1){
                                                                       echo '<option value=""> SELECT </option>'; 
                                                                    }
                                                                    foreach ($hf_arr as $k => $val) {
                                                                        echo ' <option value="' . $val['wh_id'] . '">' . $val['wh_name'] . '</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="date_of_visit">Date of Visit <span class="font-red">*</span> </label>
                                                            <div class="controls">
                                                                <input type="date" required onkeydown="return false"  value="<?= date('Y-m-d',strtotime($visit_arr['date_of_visit'])) ?>" min="<?=(!empty($min_date)?date('Y-m-d',strtotime($min_date)):'2022-10-01')?>" max="<?= date('Y-m-d') ?>" id="date_of_visit" name="date_of_visit" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" id="div_remarks" style="">
                                                        <div class="control-group">
                                                            <label class="control-label" for="remarks_of_date">Reason for changing date </label>
                                                            <div class="controls">
<!--                                                                <input type="text" required maxlength="254" id="remarks_of_date" name="remarks_of_date" class="form-control" placeholder="">-->

                                                                <select id="remarks_of_date" name="remarks_of_date" class="form-control">

                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                    foreach ($list_arr['41'] as $k => $val) {
                                                                        if(!empty($visit_arr['remarks_of_date']) && $visit_arr['remarks_of_date'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="remarks_of_date">Purpose of visit </label>
                                                            <div class="controls">
                                                                <select required id="visit_purpose" name="visit_purpose" class="form-control">
                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                        if(!empty($visit_arr['visit_purpose']) && $visit_arr['visit_purpose'] == 'fp')
                                                                        {
                                                                            echo '<option value="fp" selected>Family Planning Services</option>';
                                                                        }
                                                                        if(!empty($visit_arr['visit_purpose']) && $visit_arr['visit_purpose'] == 'larc_removal')
                                                                        {
                                                                            echo '<option value="larc_removal" selected>LARC Removal</option>';
                                                                        }
                                                                        if(!empty($visit_arr['visit_purpose']) && $visit_arr['visit_purpose'] == 'ghs')
                                                                        {
                                                                            echo '<option value="ghs" selected>General Health Services</option>';
                                                                        }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    



                                                </div>
                                            </div>




                                            <div class="row well">
                                                <div class="col-md-2 ">
                                                    <div class=""><h4 class="alert alert-info">Last pregnancy / procedure</h4></div>
                                                </div>
                                                <div class="col-md-10 ">
                                                    <div class="col-md-3"><div class="control-group">
                                                            <label class="control-label" for="selectbasic">Parity ( Alive )</label>
                                                            <div class="controls">
                                                                <input id="parity_alive" name="parity_alive" type="Number" value="<?php echo $visit_arr['parity_alive'];?>" step="1" min="0" placeholder="Number" class="form-control input-md"> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3"><div class="control-group">
                                                            <label class="control-label" for="selectbasic">Parity ( Death )</label>
                                                            <div class="controls">
                                                                <input id="parity_death" name="parity_death" type="Number" value="<?php echo $visit_arr['parity_death'];?>" step="1" min="0" placeholder="Number" class="form-control input-md"> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6"><div class="control-group">
                                                            <label class="control-label" for="selectbasic">Parity Total ( Alive + Death )</label>
                                                            <div class="controls">
                                                                <input id="parity_total" readonly disabled value="<?php echo $visit_arr['parity_alive']+$visit_arr['parity_death'];?>" class="form-control input-md"> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">

                                                        <div class="control-group">
                                                            <label class="control-label" for="radios">Outcome of Last Pregnancy/Procedure</label>
                                                            <div class="controls"> 
                                                                <label class="radio-inlinex" for="outcome_last_pregdn">
                                                                    <input type="radio" name="outcome_last_preg" id="outcome_last_pregdn" value="NVD (Normal Vaginal Delivery)"  <?php echo (strtolower($visit_arr['outcome_last_preg'])=='normal delivery' || strtolower($visit_arr['outcome_last_preg'])== strtolower('NVD (Normal Vaginal Delivery)'))?'checked="checked"':''?> >NVD (Normal Vaginal Delivery)</label>
                                                                <label class="radio-inlinex" for="outcome_last_pregdc">
                                                                    <input type="radio" name="outcome_last_preg" id="outcome_last_pregdc" value="LSCS (LOWER SEGMENT CESAREAN SECTION)" <?php echo (strtolower($visit_arr['outcome_last_preg'])=='c-section' || strtolower($visit_arr['outcome_last_preg'])== strtolower('LSCS (Lower Segment Cesarean Section)'))?'checked="checked"':''?> >LSCS (Lower Segment Cesarean Section)</label>
                                                                <label class="radio-inlinex" for="outcome_last_prega">
                                                                    <input type="radio" name="outcome_last_preg" id="outcome_last_prega" value="abortion" <?php echo (strtolower($visit_arr['outcome_last_preg'])=='abortion' || strtolower($visit_arr['outcome_last_preg'])== strtolower('Abortion'))?'checked="checked"':''?> >Abortion</label> 

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="control-group">
                                                            <label class="control-label" for="selectbasic">Total period from last Outcome / Pregnancy</label>
                                                            <div class="controls">
                                                                <select id="period_from_last_preg" name="period_from_last_preg" class="form-control">

                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                     $sel='';
                                                                    foreach ($list_arr['38'] as $k => $val) {
                                                                        if(!empty($visit_arr['period_from_last_preg']) && $visit_arr['period_from_last_preg'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            
                                            <div class="row well services" id="fp" style="display:none;">
                                                <div class="col-md-2">
                                                    <div><h4 class="alert alert-success">Family Planning Services</h4></div>
                                                </div>
                                                <div class="col-md-10 ">

                                                    <div class="col-md-4"><div class="control-group">
                                                            <label class="control-label" for="fp_category">Category of Client</label>
                                                            <div class="controls">
                                                                <select id="fp_category" name="fp_category" class="form-control">

                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                    foreach ($list_arr['34'] as $k => $val) {
                                                                        if(!empty($visit_arr['fp_category']) && $visit_arr['fp_category'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '" my_id="' . (!empty($k) ? $k : '') . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <?php
                                                    if(!empty($visit_arr['type_of_visit']) && $visit_arr['type_of_visit']=='1'){
                                                        $hide_issuance='';
                                                        $hide_referral='display:none;';
                                                    }
                                                    elseif(!empty($visit_arr['type_of_visit']) && $visit_arr['type_of_visit']=='2'){
                                                        $hide_issuance='display:none;';
                                                        $hide_referral='';
                                                    }
                                                    ?>
                                                    <div class="col-md-6">

                                                        <div class="control-group show_for_fp_only" style="">
                                                            <label class="control-label" for="radios">Type of Visit</label>
                                                            <div class="controls"> 
                                                                <label class="radio-inlinex" for="type_of_visit1" style="<?=$hide_issuance?>">
                                                                    <input type="radio" name="type_of_visit" id="type_of_visit1" value="1" style="<?=$hide_issuance?>" <?php echo (!empty($visit_arr['type_of_visit']) && $visit_arr['type_of_visit']=='1')?'checked="checked"':''?>>Issuance / Procedure</label> 
                                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                <label class="radio-inlinex" for="type_of_visit2" style="<?=$hide_referral?>">
                                                                    <input type="radio" name="type_of_visit" id="type_of_visit2" value="2" style="<?=$hide_referral?>" <?php echo (!empty($visit_arr['type_of_visit']) && $visit_arr['type_of_visit']=='2')?'checked="checked"':''?>>Referral to other facility</label> 

                                                            </div>
                                                        </div>
                                                    </div>
?>
                                                    <div class="col-md-3 show_for_fp_only" style="<?=$hide_issuance?>">
                                                        <div class="control-group">
                                                            <label class="control-label" for="fp_method">Selection of FP Method <span class="font-red">*</span> </label>
                                                            <div class="controls">
                                                                <select id="fp_method" name="fp_method"  class="form-control">
                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                    $fp_method_name='';
                                                                    foreach ($items_fp as $k => $v) {
                                                                        if(!empty($visit_arr['fp_method']) && $visit_arr['fp_method'] == $k ){
                                                                            $sel = ' selected ';
                                                                            $fp_method_name= $v;
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo '<option '.$sel.' value="' . $k . '" max_val="' . (!empty($items_fp_max[$k]) ? $items_fp_max[$k] : '1') . '">' . $v . '</option>';
                                                                    }
                                                                    ?>
                                                                </select>

                                                                <input type="hidden" name="fp_method_name" id="fp_method_name" value="<?php echo $fp_method_name; ?>">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3 show_for_fp_only" style="<?=$hide_issuance?>">
                                                        <div class="control-group">
                                                            <label class="control-label" for="fp_qty">Quantity   <span class="font-red">*</span> [Max Allowed : <span id="max_msg">?</span>] </label>  
                                                            <div class="controls">
                                                                <input id="fp_qty" name="fp_qty" type="number" value="<?php echo $visit_arr['fp_qty'];?>" step="1" min="0" max="10" placeholder="Number" class="form-control input-md"> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 " id="additional_div" style="<?=$hide_issuance?>">
                                                        <div class="control-group">
                                                            <label class="control-label" for="additional_item">Additional RC ?  </label>
                                                            <div class="controls">
<!--                                                                NOTE: the value=1 of following additional_item represents Item id of Condom-->
                                                                <input id="additional_item" name="additional_item" type="checkbox" value="1" <?php echo ((!empty($visit_arr['additional_item']) && $visit_arr['additional_item']=='1')?' checked':'')?>  class="checkbox">
                                                                <input id="additional_item_qty" name="additional_item_qty" type="number" value="<?php echo $visit_arr['additional_item_qty'];?>" placeholder="Enter Qty"   class="form-control input-md" style="" > 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="<?=$hide_referral?>"><div class="control-group">
                                                            <label class="control-label" for="fp_referred_from">Referred By (Name)</label>  
                                                            <div class="controls">
                                                                <input id="fp_referred_from" name="fp_referred_from" type="text" value="<?php echo $visit_arr['fp_referred_from'];?>" placeholder="Enter name of referee" class="form-control input-md"> 

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="<?=$hide_referral?>"><div class="control-group">
                                                            <label class="control-label" for="fp_referred_from">Referred By (Designation)</label>  
                                                            <div class="controls">
                                                                <select id="fp_referred_from_desig" name="fp_referred_from_desig" class="form-control">

                                                                    <option value=""> Select  </option>
                                                                    <?php
                                                                    foreach ($list_arr['45'] as $k => $val) {
                                                                        if(!empty($visit_arr['fp_referred_from_desig']) && $visit_arr['fp_referred_from_desig'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '" my_id="' . (!empty($k) ? $k : '') . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--                                                    <div class="col-md-4">
                                                                                                            <div class="control-group">
                                                    
                                                    
                                                    
                                                                                                                <label class="control-label" for="fp_counseling">Counselling</label>
                                                                                                                <div class="controls"> 
                                                                                                                    <label class="radio-inline" for="fp_counselingy">
                                                                                                                        <input type="radio" name="fp_counseling" id="fp_counselingy" value="yes" >
                                                                                                                        Yes
                                                                                                                    </label> 
                                                                                                                    <label class="radio-inline" for="fp_counselingn">
                                                                                                                        <input type="radio" name="fp_counseling" id="fp_counselingn" value="no">
                                                                                                                        No
                                                                                                                    </label> 
                                                    
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>-->
                                                    <?php
                                                    if(!empty($visit_arr['fp_referred_to'])){
                                                    ?>
                                                    <div class="col-md-4" style="<?=$hide_referral?>">
                                                        <div class="control-group">
                                                            <label class="control-label" for="fp_referred_to">Referred to</label>  
                                                            <div class="controls">

                                                                <select id="fp_referred_to" name="fp_referred_to" class="form-control">

                                                                    <option value=""> Select  </option>
                                                                    <?php
                                                                    foreach ($list_arr['42'] as $k => $val) {
                                                                        if(!empty($visit_arr['fp_referred_to']) && $visit_arr['fp_referred_to'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '" my_id="' . (!empty($k) ? $k : '') . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php
                                                    }
                                                    ?>
                                                                                                       
                                                    <div class="col-md-4 show_for_ref_only"  style="<?=$hide_referral?>">
                                                        <div class="control-group">
                                                            <label class="control-label" for="ref_to_fac">Referred to Facility</label>  
                                                            <div class="controls">

                                                                <select id="ref_to_fac" name="ref_to_fac" class="form-control">

                                                                    <option value=""> Select  </option>
                                                                    <?php
                                                                    foreach ($_SESSION['wh_list'] as $k => $val) {
                                                                        if(!empty($visit_arr['ref_to_fac']) && $visit_arr['ref_to_fac'] == $val['wh_id'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['wh_id'] . '" my_name="' . $val['wh_name'] . '">' . $val['wh_name'] . ' </option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="<?=$hide_referral?>">
                                                        <div class="control-group">
                                                            <label class="control-label" for="fp_referred_for">Referred For</label>  
                                                            <div class="controls">
                                                                <select id="fp_referred_for" name="fp_referred_for" class="form-control">

                                                                    <option value=""> Select  </option>
                                                                    <?php
                                                                    foreach ($list_arr['43'] as $k => $val) {
                                                                        if(!empty($visit_arr['fp_referred_for']) && $visit_arr['fp_referred_for'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '" my_id="' . (!empty($k) ? $k : '') . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>



                                                    <div class="col-md-4" style="<?=$hide_referral?>" id="fp_reason_div">
                                                        <div class="control-group">
                                                            <label class="control-label" for="fp_referred_for">Reason for IUCD referral (if applicable)</label>  
                                                            <div class="controls">
                                                                <select id="fp_reason_of_referral" name="fp_reason_of_referral" class="form-control">

                                                                    <option value=""> Select  </option>
                                                                    <?php
                                                                    foreach ($list_arr['44'] as $k => $val) {
                                                                        if(!empty($visit_arr['fp_reason_of_referral']) && $visit_arr['fp_reason_of_referral'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '" my_id="' . (!empty($k) ? $k : '') . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>

                                            <div class="row well services" id="larc_removal" style="">
                                                <div class="col-md-2">
                                                    <div><h4 class="alert alert-success">Removal of LARC</h4></div>
                                                </div>
                                                <div class="col-md-10 ">
                                                    <div class="col-md-4"><div class="control-group">
                                                            <label class="control-label" for="larc_method">Method</label>
                                                            <div class="controls">
                                                                <select id="larc_method"  name="larc_method" class="form-control">
                                                                    <option value="">SELECT</option>
                                                                    <?php
                                                                    $larc_method_name =''; 
                                                                    foreach ($items_larc as $k => $v) {
                                                                        if(!empty($visit_arr['larc_method']) && $visit_arr['larc_method'] == $k ){
                                                                            $sel = ' selected ';
                                                                            $larc_method_name = $v; 
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo '<option '.$sel.' value="' . $k . '">' . $v . '</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                                <input type="hidden" name="larc_method_name" id="larc_method_name" value="<?php echo $larc_method_name;?>">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4"><div class="control-group">
                                                            <label class="control-label" for="larc_period">Period ( of Insertion )</label>
                                                            <div class="controls">
                                                                <select id="larc_period" name="larc_period" class="form-control">

                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                    foreach ($list_arr['36'] as $k => $val) {
                                                                        if(!empty($visit_arr['larc_period']) && $visit_arr['larc_period'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4"><div class="control-group">
                                                            <label class="control-label" for="larc_reason">Reason for Removal</label>
                                                            <div class="controls">
                                                                <select id="larc_reason" name="larc_reason" class="form-control">

                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                    foreach ($list_arr['37'] as $k => $val) {
                                                                        if(!empty($visit_arr['larc_reason']) && $visit_arr['larc_reason'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>



                                                </div>
                                            </div>


                                            <div class="row well services" id="ghs" style="">
                                                <div class="col-md-2">
                                                    <div><h4 class="alert alert-success">General Health Services</h4></div>

                                                </div>
                                                <div class="col-md-10 ">
                                                <!--<div class="col-md-4">
                                                <div class="control-group">
                                                <label class="control-label" for="gen_health_patient_type">Patient Adult/ Child</label>
                                                <div class="controls">                     
                                                <label class="radio-inline" for="gen_health_patient_typea">
                                                <input type="radio" name="gen_health_patient_type" id="gen_health_patient_typea" value="adult">
                                                Adult
                                                </label> 
                                                <label class="radio-inline" for="gen_health_patient_typec">
                                                <input type="radio" name="gen_health_patient_type" id="gen_health_patient_typec" value="child">
                                                Child
                                                </label> 
                                                </div>
                                                </div>
                                                </div>-->

                                                    <div class="col-md-4"><div class="control-group">
                                                            <label class="control-label" for="gen_health_category">Category of Patient</label>
                                                            <div class="controls">
                                                                <select id="gen_health_category" name="gen_health_category" class="form-control">

                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                    foreach ($list_arr['40'] as $k => $val) {
                                                                        if(!empty($visit_arr['gen_health_category']) && $visit_arr['gen_health_category'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="gen_health_diagnosis">Diagnosis</label>
                                                            <div class="controls"> 
                                                                <input id="gen_health_diagnosis" name="gen_health_diagnosis" type="text" value="<?php echo $visit_arr['gen_health_diagnosis'];?>" placeholder="" class="form-control input-md"> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="gen_health_treatment">Treatment</label>
                                                            <div class="controls"> 
                                                                <input id="gen_health_treatment" name="gen_health_treatment" type="text" value="<?php echo $visit_arr['gen_health_treatment'];?>" placeholder="" class="form-control input-md"> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="gen_health_referred_to">Referred To</label>
                                                            <div class="controls"> 
                                                                <input id="gen_health_referred_to" name="gen_health_referred_to" type="text" value="<?php echo $visit_arr['gen_health_referred_to'];?>" placeholder="" class="form-control input-md"> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row well">
                                                <div class="col-md-2">
                                                    <div><h4 class="alert alert-info">Activity Information</h4></div>
                                                </div>
                                                <div class="col-md-10 ">

                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="activity_under">Activity Done Under</label>
                                                            <div class="controls">
                                                                <select id="activity_under" name="activity_under" class="form-control">

                                                                    <option value=""> SELECT </option>
                                                                    <?php
                                                                    foreach ($list_arr['39'] as $k => $val) {
                                                                        if(!empty($visit_arr['activity_under']) && $visit_arr['activity_under'] == $val['name'] ){
                                                                            $sel = ' selected ';
                                                                        }
                                                                        else{
                                                                                $sel='';
                                                                        }
                                                                        echo ' <option '.$sel.' value="' . $val['name'] . '">' . $val['name'];
                                                                        if (!empty($val['description'])) {
                                                                            echo ' (' . $val['description'] . ')';
                                                                        }
                                                                        echo ' </option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="activity_uc">FHD Done in Union Council</label>
                                                            <div class="controls">
<!--                                                                <select id="activity_uc" name="activity_uc" class="form-control">
                                                                    <option value=""> SELECT </option>
                                                                </select>-->
                                                                
                                                                <input id="activity_uc" name="activity_uc" type="text" value="<?php echo $visit_arr['activity_uc'];?>" placeholder="" class="form-control input-md"> 
                                                            
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <label class="control-label" for="activity_num">FHD Number</label>
                                                            <div class="controls">
                                                                <select id="activity_num" name="activity_num" class="form-control">
                                                                    <option value=""> SELECT </option>
                                                                    <option value="1" <?=($visit_arr['activity_num']=='1')?'selected':''?>>1</option>
                                                                    <option value="2" <?=($visit_arr['activity_num']=='2')?'selected':''?>>2</option>
                                                                    <option value="3" <?=($visit_arr['activity_num']=='3')?'selected':''?>>3</option>
                                                                    <option value="4" <?=($visit_arr['activity_num']=='4')?'selected':''?>>4</option>
                                                                    <option value="5" <?=($visit_arr['activity_num']=='5')?'selected':''?>>5</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>



                                                </div>
                                            </div>
                                            
                                            <?php
                                            
                                            if(strtotime($min_date) <= strtotime($visit_arr['date_of_visit'])){
                                                
                                            
                                            ?>
                                            <div class="row well">
                                                <div class="col-md-2">
                                                    <div><h4 class="alert alert-info">Press Update Button to Update This Visit</h4></div>
                                                </div>
                                                <div class="col-md-10 ">

                                                    <div class="col-md-4">
                                                        <div class="control-group">
                                                            <!-- <label class="control-label" for="button1id">&nbsp;</label>-->
                                                            <div class="controls">
                                                                
                                                        <input id="visit_id" name="visit_id" type="hidden"  value="<?php echo $visit_id; ?>" > 
                                                                <button id="button1id" name="button1id" class="btn btn-success">Update</button>
                                                                <button id="button2id" name="button2id" class="btn btn-danger">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>
                                            <?php
                                            }else{
                                                     echo '<h4 class="font-red"> <i class="fa fa-exclamation-triangle"></i>ALERT !!! You can NOT Edit this Visit Information, Because Data before the date of '.date('jS M Y',strtotime($min_date)).' has been locked for this facility.</h4>';
                                       
                                            }
                                            ?>


                                        </form>


                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

    <script>
        $(document).ready(function() {
    
            var a = $("#visit_purpose").find(":selected").val();
            console.log('On Load visit_purpose:'+a);
            $(".services").hide('5000');
            $("#"+a).show('1000');
            $('html, body').animate({
                    scrollTop: $("#visit_purpose").offset().top
                }, 1000);
    
    
            $("#parity_alive,#parity_death").on("keyup change",function(e){
                var a = $('#parity_alive').val();
                var b = $('#parity_death').val();
                console.log('A:'+a);
                a = a || 0;
                b = b || 0;
                var c = parseInt(a) + parseInt(b);
                $("#parity_total").val(c);
            });  
      
            $("#fp_method").change(function(){
                var v       = $(this).val();
                var a       = $("#fp_method").find(":selected").text();
                var this_max = $("#fp_method").find(":selected").attr('max_val');
                
                console.log('V:'+v);
                console.log('A:'+a);
                console.log('this_max:'+this_max);
                
                $("#fp_method_name").val(a);
                $("#fp_qty").attr('max',this_max);
                $("#max_msg").html(this_max);
                
                //logic for additional methods
                //ecp,jadelle,implanon,NXT,Vasectomy
                if(v == '3' || v == '13' || v == '8' || v == '81' || v == '32')
                {
                    $('#additional_div').show(500);
                }else{
                    $('#additional_div').hide(500);
                }
                
            });
            
            $("#fp_qty").on("keyup change",function(e){
                var this_qty = parseInt($(this).val());
                var this_max = parseInt($(this).attr('max'));
                
                if(this_qty>this_max){
                    console.log('Cant issue greater than the limit');
                    alert('Can NOT issue this item greater than the Max Limit of '+this_max);
                    $("#fp_qty").css("background-color", "yellow");
                    $("#fp_qty").val('0');
                }
                else{
                    console.log('issuance is within limits');
                    $("#fp_qty").css("background-color", "white");
                }
            });
            
            $("#fp_category").change(function(){
                var a = $("#fp_category").find(":selected").attr('my_id');
                console.log('A:'+a);
                if(a=='815'){
                    $('#fp_method').prop('required',true);
                    $('#fp_qty').prop('required',true);
                    $(".show_for_fp_only").show(500);
                }else{
                    $(".show_for_fp_only").hide(500);
                    $('#fp_method').val('');
                    $('#fp_qty').val('');
                    $('#fp_method').prop('required',false);
                    $('#fp_qty').prop('required',false);
                     
                }
            });
    
    
            $("#fp_referred_for").change(function(){
                var a = $("#fp_referred_for").find(":selected").attr('my_id');
                console.log('A:'+a);
                if(a=='864' || a=='866'){
                    console.log('if');
                    $("#fp_reason_div").show(600);
                }else{
                    console.log('else');
                    $("#fp_reason_div").hide(600);
                }
                
            });
            
            $("#larc_method").change(function(){
                var a = $("#larc_method").find(":selected").text();
                console.log('A:'+a);
                $("#larc_method_name").val(a);
            });
            $("#visit_purpose").change(function(){
                var a = $("#visit_purpose").find(":selected").val();
                console.log('visit_purpose:'+a);
                if(a != 'fp'){
                    $('#fp_method').prop('required',false);
                    $('#fp_method_name').prop('required',false);
                }
                $(".services").hide('5000');
                $("#"+a).show('1000');
//                $("#visit_purpose").focus();
                $('html, body').animate({
                        scrollTop: $("#visit_purpose").offset().top
                    }, 1000);
                
            });
            $("#additional_item").change(function(){
                if($(this).is(":checked"))
                {
//                    console.log('ch');
                    $("#additional_item_qty").show(200);
                }else
                {
//                    console.log('noo');
                    $("#additional_item_qty").hide(200);
                }
            });
            $("#date_of_visit").change(function(){
                var a = $(this).val();
                console.log('date:'+a);
                
                $("#div_remarks").show(500);
            });
            
    
     <?php
        if(!empty($_REQUEST['update']) && $_REQUEST['update'] == 'done' ){
            echo "toastr.success('Visit Details Updated.','Saved');";
        }
        ?>
            
        });
    </script>
</body>
</html>