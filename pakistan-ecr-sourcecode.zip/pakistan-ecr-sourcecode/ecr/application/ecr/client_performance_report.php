<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;        
$from_date = date('Y-m-01');
$to_date = date('Y-m-d');

$stakeholder = $_REQUEST['stakeholder'];

if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
if (!empty($_REQUEST['to_date']))
    $to_date = $_REQUEST['to_date'];
?>
<!--<script src="--><?php //echo PUBLIC_URL; ?><!--assets/chart.min.js"></script>-->
<!--<script src="--><?php //echo PUBLIC_URL; ?><!--assets/utils.js"></script>-->
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    table.table thead .sorting_disabled, table.table thead .sorting {
        background: #2272b7 !important;
        color: #FFF !important;
    }
    
</style>
    <link rel="stylesheet" type="text/css" href="../../public/assets/global/plugins/select2/select2.css"/>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Performance Report  </h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="" id="" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">From <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $from_date ?>"   max="<?= date('Y-m-d') ?>" min="2022-10-01" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">To <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $to_date ?>"  max="<?= date('Y-m-d') ?>" min="2022-10-01"  id="to_date" name="to_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">Stakeholder</label>
                                                    <div class="controls" id="districtsCol">
                                                        <select name="stakeholder" id="stakeholder" class="input-large  select2me "  >

                                                            <?php
                                                            $qry = "SELECT
                                                                                        distinct stakeholder.stkname, 
                                                                                        stakeholder.stkid 
                                                                                FROM
                                                                                        stakeholder
                                                                                        INNER JOIN
                                                                                        tbl_warehouse
                                                                                        ON 
                                                                                                stakeholder.stkid = tbl_warehouse.stkid
                                                                                WHERE
                                                                                        tbl_warehouse.ecr_start_month is not null
                                                                                                                                                   ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            $stk_name == '';
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                $sel = '';
                                                                
                                                                if($stakeholder == $row['stkid']){
                                                                    $sel =  'selected="selected"';
                                                                    $stk_name = $row['stkname'];
                                                                }
                                                                echo "<option value=\"" . $row['stkid'] . "\" $sel>" . $row['stkname'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input name="submit" type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>
                                <?php
                                if (isset($_GET['submit'])){
                                ?>

                                    <br>
                                    <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                    <div class="table-responsive" style="overflow: auto;">
                                        <img src="../../public/images/excel-16.png" <i id="btnExport"  table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <?php
                                        $totals=array();
                                        $begin = new DateTime( $from_date );
                                        $end   = new DateTime( $to_date );
                                        $date_arr = array();
                                        for($i = $begin; $i <= $end; $i->modify('+1 day')){
                                            $this_date=$i->format("Y-m-d");
                                            $date_arr[$this_date]=$this_date;
                                        }
                                        $from_date = date('Y-m-d', strtotime($from_date));
                                        $to_date = date('Y-m-d', strtotime($to_date));

                                        //Query for Table Header
                                        $table_header_qry= "SELECT
                                                    itminfo_tab.itm_id, 
                                                    itminfo_tab.itm_name, 
                                                    itminfo_tab.generic_name, 
                                                    itminfo_tab.method_type, 
                                                    itminfo_tab.itmrec_id
                                                FROM
                                                    itminfo_tab
                                                WHERE
                                                    itminfo_tab.itm_id IN (1,2,9,3,5,7,34,81,8,13,31,32)";
//                                        echo $qry2;exit;
                                        $res2 = mysql_query($table_header_qry);
                                        $data_arr = $data_arr1 = $wh_arr = array();
                                        while ($row = mysql_fetch_assoc($res2)) {
                                            $data_arr[$row['itm_id']] = $row;
                                        }
                                            $data_arr1[] = $data_arr[1];
                                            $data_arr1[] = $data_arr[2];
                                            $data_arr1[] = $data_arr[9];
                                            $data_arr1[] = $data_arr[3];
                                            $data_arr1[] = $data_arr[5];
                                            $data_arr1[] = $data_arr[7];
                                            $data_arr1[] = $data_arr[34];
                                            $data_arr1[] = $data_arr[81];
                                            $data_arr1[] = $data_arr[8];
                                            $data_arr1[] = $data_arr[13];
                                            $data_arr1[] = $data_arr[31];
                                            $data_arr1[] = $data_arr[32];

                                            foreach ($data_arr1 as $row){
                                                $itemIds[] = $row['itm_id'];
                                                $product[$row['method_type']][] = $row['itm_name'];
                                                if (strtoupper($row['method_type']) == strtoupper($row['generic_name'])) {
                                                    $methodType[$row['method_type']]['rowspan'] = 2;
                                                } else {
                                                    $genericName[$row['generic_name']][] = $row['itm_name'];
                                                }
                                            }


                                        // Query to get Service Delivery Points
                                        $qry = "SELECT
                                                    tbl_warehouse.wh_name,
                                                    tbl_warehouse.wh_id,
                                                    ecr_client_visits.fp_method, 
                                                    count( distinct ecr_client_visits.client_id) as client_num ,
                                            tbl_locations.LocName
                                                FROM
                                                    ecr_client_visits
                                                    INNER JOIN tbl_warehouse ON ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                                    INNER JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                                                    INNER JOIN tbl_locations ON tbl_warehouse.dist_id = tbl_locations.PkLocID 
                                                WHERE
                                                    stakeholder.stkid = $stakeholder 
                                                    AND ecr_client_visits.fp_method <> 0
                                                    AND ecr_client_visits.fp_qty <> 0
                                                    AND ecr_client_visits.date_of_visit BETWEEN '$from_date' AND '$to_date'
                                            
	group by tbl_warehouse.wh_id,
	ecr_client_visits.fp_method
                                            ORDER BY tbl_locations.LocName,tbl_warehouse.wh_name";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        //Initializing Process array
                                        $data_array = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            //data processing
                                            $wh_arr[$row['wh_id']] = $row['wh_name'];
                                            $d_arr[$row['wh_id']] = $row['LocName'];
                                            $data_array[$row['wh_id']][$row['fp_method']] = $row['client_num'];
                                        }
//                                        echo '<pre>';
//                                        print_r($wh_arr);
//                                        print_r($data_array);
//                                        echo '</pre>';    
//                                        exit;
                                        $c = 1;
                                        $colspan_count = 0;
                                        foreach ($product as $proType => $proNames) {
                                            foreach ($proNames as $name) {
                                                $colspan_count++;
                                            }
                                        }

                                        echo '<table id="table_1" border="1" class="table table-bordered table-condensed">';
                                        ?>
                                        <thead>
                                        <tr class="bg-light">
                                            <th colspan="<?= ($colspan_count + 2) ?>">
                                                <div class="h4 center">
                                                    Monthly Performance Report of  Clients ( <?php echo $stk_name; ?> )
                                                    <br/>For the period : <?php echo date('dS F Y',strtotime($from_date)).' to '.date('dS F Y',strtotime($to_date));?>


                                                </div>
                                            </th>
                                        </tr>
                                        <tr class="bg-primary" style="font-size: xx-small">
                                            <th rowspan="3" class="text-center">District</th>
                                            <th rowspan="3" class="text-center">Facility</th>
                                            <?php
                                            //product
                                            foreach ($product as $proType => $proNames) {
                                                echo "<th class='text-center' colspan=" . sizeof($proNames) . " rowspan='" . (isset($methodType[$proType]['rowspan']) ? $methodType[$proType]['rowspan'] : '') . "'>$proType</th>";
                                            }
                                            ?>
                                            <th rowspan="3">Total</th>
                                        </tr>
                                        <tr class="bg-primary" style="font-size: xx-small">
                                            <?php
                                            $col = '';
                                            //generic name
                                            foreach ($genericName as $name => $proNames) {
                                                echo "<th class='text-center' colspan=" . sizeof($proNames) . ">$name</th>";
                                            }
                                            ?>
                                        </tr>
                                        <tr class="bg-primary" style="font-size: xx-small">
                                            <?php
                                            $col = '';
                                            //product
                                            foreach ($product as $proType => $proNames) {
                                                foreach ($proNames as $name) {
                                                    echo "<th class='text-center' width='" . (70 / count($itemIds)) . "%'>$name</th>";
                                                }
                                            }
                                            ?>
                                        </tr>

                                        </thead>
                                        <?php
                                        echo '<tbody>';
                                        $item_wise_total = array();
                                        foreach ($wh_arr as $wh_id => $wh_name){
                                            echo '<tr>';
                                            echo '<td class="bg-primary">'. $d_arr[$wh_id] .'</td>';
                                            echo '<td class="bg-primary">'. $wh_name .'</td>';
                                            $facility_total = 0;
                                            foreach ($itemIds as $itemId){
                                                @$facility_total += $data_array[$wh_id][$itemId];
                                                @$item_wise_total[$itemId] += $data_array[$wh_id][$itemId];
                                                echo '<td align="right">'. ((isset($data_array[$wh_id][$itemId]))?$data_array[$wh_id][$itemId]:0) .'</td>';
                                            }
                                            echo '<td class="bg-primary">'. $facility_total .'</td>';
                                            echo '</tr>';
                                        }
                                        echo '</tbody>';
                                        echo '<tfoot>';
                                        echo '<tr class="bg-primary">';
                                        echo '<td colspan="2" class="text-center">Total</td>';
                                        foreach ($itemIds as $itemId) {
                                            echo '<td> '. $item_wise_total[$itemId] .' </td>';
                                        }
                                        echo '<td class="text-center"> - </td>';
                                        echo '<tr>';
                                        echo '</tfoot>';
                                        echo '</table>';
                                        ?>
                                    </div>
                                    </div>
                                </div>

                                <?php
                                }
                                ?>
                            
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
<?php
include PUBLIC_PATH . "/html/footer.php";
?>


    <script type="text/javascript" src="../../public/assets/global/plugins/select2/select2.min.js"></script>

</body>
</html>