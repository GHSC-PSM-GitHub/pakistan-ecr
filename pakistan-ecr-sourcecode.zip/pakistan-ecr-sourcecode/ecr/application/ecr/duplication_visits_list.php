<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Possible Duplicate Visits </h3>
                            </div>
                            <div class="widget-body">
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        
                                        $qry = "
                                        select ecr_client_visits.* 
                                        from ecr_client_visits
                                        order by client_id , date_of_visit,visit_purpose
limit 3000
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr =$date_arr = $client_id_arr=$client_id_arr2= $count_arr= array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            if($row['visit_purpose'] == '') continue;
                                            @$client_id_arr[$row['client_id']] +=1;
                                            @$client_id_arr2[$row['client_id']]['cid'] =$row['client_id'];
                                            @$client_id_arr2[$row['client_id']]['cnt'] +=1;
                                            @$date_arr[$row['date_of_visit']] +=1;
                                            @$count_arr[$row['client_id']][$row['date_of_visit']][$row['visit_purpose']] +=1;
                                            @$data_arr[$row['client_id']][$row['date_of_visit']][$row['visit_purpose']][$row['pk_id']] = $row;
                                        }
//                                        echo '<pre>';
////                                        print_r($date_arr);
//                                        print_r($client_id_arr);
////                                        print_r($count_arr);
//                                        echo '</pre>';    

                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                            echo '<tr>';
                                            echo '<td>#</td>';
                                            echo '<td>Client ID</td>';
                                            echo '<td>Date of Visit</td>';
                                            echo '<td>Purpose of Visit</td>';
                                            echo '<td>No of Visits</td>';
                                            echo '<td>Action</td>';
                                            echo '</tr>';
                                              
                                        function sortByOrder($a, $b) {
                                            if ($a['cnt'] < $b['cnt']) {
                                                return 1;
                                            } elseif ($a['cnt'] > $b['cnt']) {
                                                return -1;
                                            }
                                            return 0;
                                        }

                                        usort($client_id_arr2, 'sortByOrder');
//                                    echo '<pre>';
//                                    print_r($client_id_arr2);
//                                    echo '</pre>';
//                                    exit;    
                                            
                                        foreach ($client_id_arr2 as $k => $cdata ) {
                                            $cid = $cdata['cid'];
                                            $c_count = $cdata['cnt'];
                                            
                                            if($c_count <= 1)
                                            {
                                                continue;
                                            }
                                            
                                            foreach($count_arr[$cid] as $date => $d_obj )
                                            {
                                                foreach($d_obj as $purpose => $p_count )
                                                {
                                                    if($p_count <= 1)
                                                    {
                                                        continue;
                                                    }


                                                echo '<tr>';
                                                echo '<td>' . $c++ . '</td>';
                                                echo '<td>' . $cid . '</td>';
                                                echo '<td>' . $date . '</td>';
                                                echo '<td>' . $purpose . '</td>';
                                                echo '<td><span class="badge badge-error">' . $p_count . '</span></td>';
                                                echo '<td>';
                                                echo '<a target="_blank" href="view_multi_visits.php?ids=';
                                                foreach($data_arr[$cid][$date][$purpose] as $pkid => $row){ 
                                                    echo $pkid.',';
                                                } 
                                                echo'" >View Details </a>';
                                                echo'</td>';
    //                                            echo '<td>' . $visits['visits'] . '</td>';
    //                                            echo '<td> <a class="btn btn-xs btn-success" href="duplication_view.php?param=cnic&value='.$obj['cnic'].'">View</a> ';
    //                                            echo ' <a target="_blank" class="btn btn-xs btn-warning" href="merge.php?param=cnic&value='.$obj['cnic'].'">Merge</a> ';
    //                                            echo '</td>';
                                                echo '</tr>';
                                                }   
                                            
                                            }
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>