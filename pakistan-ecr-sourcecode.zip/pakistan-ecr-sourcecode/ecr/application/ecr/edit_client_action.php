<?php

include("../includes/classes/AllClasses.php");

$client_id = $_POST['client_id'];
if(!empty($client_id)){
    
    $qry = " SELECT *  FROM ecr_clients where ecr_clients.pk_id = '".$client_id."'  ";
    $qryRes = mysql_query($qry);
    $client_data  =array();
    $row = mysql_fetch_assoc($qryRes);
    $client_data = $row;
   
     if(!( (!empty($client_data['registered_at']) && $client_data['registered_at']==$_SESSION['user_warehouse'] ) || $_SESSION['user_id'] == '9744' ))
    {
        ////access denied
        echo 'Un-Authorized Access. You do NOT have authorization for this action. !';
        exit;
         
     }
     
    $crc_new_old = $_POST['crc_new_old'];
    $crc_number = $_POST['crc_number'];
    $client_name = $_POST['client_name'];
    $father_name = $_POST['father_name'];
    $address = $_POST['address'];
    $catchment_area = $_POST['catchment_area'];
    $contact_number = $_POST['contact_number'];
    $cnic = $_POST['cnic'];
    $nationality = $_REQUEST['nationality'];
    $foreigner_identity = $_REQUEST['foreigner_identity'];
    $occupation = $_POST['occupation'];
    $education = $_POST['education'];
    $age_today = $_POST['age_today'];
    $age_when_married = $_POST['age_when_married'];
    $wh_id  = $_SESSION['user_warehouse']; 
    $date_of_visit = $_POST['date_of_visit'];

    
    if(!isset($cnic) || $cnic == '' || $cnic == '0' || (int)$cnic == '0'){
        // force override 00000-0000000-0
        $cnic = '00000-0000000-0';
    }
    $temp_cnic = explode('-',$cnic);
    @$comb_cnic = $temp_cnic[0].$temp_cnic[1].$temp_cnic[2];
    $formatted_cnic = substr($comb_cnic,0,5).'-'.substr($comb_cnic,5,7).'-'.substr($comb_cnic,12,1);

    
    if(!empty($nationality) && $nationality != 'pakistani'){
        $formatted_cnic='';
    }
    
    $strSql = " UPDATE ecr_clients SET ";
    $strSql .= "  `crc_new_old`='".$crc_new_old."',`crc_number`='".$crc_number."', `client_name`='".$client_name."', ";
    $strSql .= "  `father_name`='".$father_name."', `address`='".$address."', `catchment_area`='".$catchment_area."', ";
    $strSql .= "  `contact_number`='".$contact_number."', `cnic`='".$formatted_cnic."', `occupation`='".$occupation."', ";
    $strSql .= "   `foreigner_identity`='".$foreigner_identity."',`nationality`='".$nationality."', ";
    $strSql .= "  `education`='".$education."', `age_today`='".$age_today."', `age_when_married`='".$age_when_married."', `created_on`='".$date_of_visit."' ";
    $strSql .= "   WHERE pk_id = '".$client_id."' ;";
//    echo $strSql;exit;
    $rsSql = mysql_query($strSql) or die("ERROR in updating data");
    
    
    $strSql2 = " INSERT INTO ecr_clients_log SET ";
    $strSql2 .= "  `crc_new_old`='".$crc_new_old."',`crc_number`='".$crc_number."', `client_name`='".$client_name."', ";
    $strSql2 .= "  `father_name`='".$father_name."', `address`='".$address."', `catchment_area`='".$catchment_area."', ";
    $strSql2 .= "  `contact_number`='".$contact_number."', `cnic`='".$formatted_cnic."', `occupation`='".$occupation."', ";
    $strSql2 .= "   `foreigner_identity`='".$foreigner_identity."',`nationality`='".$nationality."', ";
    $strSql2 .= "  `education`='".$education."', `age_today`='".$age_today."', `age_when_married`='".$age_when_married."', `created_on`='".$date_of_visit."', ";
    $strSql2 .= "   client_id = '".$client_id."',user_id='".$_SESSION['user_id']."' ;";
//    echo $strSql2;exit;
    $rsSql = mysql_query($strSql2) or die($strSql2."ERROR in inserting log");
    
    
    header("location:edit_client.php?update=done&client_id=".$client_id);
}
exit;
?>