<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";




$qry = "SELECT
                list_detail.pk_id,
                list_detail.list_value,
                list_detail.description,
                list_detail.rank,
                list_detail.reference_id,
                list_detail.parent_id,
                list_detail.list_master_id
            FROM
                list_detail
            ORDER BY
                list_detail.rank ,
                list_detail.list_value ASC
        ";
$qryRes = mysql_query($qry);
$list_arr = array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $list_arr[$row['list_master_id']][$row['pk_id']]['name'] = $row['list_value'];
    $list_arr[$row['list_master_id']][$row['pk_id']]['description'] = $row['description'];
}
//echo '<pre>';
//print_r($list_arr);
//echo '</pre>';
//exit;

$sr_no = '';

$cnt = 0;
//$qry = " SELECT count(*) as cnt FROM ecr_clients WHERE  registered_at = '" . $_SESSION['user_warehouse'] . "' ";
$qry = " SELECT max(pk_id) as cnt  FROM ecr_clients  ";
$qryRes = mysql_query($qry);
while ($row = mysql_fetch_assoc($qryRes)) {
    $cnt = $row['cnt'];
}
$cnt = $cnt + 1;
$sr_no = $_SESSION['user_warehouse'] . '-' . date('Ym') . '-' . $cnt;

//Todo:
//increment in serial number
//include warehouse in client table
// create readonly view for visits
// create edit for clients 
// create edit for visits

?>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content">
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                            ?>
                                <a class="btn btn-info pull-right" download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                            <?php
                            }
                            ?>
                            
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Register A New Client</h3>
                            </div>
                            <div class="widget-body">
                                <form method="POST" name="add_client" id="add_client" action="add_client_action.php">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <?php
                                if(!empty($_REQUEST['show_msg']) && !empty($msg_array[$_REQUEST['show_msg']]['txt'])) {
                                    if(!empty($msg_array[$_REQUEST['show_msg']]['cls'])){
                                        $cls = $msg_array[$_REQUEST['show_msg']]['cls'];
                                    }else{
                                        $cls='success';
                                    }
                                echo '<div class="col-md-12 col-lg-12">
                                            <div class="note note-'.$cls.'" >'.$msg_array[$_REQUEST['show_msg']]['txt'].'<i class="fa fa-check font-green"></i></div>  
                                    </div>';
                                }
                            ?>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="textinput">Computerized Registration Number / Serial Number </label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-laptop"></i>
                                                            </span>
                                                            <input id="serial_number" name="serial_number" type="text" value="<?php echo $sr_no; ?>" style="background-color:#ccc" readonly class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-4">

                                                <div class="control-group">
                                                    <label class="control-label" for="crc_new_oldn">Identity of client <span class="red">*</span></label>
                                                    <div class="controls">
                                                        <label class="radio-inline" for="nationality_pak">
                                                            <input type="radio" name="nationality" id="nationality_pak" value="pakistani" checked="checked">
                                                            Pakistani
                                                        </label>
                                                        <label class="radio-inline" for="nationality_o">
                                                            <input type="radio" name="nationality" id="nationality_o" value="other">
                                                            Other
                                                        </label>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4" id="cnic_div">
                                                <div class="control-group">
                                                    <label class="control-label required" for="textinput">CNIC Number (of client / husband / father) <span class="red">*</span></label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="cnic" name="cnic" required type="text" pattern="^\d{5}-\d{7}-\d{1}|\d{13}$" placeholder="00000-0000000-0 OR 0000000000000" maxlength="15" step="1" autocomplete="off" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4" id="foreigner_div" style="display:none;">
                                                <div class="control-group">
                                                    <label class="control-label required" for="textinput">Identification Number for other nationals<span class="red">*</span></label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="foreigner_identity" name="foreigner_identity" type="text" placeholder="ID card number / passport number " autocomplete="off" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="textinput">Date of Registration</label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-calendar"></i>
                                                            </span>
                                                        <input type="date"  onkeydown="return false"  required value="<?= date('Y-m-d') ?>" min="<?=(!empty($min_date)?date('Y-m-d',strtotime($min_date)):'2022-10-01')?>" max="<?= date('Y-m-d') ?>" id="date_of_visit" name="date_of_visit" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">

                                                <div class="control-group">
                                                    <label class="control-label" for="crc_new_oldn">CRC Old / New </label>
                                                    <div class="controls">
                                                        <label class="radio-inline" for="crc_new_oldn">
                                                            <input type="radio" name="crc_new_old" id="crc_new_oldn" value="new" checked="checked">
                                                            New
                                                        </label>
                                                        <label class="radio-inline" for="crc_new_oldo">
                                                            <input type="radio" name="crc_new_old" id="crc_new_oldo" value="old">
                                                            Old
                                                        </label>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">

                                                <div class="control-group">
                                                    <label class="control-label" for="crc_number">CRC Number <span class="red">*</span></label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="crc_number" required name="crc_number" type="text" placeholder="CRC Number Mentioned on Register" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="textinput">Clients Name <span class="red">*</span> </label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="client_name" required name="client_name" type="text" placeholder="Full Name of Client" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="textinput">Husband/Father Name <span class="red">*</span></label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="father_name" required name="father_name" type="text" placeholder="Name of Father or Husband" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="textarea">Complete Address (with landmark)</label>
                                                    <div class="controls">
                                                        <textarea class="form-control" id="address" name="address" placeholder="Complete Address (with landmark)"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">

                                                <div class="control-group">
                                                    <label class="control-label" for="radios">Catchment Area</label>
                                                    <div class="controls">
                                                        <label class="radio-inline" for="catchment_areau">
                                                            <input type="radio" name="catchment_area" id="catchment_areau" value="urban" checked="checked">
                                                            Urban
                                                        </label>
                                                        <label class="radio-inline" for="catchment_arear">
                                                            <input type="radio" name="catchment_area" id="catchment_arear" value="rural">
                                                            Rural
                                                        </label>
                                                        <label class="radio-inline" for="catchment_areas">
                                                            <input type="radio" name="catchment_area" id="catchment_areas" value="slum">
                                                            Slum
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label required" for="textinput">Contact Number (of client / husband / father) <span class="red">*</span></label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="contact_number" required name="contact_number" type="text" pattern="^\d{4}-\d{7}|\d{11}$" placeholder="03xxxxxxxxx (11 digits)" maxlength="11" step="1" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="selectbasic">Occupation of Client / Head of household</label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <select id="occupation" name="occupation" class="form-control">

                                                                <?php

                                                                foreach ($list_arr['32'] as $k => $val) {
                                                                    echo ' <option value="' . $val['name'] . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                }

                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="selectbasic">Education of Client</label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <select id="education" name="education" class="form-control">

                                                                <?php

                                                                foreach ($list_arr['33'] as $k => $val) {
                                                                    echo ' <option value="' . $val['name'] . '">' . $val['name'] . ' (' . $val['description'] . ')</option>';
                                                                }

                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="textinput">Age( Years )</label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="age_today" name="age_today" type="number" min="1" max="99" step="1" placeholder="Age as of Today in Years" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="textinput">Years of Marriage</label>
                                                    <div class="controls">
                                                        <div class="input-group">
                                                            <span class="input-group-addon input-circle-left  bg-blue-madison">
                                                                <i class="fa fa-tag"></i>
                                                            </span>
                                                            <input id="age_when_married" name="age_when_married" type="number" min="0" max="99" step="1" placeholder="Years of Marriage" class="form-control input-md">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="control-group">
                                                    <label class="control-label" for="button1id">&nbsp;</label>
                                                    <div class="controls">
                                                        <button id="button1id" type="submit" name="save_n_add_visit" class="btn btn-success">Save Registration & Add Visit</button>
                                                        <button id="button1id" type="submit" name="save_only" class="btn btn-warning">Only Register</button>
                                                        <input class="btn btn-danger" type="reset">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <span class="note note-warning">Note: Before registering a new client, please check if it already exists, by searching in the search page.</span>
                <span class="note note-info">Note: If Contact Number and CNIC Number are not available, then enter Zero (0) to proceed.</span>

            </div>
        </div>
        <!-- // Content END -->

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

    <script>
        $(document).ready(function() {

             console.log('rdy');
            $("input[type=radio][name=nationality]").change(function() {
                var thisval = $(this).val();
                console.log('Nationality changed:'+thisval);
                if(thisval == 'pakistani'){
                    $("#foreigner_div").hide('200');
                    $("#cnic_div").show('300');
                    $("#cnic").focus();
                    $('#foreigner_identity').prop('required',false);
                    $('#cnic').prop('required',true);
                }
                else{
                    
                    $("#cnic_div").hide('200');
                    $("#foreigner_div").show('300');
                    $("#foreigner_identity").focus();
                    $('#foreigner_identity').prop('required',true);
                    $('#cnic').prop('required',false);
                }
            });
            $("#contact_number").change(function() {
                var thisval = $(this).val();
                console.log('contact_number:'+thisval);
                if (thisval == '0000-0000000' || thisval == '0' || parseInt(thisval) == '0') {
                    $("#contact_number").css('background-color', '#aff7ac');
                    $("#contact_number").val('00000000000');
                }
                else{
                    var phone_regex = new RegExp('[0-9]{4}[0-9]{7}');
                    var phone_regex2 = new RegExp('[0-9]{4}-[0-9]{7}');

                    if (phone_regex.test(thisval)) {
                        console.log('valid contact pattern 1');
                        $("#contact_number").css('background-color', '#aff7ac');
                    }else if (phone_regex2.test(thisval)) {
                        console.log('valid contact pattern 2');
                        $("#contact_number").css('background-color', '#aff7ac');
                    }else{
                        console.log('invalid contact');
                        $("#contact_number").css('background-color', '#f9f952');
                        $("#contact_number").val('');
                        toastr.error('Please enter the valid contact number in this format : 0300-0000000','Wrong Format');
                    }
                }
            });
            $("#cnic").change(function() {
                var thisval = $(this).val();
                console.log(thisval);
                if (thisval == '00000-0000000-0' || thisval == '0000000000000' || thisval == '0' || parseInt(thisval) == '0') {
                    console.log('Green ');
                    $("#cnic").css('background-color', '#aff7ac');
                    $("#cnic").val('00000-0000000-0');
                } else {
                    $.ajax({
                        url: "check_unique_cnic.php?cnic=" + thisval,
                        success: function(result) {
                            console.log(result);
                            console.log(result.exists);
                            if (result.exists == 'yes') {
                                console.log('RED');
                                $("#cnic").css('background-color', '#ffc9c9');
                                $("#cnic").val('');
                                toastr.error('Patient having this CNIC number ' + thisval + ' already exists. Go to Client Search page and search with this CNIC.','Duplicate CNIC');
                                alert('Patient having this CNIC number ' + thisval + ' already exists. Go to Client Search page and search with this CNIC.');
                                $("#cnic").focus();
                            } else {
                                if (result.format == 'wrong_format') {

                                    console.log('Yellow ');
                                    toastr.error('Please enter the valid CNIC number in this format : 00000-0000000-0 OR 0000000000000','Wrong CNIC Format');
                                    $("#cnic").css('background-color', '#f9f952');
                                    $("#cnic").val('');
                                    $("#cnic").focus();
                                } else {
                                    console.log('Green ');
                                    $("#cnic").css('background-color', '#aff7ac');
                                }
                            }
                        }
                    });
                }
            });
     
     <?php
        if(!empty($_REQUEST['show_msg']) && !empty($msg_array[$_REQUEST['show_msg']]['txt'])) {
            if(!empty($msg_array[$_REQUEST['show_msg']]['cls'])){
                $cls = $msg_array[$_REQUEST['show_msg']]['cls'];
            }else{
                $cls='success';
            }
            echo "toastr.".$cls."('".$msg_array[$_REQUEST['show_msg']]['txt']."');";
        }
        ?>
        });
    </script>
</body>

</html>