<?php

include("../includes/classes/AllClasses.php");

//echo '<pre>';
//print_r($_REQUEST);
//echo '</pre>';
//exit;
$serial_number = $_REQUEST['serial_number'];
$crc_new_old = strtolower($_REQUEST['crc_new_old']);
$crc_number = $_REQUEST['crc_number'];
$client_name = $_REQUEST['client_name'];
$father_name = $_REQUEST['father_name'];
$address = $_REQUEST['address'];
$catchment_area = strtolower($_REQUEST['catchment_area']);
$contact_number = $_REQUEST['contact_number'];
$cnic = $_REQUEST['cnic'];
$nationality = $_REQUEST['nationality'];
$foreigner_identity = $_REQUEST['foreigner_identity'];
$occupation = $_REQUEST['occupation'];
$education = $_REQUEST['education'];
$age_today = $_REQUEST['age_today'];
$age_when_married = $_REQUEST['age_when_married'];
@$parity_alive = $_REQUEST['parity_alive'];
@$parity_death = $_REQUEST['parity_death'];
$created_on = $_REQUEST['date_of_visit']; /// date of registration
$wh_id  = $_SESSION['user_warehouse'];

if(!isset($cnic) || $cnic == '' || $cnic == '0' || (int)$cnic == '0'){
    // force override 00000-0000000-0
    $cnic = '00000-0000000-0';
}
$temp_cnic = explode('-',$cnic);
@$comb_cnic = $temp_cnic[0].$temp_cnic[1].$temp_cnic[2];
$formatted_cnic = substr($comb_cnic,0,5).'-'.substr($comb_cnic,5,7).'-'.substr($comb_cnic,12,1);

if(!empty($nationality) && $nationality != 'pakistani'){
    $formatted_cnic='';
}

$qry = " SELECT pk_id   FROM ecr_clients where serial_number = '".$serial_number."'  ";
$qryRes = mysql_query($qry);
$duplicate_serial = false;
while ($row = mysql_fetch_assoc($qryRes)) {
    $pk_id = $row['pk_id'];
}

if(!empty($pk_id) && $pk_id > 0){
    $duplicate_serial = true;
}


$qry = " SELECT * FROM ecr_clients where client_name = '".$client_name."' 
    and father_name = '".$father_name."' 
        and cnic = '".$formatted_cnic."' and  contact_number = '".$contact_number."' and address = '".$address."' ";
$qryRes = mysql_query($qry);
$client_data=array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $client_data = $row;
}
if(!empty($client_data['pk_id']) && $client_data['pk_id'] > 0){
    /// client info already exists
    $new_id = $client_data['pk_id'];
    
    if(!empty($new_id)){
        header("location:add_visit.php?client_id=".$new_id."&msg=already_existed");
    }
    exit;
}
else{
    /// register this client

    $strSql = " INSERT INTO ecr_clients (`serial_number`, `crc_new_old`,`crc_number`, `client_name`, ";
    $strSql .= "  `father_name`, `address`, `catchment_area`, ";
    $strSql .= "  `contact_number`, `cnic`,`nationality`,`foreigner_identity`, `occupation`, ";
    $strSql .= "  `education`, `age_today`, `age_when_married`, `parity_alive`, `parity_death`,`registered_at`,user_id, created_on) ";
    $strSql .= " VALUES ('".$serial_number."','".$crc_new_old."','".$crc_number."','".$client_name."', ";
    $strSql .= "  '".$father_name."','".$address."','".$catchment_area."', ";
    $strSql .= "  '".$contact_number."','".$formatted_cnic."','".$nationality."','".$foreigner_identity."','".$occupation."', ";
    $strSql .= "  '".$education."','".$age_today."','".$age_when_married."','".$parity_alive."','".$parity_death."','".$wh_id."','".$_SESSION['user_id']."','".$created_on."');";
//    echo $strSql;exit;
    $rsSql = mysql_query($strSql) or die("ERROR in saving data");
    $new_id = mysql_insert_id();

    /////////////if serial number is duplicate

    $temp_serial = explode('-',$serial_number);
    $serial_number = $temp_serial[0].'-'.$temp_serial[1].'-'.$new_id;

    $qry = " UPDATE  ecr_clients SET serial_number = '".$serial_number."' WHERE pk_id = '".$new_id."'; ";
    $qryRes = mysql_query($qry);
    //////////////////

    if(!empty($new_id)){
        if(isset($_REQUEST['save_only'])){
            header("location:add_client.php?show_msg=client_added");
        }

        if(isset($_REQUEST['save_n_add_visit'])){
            header("location:add_visit.php?client_id=".$new_id."&show_msg=client_added");
        }
    }
    exit;
}


?>