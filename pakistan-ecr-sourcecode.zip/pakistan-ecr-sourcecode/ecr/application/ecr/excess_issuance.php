<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Possible Excess Issuance </h3>
                            </div>
                            <div class="widget-body">

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - COC
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 9
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 12
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - POP
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 2
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 12
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - ECP
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 3
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 8
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - Sayana Pres
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 34
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 3
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - Depo 3Month Injection
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 7
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 4
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - Copper T
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 5
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 1
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - Jadelle
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 13
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 1
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - Tubal ligation ( CS for Female )
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 31
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 1
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-head bg-info">
                                        Possible Excess Issuance - Vasectomy ( CS for Male )
                                    </div>
                                    <div class="panel-body">
                                        <?php
                                        $qry = "
                                        SELECT
	ecr_client_visits.client_id,
	ecr_clients.serial_number, 
	ecr_clients.client_name, 
	ecr_clients.father_name, 
	ecr_clients.cnic, 
	ecr_clients.contact_number, 
	ecr_clients.address, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name, 
	sum(ecr_client_visits.fp_qty) as cnt
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
WHERE
	fp_method = 32
GROUP BY
	ecr_client_visits.client_id, 
	ecr_client_visits.fp_method, 
	ecr_client_visits.fp_method_name
HAVING
	sum(ecr_client_visits.fp_qty) > 1
	order by sum(ecr_client_visits.fp_qty)  desc 
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td>Serial Number</td>';
                                        echo '<td>Name</td>';
                                        echo '<td>F/H Name</td>';
                                        echo '<td>CNIC</td>';
                                        echo '<td>Contact</td>';
                                        echo '<td>Registered At</td>';
                                        echo '<td>Item</td>';
                                        echo '<td>Total Issued</td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {

                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['client_name'] . '</td>';
                                            echo '<td>' . $obj['father_name'] . '</td>';
                                            echo '<td>' . ($obj['cnic'] == '00000-0000000-0' ? '' : $obj['cnic']) . '</td>';
                                            echo '<td>' . ($obj['contact_number'] == '00000000000' ? '' : $obj['contact_number']) . '</td>';
                                            echo '<td>' . $obj['wh_name'] . '</td>';
                                            echo '<td>' . $obj['fp_method_name'] . '</td>';
                                            echo '<td><span class="badge badge-danger">' . $obj['cnt'] . '</span></td>';
                                            echo '<td><a target="_blank" class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $obj['client_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a></td>';

                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>