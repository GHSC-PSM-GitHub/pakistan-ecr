<?php
include("../includes/classes/AllClasses.php");
$stakeholder = $_POST['stk'];
?>
<?='<select name="district" id="district" class="form-control " onchange="change_dist()" >'?>
    <?php
if ($_SESSION['user_level'] == 1){
    $prov_helper = " IN (2,4) ";
}
else{
    $prov_helper = " = '". $_SESSION['user_province1']. "'";
}
if ($stakeholder == 1){
    $lvl_helper = " AND lvl = 3";
}
else{
    $lvl_helper = "";
}
    $qry = "SELECT
                distinct PkLocID,
                LocName
            FROM
                    tbl_locations

            INNER JOIN
            tbl_warehouse
            ON
                    tbl_locations.PkLocID = tbl_warehouse.dist_id
            
            INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid 
            WHERE
                    tbl_locations.ParentID $prov_helper AND LocLvl = '3' AND
            tbl_warehouse.stkid = $stakeholder $lvl_helper
            ORDER BY
                LocName";
    $rsfd = mysql_query($qry) or die(mysql_error());
    while ($row = mysql_fetch_array($rsfd)) {
        if ($_SESSION['user_level'] > '2' && !empty($_SESSION['user_district'])) {
            $district = $_SESSION['user_district'];
            if ($row['PkLocID'] != $_SESSION['user_district'])
                continue;
        }
        $sel = ($_REQUEST['district'] == $row['PkLocID']) ? 'selected="selected"' : '';
        echo "<option value=\"" . $row['PkLocID'] . "\" $sel>" . $row['LocName'] . "</option>";
    }
    ?>
<?='</select>'?>