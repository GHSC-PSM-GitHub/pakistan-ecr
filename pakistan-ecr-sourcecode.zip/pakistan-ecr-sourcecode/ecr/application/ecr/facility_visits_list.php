<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
$from_date = date('Y-m-d');

@$fac_id = $_REQUEST['fac_id'];
@$item_id = $_REQUEST['item_id'];
@$purpose = $_REQUEST['purpose'];

if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Facility visits listing  </h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">Date <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $from_date ?>"   max="<?= date('Y-m-d') ?>" min="2022-10-01" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="widget-body">
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <h4>Visits Recorded on <?php echo date('d-M-Y', strtotime($from_date)); ?></h4>
                                        <?php


                                        $qry = 'SELECT
                                                            ecr_client_visits.*,
                                                            ecr_clients.serial_number,
                                                            ecr_clients.client_name,
                                                            ecr_clients.father_name,
                                                            ecr_clients.contact_number,
                                                            ecr_clients.cnic,
                                                            tbl_warehouse.wh_name
                                                    FROM
                                                            ecr_client_visits
                                                    INNER JOIN tbl_warehouse ON ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                                    INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
                                                    WHERE  DATE_FORMAT(date_of_visit,\'%Y-%m-%d\') = "' . $from_date . '" 
                                                         ';

                                        if (!empty($fac_id)) {
                                            $qry .= " and tbl_warehouse.wh_id = '".$fac_id."' ";
                                        }
                                        if (!empty($item_id)) {
                                            $qry .= " and (fp_method = '".$item_id."' OR additional_item = '".$item_id."') ";
                                        }
                                        if (!empty($purpose)) {
                                            $qry .= " and visit_purpose = '".$purpose."' ";
                                        }
                                        $qry .= " ORDER BY visit_purpose,fp_method_name,client_name";
//                                            echo $qry;exit;
                                        $res = mysql_query($qry);
                                        while ($row = mysql_fetch_assoc($res)) {

                                            @$visits_arr[$row['pk_id']] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr class="info">';
                                        echo ' 
                                                <th>#</th>
                                                <th>Facility</th>
                                                <th>Registration No.</th>
                                                <th>Clients Name</th>
                                                <th>Husband/Father Name</th>
                                                <th>Contact No.</th>
                                                <th>Purpose of Visit</th>
                                                <th>Category</th>
                                                <th>FP Method</th>
                                                <th>Qty</th>
                                                <th>Additional RC</th>
                                               
                                                
                                            ';
                                        echo '</tr>';
                                        foreach ($visits_arr as $pk_id => $v) {
                                            echo '<tr>';
                                            echo '<td title="visit_id:'.$v['pk_id'].'">' . $c++ . '</td>';
                                            echo '<td>' . $v['wh_name'] . '</td>';
                                            echo '<td>' . $v['serial_number'] . '</td>';
                                            echo '<td>' . $v['client_name'] . '</td>';
                                            echo '<td>' . $v['father_name'] . '</td>';
                                            echo '<td>' . $v['contact_number'] . '</td>';
                                            echo '<td>' . strtoupper(str_replace('_',' ',$v['visit_purpose'])) . '</td>';
                                            if($v['visit_purpose']=='fp'){
                                                echo '<td>' . ucfirst($v['fp_category']) . '</td>';
                                            }elseif($v['visit_purpose']=='ghs'){
                                                echo '<td>' . ucfirst($v['gen_health_category']) . '</td>';
                                            }elseif($v['visit_purpose']=='larc_removal'){
                                                echo '<td>Method:' . ucfirst($v['larc_method_name']) . '</td>';
                                            }
                                            echo '<td>' . $v['fp_method_name'] . '</td>';
                                            echo '<td>' . $v['fp_qty'] . '</td>';
                                            echo '<td>' . $v['additional_item_qty'] . '</td>';
                                            echo '</tr>';
                                        }

                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>



                            </div>

                        </div>


                    </div>
                </div>

            </div>
        </div>

    </div>
    <!-- // Content END --> 

    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>