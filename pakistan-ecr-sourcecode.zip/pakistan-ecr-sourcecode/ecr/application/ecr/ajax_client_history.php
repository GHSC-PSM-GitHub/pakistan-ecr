<?php
include("../includes/classes/AllClasses.php");
include "ecr_common.php";
$id = $_REQUEST['client_id'];
if(!empty($id))
{

$qry = "SELECT * FROM
                    ecr_client_visits
                WHERE 
                    client_id = '" . $id . "'
                        ORDER BY date_of_visit desc,pk_id desc
            ";
//echo $qry;exit;
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $visit_arr[] = $row;
    }
//    echo '<pre>';
//print_r($visit_arr);
//echo '</pre>';
//exit;
    
$cls_arr = array();    
$cls_arr['fp'] = 'green';    
$cls_arr['ghs'] = 'yellow';    
$cls_arr['larc'] = 'blue';    
?>
<ul class="timeline">
    <?php
foreach ($visit_arr as $k =>  $row) {
    if($row['visit_purpose']=='larc_removal')$row['visit_purpose']='larc';
    
echo '<li class="timeline-'.$cls_arr[$row['visit_purpose']].'">
        <div class="timeline-time">
            <span class="date">
                '.$row['date_of_visit'].' </span>
            <span class="time">
               '.  strtoupper(str_replace('_', '', $row['visit_purpose'])).'</span>
        </div>
        <div class="timeline-icon">
            <i class="fa fa-user"></i>
        </div>
        <div class="timeline-body">
            <h2 style="font:red">'.ucfirst($row['wh_name']).'</h2>
            <div class="timeline-content">
                <i class="fa fa-file-text-o"></i>';
if($row['visit_purpose'] == 'fp'){
echo            ''.(!empty($row['fp_category'])?'<br/><i class="fa fa-arrow-right"></i><b><u>FP Category:</u></b>'.$row['fp_category']:'');

if(!empty($row['type_of_visit'])){
    $type_of_visit_name='';
    if( $row['type_of_visit']=='1'){
        $type_of_visit_name='Issuance / Procedure';
    }
    if( $row['type_of_visit']=='2'){
        $type_of_visit_name='Referral to other facility';
    }


    echo '<br/><i class="fa fa-arrow-right"></i><b><u>Type of Visit:</u></b>'.$type_of_visit_name;
}
echo            (!empty($row['fp_method_name'])?'<br/><i class="fa fa-arrow-right"></i><b><u>Method:</u></b>'.$row['fp_method_name']:'').'
                '.(!empty($row['fp_qty'])?'<br/><i class="fa fa-arrow-right"></i><b><u>Issued:</u></b>'.$row['fp_qty']:'').'
                '.(!empty($row['additional_item_qty'])?'<br/><b><u>Additional RC:</u></b>'.$row['additional_item_qty']:'').'';
}
if($row['visit_purpose'] == 'ghs'){
echo            ''.(!empty($row['gen_health_category'])?'<br/><i class="fa fa-arrow-right"></i><b><u>GHS Category:</u></b>'.$row['gen_health_category']:'').'
                ';
}
if($row['visit_purpose'] == 'larc'){
echo            ''.(!empty($row['larc_method_name'])?'<br/><i class="fa fa-arrow-right"></i><b><u>Larc Method:</u></b>'.$row['larc_method_name']:'').'';
}
echo            ''.(!empty($row['activity_under'])?'<br/><i class="fa fa-arrow-right"></i><b><u>Activity Under:</u></b>'.$row['activity_under']:'').'';
echo            ''.(!empty($row['last_updated'])?'<br/><i class="fa fa-arrow-right"></i><b><u>Reported On :</u></b>'.$row['last_updated']:'').'';
echo            '
            </div>
            <div class="timeline-footer">
                <a target="_blank" href="view_visit.php?visit_id='.$row['pk_id'].'" style="color:white">
                    View Details <i class="m-icon-swapright m-icon-white"></i>
                </a>
            </div>
        </div>
    </li>';
    
}

?>
</ul>

<?php
}
else{
    echo 'Invalid Request';
}
?>
