<?php

include("../includes/classes/AllClasses.php");
include "ecr_common.php";



$visit_id = $_REQUEST['visit_id'];
$client_id = $_REQUEST['client_id'];

 $qry = "SELECT * FROM
                    ecr_client_visits
                WHERE 
                    pk_id = '" . $visit_id . "'
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $visit_arr = $row;
    }

//echo '<pre>';
////print_r($_REQUEST);
//print_r($visit_arr);
////print_r($_SESSION);
//echo '</pre>';
//exit;


    
if(!empty($visit_arr['date_of_visit']) && !empty($_SESSION['wh_info']['ecr_data_open_since']) && ($visit_arr['date_of_visit'] < $_SESSION['wh_info']['ecr_data_open_since']))
{
    header("location:view_client.php?show_msg=cant_del_locked&client_id=".$client_id);
    exit;
}
else{
    

    $strSql2 = " INSERT INTO `ecr_client_visits_log` SET ";
    $strSql2 .= " visit_id='".$visit_id."',`client_id`= '".$client_id."' ,`wh_id` = '".$visit_arr['wh_id']."' ,user_id='".$_SESSION['user_id']."' ,";
    $strSql2 .= " `date_of_visit`= '".$visit_arr['date_of_visit']."',`remarks_of_date`='DELETED'; ";
//    echo $strSql2;exit;
    $rsSql = mysql_query($strSql2) or die("ERROR in saving log");
    
    $strSql = " DELETE FROM `ecr_client_visits` WHERE pk_id= '".$visit_id."' and client_id = '".$client_id."' and wh_id = '".$_SESSION['user_warehouse']."'; ";
    //echo $strSql;exit;
    $rsSql = mysql_query($strSql) or die("ERROR in Del Visit");
    header("location:view_client.php?show_msg=visit_deleted&client_id=".$client_id);
    exit;
}
?>