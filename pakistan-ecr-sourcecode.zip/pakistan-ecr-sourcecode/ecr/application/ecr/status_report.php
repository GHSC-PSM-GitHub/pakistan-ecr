<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";


$stk = $_SESSION['user_stakeholder1'];
if (!empty($_REQUEST['stk'])) {
    $stk = $_REQUEST['stk'];
}

$colors_new = array();
$colors_new[] = "#8251b8";
$colors_new[] = "#4c8ce6";
$colors_new[] = "#3fccc0";
$colors_new[] = "rgba(139,195,74,1)";
$colors_new[] = "rgba(33,150,243,1)";
$colors_new[] = "rgba(247, 184, 35,1)";
$colors_new[] = "rgba(250, 85, 192,1)";
$colors_new[] = "rgba(245, 146, 93,1)";
$colors_new[] = "rgba(56, 37, 184,1)";
$colors_new[] = "rgba(222, 108, 27,1)";
$colors_new[] = "#7CFC00";
$colors_new[] = "#FFFF00";
$colors_new[] = "#9932CC";


$data_counts = array();
$qry = "SELECT
	tbl_locations.PkLocID, 
	tbl_locations.LocName, 
	tbl_warehouse.hf_type_id, 
	tbl_warehouse.dist_id, 
	count(tbl_warehouse.wh_id) AS cc, 
	tbl_hf_type.hf_type
FROM
	tbl_warehouse
	INNER JOIN
	tbl_locations
	ON 
		tbl_warehouse.dist_id = tbl_locations.PkLocID
	INNER JOIN
	tbl_hf_type
	ON 
		tbl_warehouse.hf_type_id = tbl_hf_type.pk_id
	INNER JOIN
	stakeholder
	ON 
		tbl_warehouse.stkofficeid = stakeholder.stkid
WHERE
	tbl_warehouse.prov_id = ".$_SESSION['user_province1']." 
         AND	tbl_warehouse.stkid = ".$stk."
	/*and ecr_start_month is not null*/ ";
if($stk == 1)
$qry .= " and tbl_warehouse.hf_type_id in (1,2,4,130)";
$qry .= "
	and tbl_warehouse.is_active = 1
	and stakeholder.lvl = 7
GROUP BY
        tbl_warehouse.dist_id,
	tbl_warehouse.hf_type_id
Order BY
        LocName
	";
//    echo $client_referrals_query;
$visit_purpose_results = mysql_query($qry);
while ($row = mysql_fetch_assoc($visit_purpose_results)) {
    @$dist_counts[$row['dist_id']][$row['hf_type_id']] = $row['cc'];
    @$type_counts[$row['hf_type_id']] += $row['cc'];

    $dist_names[$row['dist_id']] = $row['LocName'];
    $type_names[$row['hf_type_id']] = $row['hf_type'];
}



$qry = "SELECT
	tbl_locations.PkLocID, 
	tbl_locations.LocName, 
	tbl_warehouse.hf_type_id, 
	tbl_warehouse.dist_id, 
	count(tbl_warehouse.wh_id) AS cc, 
	tbl_hf_type.hf_type
FROM
	tbl_warehouse
	INNER JOIN
	tbl_locations
	ON 
		tbl_warehouse.dist_id = tbl_locations.PkLocID
	INNER JOIN
	tbl_hf_type
	ON 
		tbl_warehouse.hf_type_id = tbl_hf_type.pk_id
	INNER JOIN
	stakeholder
	ON 
		tbl_warehouse.stkofficeid = stakeholder.stkid
WHERE
	tbl_warehouse.prov_id = ".$_SESSION['user_province1']." 
        AND tbl_warehouse.stkid = ".$stk."
	and ecr_start_month is not null
	and stakeholder.lvl = 7 ";
if($stk == 1)
$qry .= " and tbl_warehouse.hf_type_id in (1,2,4,130)";
$qry .= "
	and tbl_warehouse.is_active = 1
GROUP BY
        tbl_warehouse.dist_id,
	tbl_warehouse.hf_type_id
Order BY
        LocName
	";
//    echo $client_referrals_query;
$visit_purpose_results = mysql_query($qry);
while ($row = mysql_fetch_assoc($visit_purpose_results)) {
    @$dist_counts_ecr[$row['dist_id']][$row['hf_type_id']] = $row['cc'];
    @$type_counts_ecr[$row['hf_type_id']] += $row['cc'];

    $dist_names[$row['dist_id']] = $row['LocName'];
    $type_names[$row['hf_type_id']] = $row['hf_type'];
}


?> 

<style>
    #container2 {
        max-width: 400px;
        margin: 0 auto;
    }

    .highcharts-figure,
    .highcharts-data-table table {
        min-width: 380px;
        max-width: 600px;
        margin: 0 auto;
    }

    .highcharts-data-table table {
        font-family: Verdana, sans-serif;
        border-collapse: collapse;
        border: 1px solid #ebebeb;
        margin: 10px auto;
        text-align: center;
        width: 100%;
        max-width: 500px;
    }

    .highcharts-data-table caption {
        padding: 1em 0;
        font-size: 1.2em;
        color: #555;
    }

    .highcharts-data-table th {
        font-weight: 600;
        padding: 0.5em;
    }

    .highcharts-data-table td,
    .highcharts-data-table th,
    .highcharts-data-table caption {
        padding: 0.5em;
    }

    .highcharts-data-table thead tr,
    .highcharts-data-table tr:nth-child(even) {
        background: #f8f8f8;
    }

    .highcharts-data-table tr:hover {
        background: #f1f7ff;
    }


</style>
</head> 
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/solid-gauge.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">ECR Facilities Status Report</h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 


                                        </div>
                                    </div>


                                </form>
                                <hr/>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        
                                        <div class="col-md-12" style="margin-left:0px;margin-right: 0px;" id="filters">
                                                <div class="portlet box" data-toggle="collapse-widget">
                                                  
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder"  >
                                                            <form action="">
                                                                Choose Department / Stakeholder :  
                                                                <select  required name="stk" id="stk" class="m form-control input-sm" onchange="this.form.submit()">
                                                                    <?php
                                                                    $queryprov = "SELECT
	distinct stakeholder.stkname, 
	stakeholder.stkid 
FROM
	stakeholder
	INNER JOIN
	tbl_warehouse
	ON 
		stakeholder.stkid = tbl_warehouse.stkid
WHERE
	 tbl_warehouse.ecr_start_month is not null
                                                                        ";
                                                                    //query result
                                                                    $rsprov = mysql_query($queryprov) or die();

                                                                    while ($rowprov = mysql_fetch_array($rsprov)) {
                                                                        if ($rowprov['stkid'] == $stk) {
                                                                            $sel = "selected='selected'";
                                                                            $stk_name = $rowprov['stkname'];
                                                                        } else {
                                                                            $sel = "";
                                                                        }
                                                                        ?>
                                                                        <option value="<?php echo $rowprov['stkid']; ?>" <?php echo $sel; ?>><?php echo $rowprov['stkname']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php
                                        $c = 1;


//                                        echo '<img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>';
//                                        echo '<img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>';
//                                        echo '<h3 align="center">Provincial Status of Facilities Upgraded to ECR</h3>';
//                                        echo '<table id="table_b"  border="1" style="width:90%;" class="table table-bordered table-hover table-condensed" >';
//                                        echo '<thead>';
//                                        echo '<tr class="bg-info">';
//                                        echo '<th>Sr</th>';
//                                        echo '<th>Province</th>';
//                                        foreach ($type_names as $type_id => $type_name) {
//
//                                            echo '<th>' . $type_name . '</th>';
//                                        }
//                                        echo '</tr>';
//                                        echo '</thead>';
//
//                                        echo '<tbody>';
//
//                                        echo '<tr>';
//                                        echo '<th>' . $c++ . '</th>';
//                                        echo '<th>Sindh</th>';
//                                        foreach ($type_names as $type_id => $type_name) {
//                                            $c1 = (!empty($type_counts_ecr[$type_id]))?$type_counts_ecr[$type_id]:0;
//                                            echo '<td><sup>' . $c1 . '</sup>&frasl;<sub>' . $type_counts[$type_id] . '</sub></td>';
//                                        }
//                                        echo '</tr>';
//
//                                        echo '</tbody>';
//
//                                        echo '</table>';



                                        echo '<span class="btn btn-info rounded pulsate" id="show_breakdown"><i class="fa fa-arrow-down"></i> Click here to Show District Wise Breakdown</span>';
                                        $c = 1;
                                        echo '<img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>';
                                        echo '<img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>';
                                        echo '<h3 align="center">District Wise Status of Facilities Upgraded to ECR</h3>';
                                        echo '<table id="table_a"  border="1" style="width:90%;" class="table table-bordered table-hover table-condensed" >';
                                        echo '<thead>';
                                        echo '<tr class="bg-info">';
                                        echo '<th>Sr</th>';
                                        echo '<th>District</th>';
                                        foreach ($type_names as $type_id => $type_name) {

                                            echo '<th>' . $type_name . '</th>';
                                        }
                                        echo '</tr>';
                                        echo '</thead>';

                                        echo '<tbody>';

                                        foreach ($dist_names as $d_id => $d_name) {
                                            echo '<tr style="display:none;">';
                                            echo '<th>' . $c++ . '</th>';
                                            echo '<th>' . $d_name . '</th>';
                                            foreach ($type_names as $type_id => $type_name) {
                                                $cc = (!empty($dist_counts_ecr[$d_id][$type_id])?@$dist_counts_ecr[$d_id][$type_id]:'0');
                                                $ct = (!empty($dist_counts[$d_id][$type_id])?$dist_counts[$d_id][$type_id]:'0');
                                                
                                                $cls='';
                                                if($cc == 0 )$cls = 'danger';
                                                if($cc == $ct )$cls = 'success';
                                                if($ct == 0 )$cls = 'dark';
                                                echo '<td class="bg-'.$cls.'" title="'.$cc.' '.$type_name.' centers of '.$d_name.' upgraded to ECR out of '.$ct.' centers">';
                                                if($ct > 0 ){
                                                    
                                                    echo '<sup>' . $cc . '</sup>&frasl;<sub>' . $ct . '</sub>';
                                                }
                                                echo '</td>';
                                                
                                                @$type_total[$type_id]['converted']+=$cc;
                                                @$type_total[$type_id]['total']+=$ct;
                                                
                                            }
                                            echo '</tr>';
                                        }

//                                        echo '<pre>';
//print_r($type_names);
//print_r(@$type_total);
//echo '</pre>';
//exit;
                                                echo '<tr>';
                                                echo '<th colspan="2">Provincial Total</th>';
                                            foreach ($type_names as $type_id => $type_name) { 
                                                
                                                $cc = (!empty($type_total[$type_id]['converted'])?@$type_total[$type_id]['converted']:'0');
                                                $ct = (!empty($type_total[$type_id]['total'])?$type_total[$type_id]['total']:'0');
                                                
                                                
                                                $cls='';
                                                if($cc == 0 )$cls = 'danger';
                                                if($cc == $ct )$cls = 'success';
                                                if($ct == 0 )$cls = 'dark';
                                                echo '<td class="h3 bg-'.$cls.'">';
                                                    echo '<sup>' . $cc . '</sup>&frasl;<sub>' . $ct . '</sub>';
                                                echo '</td>';
                                                
                                            }
                                                echo '</tr>';
                                        echo '</tbody>';

                                        echo '</table>';
                                        ?>
                                        
                                        Legend : Green = All done , Red = Zero , White = Partial , Grey = No Facility



                                        <div class="col-md-12"  >
                                            <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                <div class="portlet-title">
                                                    <div class="caption"><i class="fa fa-cogs"></i>Upgradation Status
                                                    </div>
                                                    <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                    </div>
                                                </div>
                                                <div class="portlet-body"  style=""   >
                                                    <figure class="highcharts-figure">
                                                        <div id="container2"></div>
                                                        <p class="highcharts-description">
                                                            This Progress Gauge Chart Displays the Status of Facilities to ECR in Percentage
                                                        </p>
                                                    </figure>


                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

    <script> 
        
        $('#show_breakdown').click(function () {
                $("#table_a tbody tr").first().show("fast", function showNext() {
                    $(this).next("tr").show("fast", showNext);
                });
                $(this).hide();
            });
        
        
        // Uncomment to style it like Apple Watch
        /*
if (!Highcharts.theme) {
    Highcharts.setOptions({
        chart: {
            backgroundColor: 'black'
        },
        colors: ['#F62366', '#9DFF02', '#0CCDD6'],
        title: {
            style: {
                color: 'silver'
            }
        },
        tooltip: {
            style: {
                color: 'silver'
            }
        }
    });
}
// */

        /**
         * In the chart render event, add icons on top of the circular shapes
         */
        function renderIcons() { }

        Highcharts.chart('container2', {

            chart: {
                type: 'solidgauge',
                height: '110%',
                events: {
                    render: renderIcons
                }
            },

            title: {
                text: 'Upgraded Facilities',
                style: {
                    fontSize: '24px'
                }
            },

            tooltip: {
                borderWidth: 0,
                backgroundColor: 'none',
                shadow: false,
                style: {
                    fontSize: '16px'
                },
                valueSuffix: '%',
                pointFormat: '{series.name}<br><span style="font-size:2em; color: {point.color}; font-weight: bold">{point.y}</span>',
                positioner: function (labelWidth) {
                    return {
                        x: (this.chart.chartWidth - labelWidth) / 2,
                        y: (this.chart.plotHeight / 2) + 15
                    };
                }
            },

            pane: {
                startAngle: 0,
                endAngle: 360,
                background: []
            },

            yAxis: {
                min: 0,
                max: 100,
                lineWidth: 0,
                tickPositions: []
            },

            plotOptions: {
                solidgauge: {
                    dataLabels: {
                        enabled: false
                    },
                    linecap: 'round',
                    stickyTracking: false,
                    rounded: true
                }
            },

            series: [
                
                <?php
                $val_r = 110;
                $val_i = 95;
                $val_c = 0;
                if(!empty($type_names)){
                    foreach ($type_names as $tid => $tname) {
                        ?>
                        {
                            name: '<?=$tname?>',
                            data: [{
                                    color: Highcharts.getOptions().colors[<?=$val_c++?>],
                                    radius: '<?=$val_r?>%',
                                    innerRadius: '<?=$val_i?>%',
                                    y: <?php echo (!empty($type_total[$tid]['converted']) && !empty($type_total[$tid]['total']))?round($type_total[$tid]['converted']*100/$type_total[$tid]['total'],1):0; ?>
                                }]
                        },            
                        <?php
                    $val_r=$val_r-20;    
                    $val_i=$val_i-20;    
                    }
                }
                ?>
                ]
        });

    </script>

</body>
</html>