<?php
/// for ECR module, the items are assigned manually, but the IDs are the same as in cLMIS
$items_fp = $items_fp_max = $items_larc = array();
$items_fp[1] = 'Rubber Condom';
$items_fp[9] = 'COC';
$items_fp[2] = 'POP';
$items_fp[3] = 'ECP';
$items_fp[7] = '3-Month Inj ( Depo )';
$items_fp[34] = '3-Month Inj Sayana Pres';
$items_fp[5] = 'Copper-T (Cu-T)';
$items_fp[4] = 'Multiload';
$items_fp[13] = 'Jadelle';
///// temporary blocked , will be enabled later when communicated by pwd sindh
//$items_fp[8] = 'Implanon';  
//$items_fp[81] = 'Implanon NXT';
$items_fp[31] = 'Tubal ligation ( CS for Female )';
$items_fp[32] = 'Vasectomy ( CS for Male )';

$items_fp_max[1] = '10';
$items_fp_max[9] = '3';
$items_fp_max[2] = '3';
$items_fp_max[3] = '2';
$items_fp_max[7] = '1';
$items_fp_max[34] = '2';
$items_fp_max[4] = '1';
$items_fp_max[5] = '1';
$items_fp_max[13] = '1';
$items_fp_max[8] = '1';
$items_fp_max[81] = '1';
$items_fp_max[31] = '1';
$items_fp_max[32] = '1';

$items_larc[5] = 'Copper-T (Cu-T)';
$items_larc[4] = 'Multiload';
$items_larc[13] = 'Jadelle';
$items_larc[8] = 'Implanon';
$items_larc[81] = 'Implanon NXT';



////////// messages array

$msg_array = array();
$msg_array['client_added']['txt']   ='Client has been registered.';
$msg_array['client_updated']['txt'] ='Client information has been updated.';
$msg_array['visit_added']['txt']    ='Visit has been added.';
$msg_array['visit_updated']['txt']  ='Visit information has been updated.';
$msg_array['cant_del_locked']['txt']  ='Can NOT delete data which is locked.';
$msg_array['cant_del_locked']['cls']   ='danger';

$msg_array['client_duplicate']['txt']   ='This client already exists in system. You may be attempting to register again.';
$msg_array['client_duplicate']['cls']   ='danger';

$msg_array['visit_duplicate']['txt']   ='This Visit of same date already exists. You may be attempting to enter a duplicate visit. Please contact district / provincial focal person for clarity.';
$msg_array['visit_duplicate']['cls']   ='danger';

$msg_array['visit_deleted']['txt']   ='Visit Information Deleted.';
$msg_array['visit_duplicate']['cls']   ='danger';

$msg_array['client_flagged']['txt']   ='Client has been flagged as duplicate !';
$msg_array['client_flagged']['cls']   ='warning';


//////// setting up common session values for ECR


if (!empty($_SESSION['wh_info'])) {
    $wh_info = $_SESSION['wh_info'];
} else {
    if(!empty($_SESSION['user_warehouse'])){
            $qry = "
                    SELECT
                        tbl_warehouse.wh_name,
                        tbl_warehouse.is_allowed_im,
                        tbl_warehouse.reporting_start_month,
                        tbl_warehouse.im_start_month,
                        tbl_warehouse.ecr_start_month,
                        tbl_warehouse.ecr_data_open_since,
                        tbl_warehouse.editable_data_entry_months,
                        tbl_warehouse.parent_id,
                        dd.LocName AS dist_name,
                        pp.LocName AS prov_name,
                        stakeholder.stkname,
                        tbl_dist_levels.lvl_name,
                        ss.lvl,
                        tbl_warehouse.stkofficeid,
                        parent.wh_name AS parent_fac
                    FROM
                        tbl_warehouse
                    LEFT JOIN tbl_locations AS dd ON tbl_warehouse.dist_id = dd.PkLocID
                    LEFT JOIN tbl_locations AS pp ON tbl_warehouse.prov_id = pp.PkLocID
                    LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                    LEFT JOIN stakeholder AS ss ON tbl_warehouse.stkofficeid = ss.stkid
                    LEFT JOIN tbl_dist_levels ON ss.lvl = tbl_dist_levels.lvl_id
                        LEFT JOIN tbl_warehouse AS parent ON tbl_warehouse.parent_id = parent.wh_id
                    WHERE
                        tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "'
                ";

            $res = mysql_query($qry);
            $wh_info = array();
            $wh_info = mysql_fetch_assoc($res);
            $_SESSION['wh_info'] = $wh_info;
    }
}

//if (!empty($_SESSION['wh_list'])) {
//    $wh_info = $_SESSION['wh_list'];
//} else {
//    if(!empty($_SESSION['user_district'])){
            $qry = "
                   SELECT
	tbl_warehouse.wh_id, 
	tbl_warehouse.wh_name, 
	tbl_warehouse.dist_id, 
	tbl_warehouse.prov_id, 
	tbl_warehouse.stkid, 
	tbl_warehouse.hf_type_id
FROM
	tbl_warehouse
	INNER JOIN
	stakeholder
	ON 
		tbl_warehouse.stkofficeid = stakeholder.stkid
WHERE
	stakeholder.lvl = 7
	and tbl_warehouse.dist_id = '" .$_SESSION['user_district'] . "'
	and tbl_warehouse.stkid = '" .$_SESSION['user_stakeholder1'] . "'
	and is_active = 1
	order by wh_name 
                ";
//echo $qry;exit;
            $res = mysql_query($qry);
            $wh_list = array();
            while($row = mysql_fetch_assoc($res)){
                
                $wh_list[$row['wh_id']] = $row;
            }
            $_SESSION['wh_list'] = $wh_list;
//    }
//}
//echo '<pre>';
//print_r($_SESSION['wh_list']);
//echo '</pre>';
//exit;


$ecr_start = '2022-10-01';
if(!empty($_SESSION['wh_info']['ecr_start_month'])){
    $ecr_start = $_SESSION['wh_info']['ecr_start_month'];
}
//echo $ecr_start;exit;

$min_date = $ecr_start;
if(!empty($ecr_start)){
    $min_date=date('Y-m-d',strtotime($ecr_start)); //// first the ECR start date of facility
}
if(!empty($_SESSION['wh_info']['ecr_data_open_since'])){
    $ecr_open_since = $_SESSION['wh_info']['ecr_data_open_since'];
    $min_date=date('Y-m-d',strtotime($ecr_open_since)); /// if open since values is available then override
}

//echo 'ecr:'.$ecr_start.',min:'.$min_date;exit;
$show_msg = false;
if($min_date!=$ecr_start){
    $show_msg = true;
    $lock_msg = 'Please note : Data for this facility is locked before the date of '.date('jS M Y',strtotime($min_date)).'. Hence You can NOT Enter or Modify ECR data before : '.date('jS M Y',strtotime($min_date)).'';
}

?>