<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$visit_id = '';

if (!empty($_REQUEST['visit_id']))
    $visit_id = htmlspecialchars($_REQUEST['visit_id']);

$items_fp = $items_larc = array();
$client_arr = $visit_arr = array();

$qry = "SELECT * FROM
                ecr_client_visits
            WHERE 
                pk_id = '" . $visit_id . "'
        ";
$qryRes = mysql_query($qry);
while ($row = mysql_fetch_assoc($qryRes)) {
    $visit_arr = $row;
}
$client_id = $visit_arr['client_id'];

$qry = "SELECT
                list_detail.pk_id,
                list_detail.list_value,
                list_detail.description,
                list_detail.rank,
                list_detail.reference_id,
                list_detail.parent_id,
                list_detail.list_master_id
            FROM
                list_detail
            ORDER BY
                list_detail.rank ,
                list_detail.list_value ASC
        ";
$qryRes = mysql_query($qry);
$list_arr = array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $list_arr[$row['list_master_id']][$row['pk_id']]['name'] = $row['list_value'];
    $list_arr[$row['list_master_id']][$row['pk_id']]['description'] = $row['description'];
}


if (!empty($client_id)) {
    $qry = "SELECT ecr_clients.*,wh_name FROM
                    ecr_clients
                    inner join tbl_warehouse on registered_at = wh_id
                WHERE 
                    pk_id = '" . $client_id . "'
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $client_arr = $row;
    }
}
//echo '<pre>';
//print_r($client_arr);
//print_r($visit_arr);
//echo '</pre>';
//exit;
?>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="font-green">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>


                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Visit Information</h3>
                            </div>
                            <div class="widget-body">
                                <div class="row">
                                    <div class="col-md-12 table-responsive">

                                          <?php
                                if(!empty($_REQUEST['show_msg']) && !empty($msg_array[$_REQUEST['show_msg']]['txt'])) {
                                    if(!empty($msg_array[$_REQUEST['show_msg']]['cls'])){
                                        $cls = $msg_array[$_REQUEST['show_msg']]['cls'];
                                    }else{
                                        $cls='success';
                                    }
                                echo '<div class="col-md-12 col-lg-12">
                                            <div class="note note-'.$cls.'" >NOTE : '.$msg_array[$_REQUEST['show_msg']]['txt'].'</div>  
                                    </div>';
                                }
                            ?>
                                        <table class="table table-bordered table-condensed table-striped">
                                            <thead>
                                                <tr class="bg-success">
                                                    <th  colspan="2" >Visit Info</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php
                                                $c = 1;
                                                echo '<tr>';
                                                echo '<th>Health Facility of Visit:</th><td>' . $visit_arr['wh_name'] . '</td> ';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo '<th>Date of visit:</th><td>' . (!empty($visit_arr['date_of_visit']) ? date('d-M-Y', strtotime($visit_arr['date_of_visit'])) : '') . '</td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo ' <th>Reason for changing date:</th><td>' . $visit_arr['remarks_of_date'] . '</td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo ' <th>Purpose of visit:</th><td>' . strtoupper($visit_arr['visit_purpose']) . '</td>';
                                                echo '</tr>';
                                                ?>
                                            </tbody>
                                        </table>
                                        <table class="table table-bordered table-condensed table-striped">
                                            <thead>
                                                <tr class="bg-success">
                                                    <th  colspan="2" >Last Pregnancy/Procedure</th>
                                                </tr>

                                            </thead>
                                            <tbody><?php
                                                echo '<th>Outcome of Last Pregnancy/Procedure:</th><td>' . ucfirst($visit_arr['outcome_last_preg']) . '</td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo '<th>Parity ( Alive ): </th><td>' . (!empty($visit_arr['parity_alive']) ? $visit_arr['parity_alive'] : '0') . ' </td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo '<th>Parity ( Death ):</th><td>' . (!empty($visit_arr['parity_death']) ? $visit_arr['parity_death'] : '0') . '</td>';
                                                echo '</tr>';
                                                echo '<tr>';

                                                echo '<th>Total period from last Outcome / Pregnancy:</th><td>' . $visit_arr['period_from_last_preg'] . '</td> ';
                                                echo '</tr>';
                                                ?>
                                            </tbody>
                                        </table>
                                        <table class="table table-bordered table-condensed table-striped">
                                            <thead>
                                                <tr class="bg-success">
                                                    <th  colspan="2">Services Details</th>
                                                </tr>
                                            </thead>
                                            <tbody><?php
                                                if (!empty($visit_arr['visit_purpose'])) {

                                                    echo '<th>Purpose of Visit:</th><td> ' . strtoupper($visit_arr['visit_purpose']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                                    if ($visit_arr['visit_purpose'] == 'fp') {

                                                        echo '<th>Category:</th><td>' . $visit_arr['fp_category'] . '</td>';
                                                        echo '</tr>';
                                                        if(!empty($visit_arr['type_of_visit'])){
                                                            $type_of_visit_name='';
                                                            if( $visit_arr['type_of_visit']=='1'){
                                                                $type_of_visit_name='Issuance / Procedure';
                                                            }
                                                            if( $visit_arr['type_of_visit']=='2'){
                                                                $type_of_visit_name='Referral to other facility';
                                                            }
                                                            
                                                                
                                                            echo '<tr>';
                                                            echo '<th>Type of Visit:</th><td>' . $type_of_visit_name . ' </td>';
                                                            echo '</tr>';
                                                        }
                                                        echo '<tr>';
                                                        echo '<th>Method:</th><td>' . $visit_arr['fp_method_name'] . ' </td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Issuance:</th><td>' . $visit_arr['fp_qty'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Additional RC:</th><td>' . $visit_arr['additional_item_qty'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Referred By (Name):</th><td>' . $visit_arr['fp_referred_from'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Reffered by (Designation):</th><td>' . $visit_arr['fp_referred_from_desig'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Reffered to:</th><td>' . $visit_arr['fp_referred_to'].$visit_arr['ref_to_fac_name'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Reffered for:</th><td>' . $visit_arr['fp_referred_for'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Reason for IUCD referral (if applicable):</th><td>' . $visit_arr['fp_reason_of_referral'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                    } elseif ($visit_arr['visit_purpose'] == 'ghs') {

                                                        echo '<th>Category:</span>' . $visit_arr['gen_health_category'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Diagnosis:</span>' . ucfirst($visit_arr['gen_health_diagnosis']) . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Treatment:</span>' . ucfirst($visit_arr['gen_health_treatment']) . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Referred To:</span>' . $visit_arr['gen_health_referred_to'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                    } elseif ($visit_arr['visit_purpose'] == 'larc_removal') {
                                                        echo '<th>Method:</span>' . $visit_arr['larc_method_name'] . ' </td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Period ( of Insertion ):</span>' . $visit_arr['larc_period'] . ' </td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                        echo '<th>Reason for Removal:</span>' . $visit_arr['larc_reason'] . '</td>';
                                                        echo '</tr>';
                                                        echo '<tr>';
                                                    }
                                                } else {
                                                    // for now printing all info for old data... 
                                                    /// not necessary when launched
                                                    echo '<th>FP Services:</th>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Category:</th><td>' . $visit_arr['fp_category'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Method:</th><td>' . $visit_arr['fp_method_name'] . ' </td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Issuance:</th><td>' . $visit_arr['fp_qty'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Ref by:</th><td>' . $visit_arr['fp_referred_from'] . '(' . $visit_arr['fp_referred_from'] . ')</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    //// in the following line, using both variables to display the 'Ref To', one of them is old one, other is new
                                                    echo '<th>Ref to:</th><td>' . $visit_arr['fp_referred_to'] .$visit_arr['ref_to_fac_name'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Ref for:</th><td>' . $visit_arr['fp_referred_for'] . '(' . $visit_arr['fp_reason_of_referral'] . ')</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';

                                                    echo '<th>GHS:</th>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Category:</th><td>' . $visit_arr['gen_health_category'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Diagnosis:</th><td>' . ucfirst($visit_arr['gen_health_diagnosis']) . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Treatment:</th><td>' . ucfirst($visit_arr['gen_health_treatment']) . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Ref To:</th><td>' . $visit_arr['gen_health_referred_to'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';

                                                    echo '<th>LARC Removal:</th>';
                                                    echo '<th>Method:</th><td>' . $visit_arr['larc_method_name'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Period:</th><td>' . $visit_arr['larc_period'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                    echo '<th>Reason:</th><td>' . $visit_arr['larc_reason'] . '</td>';
                                                    echo '</tr>';
                                                    echo '<tr>';
                                                }
                                                echo '</td>';
                                                ?>
                                            </tbody>
                                        </table>
                                        <table class="table table-bordered table-condensed table-striped">
                                            <thead>
                                                <tr class="bg-success">
                                                    <th  colspan="2" >Activity Information</th>
                                                </tr>
                                            </thead>
                                            <tbody><?php
                                                echo '<th>Activity Done Under </th><td>' . $visit_arr['activity_under'] . '</td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo '<th>FHD Done in Union Council: </th><td>' . $visit_arr['activity_uc'] . '</td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo '<th>FHD Number:</th><td>' . $visit_arr['activity_num'] . '</td>';
                                                echo '</tr>';
                                                ?>
                                            </tbody>
                                        </table>
                                        <?php
                                        echo '<a class="btn btn-xs btn-success" href="add_visit.php?client_id=' . $client_id . '"><i class="fa fa-plus"></i> Add A New Visit of ' . ucwords($client_arr['client_name']) . '</a>';
                                        if(!empty($visit_arr['wh_id']) && $visit_arr['wh_id']==$_SESSION['user_warehouse'])
                                        {

                                            echo '&nbsp;<a class="btn btn-xs btn-warning" href="edit_visit.php?visit_id='.$visit_arr['pk_id'].'"><i class="fa fa-pencil"></i> Edit This Visit</a>';
                                            echo '&nbsp;<a onclick="return confirm(\'Are you sure to Delete this Visit?\')" class="btn btn-xs btn-danger" href="del_visit_action.php?visit_id='.$visit_arr['pk_id'].'&client_id='.$visit_arr['client_id'].'"><i class="fa fa-times"></i> Delete This Visit</a>';

                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4"> 
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Clients Personal Information</h3>
                            </div>
                            <div class="widget-body">
                                <div class="row">
                                    <div class="col-md-12 table-responsive">

                                        <table class="table table-bordered table-condensed table-striped">

                                            <?php
                                            $v = $client_arr;

                                            echo '<tr>';
                                            echo '<th>Serial Number</th><td>' . $v['serial_number'] . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Clients Name</th><td>' . ucfirst($v['client_name']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Father/Husband</th><td>' . ucfirst($v['father_name']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Nationality</th><td>' . ucfirst($v['nationality']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>CNIC</th><td>' . $v['cnic'] . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Foreign ID</th><td>' . $v['foreigner_identity'] . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Contact</th><td>' . $v['contact_number'] . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>CRC New/Old</th><td>' . ucfirst($v['crc_new_old']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>CRC Number</th><td>' . ucfirst($v['crc_number']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Catchment</th><td>' . ucfirst($v['catchment_area']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Occupation</th><td>' . ucfirst($v['occupation']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Education</th><td>' . ucfirst($v['education']) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Age When Registered</th><td>' . $v['age_today'] . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Years of Marriage</th><td>' . $v['age_when_married'] . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Registration Date</th><td>' . date('d-M-Y', strtotime($v['created_on'])) . '</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<th>Registered At </th><td>' . $v['wh_name'] . '</td>';
                                            echo '</tr>';

                                            $client_name = $v['client_name'];
                                            ?>
                                        </table>
                                        
                                        <?php
                                        if(!empty($v['registered_at']) && $v['registered_at']==$_SESSION['user_warehouse'])
                                        {
                                            echo '<br/><a class="btn btn-xs btn-info" href="edit_client.php?client_id='.$v['pk_id'].'"><i class="fa fa-pencil"></i> Edit This Clients Info</a>';
                                        }
                                        ?>

                                    </div>
                                </div>

                            </div>



                        </div>


                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

</body>
</html>