<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";

$stk = $_SESSION['user_stakeholder1'];
if (!empty($_REQUEST['stk'])) {
    $stk = $_REQUEST['stk'];
}

$colors_new = array();
$colors_new[] = "#8251b8";
$colors_new[] = "#4c8ce6";
$colors_new[] = "#3fccc0";
$colors_new[] = "rgba(139,195,74,1)";
$colors_new[] = "rgba(33,150,243,1)";
$colors_new[] = "rgba(247, 184, 35,1)";
$colors_new[] = "rgba(250, 85, 192,1)";
$colors_new[] = "rgba(245, 146, 93,1)";
$colors_new[] = "rgba(56, 37, 184,1)";
$colors_new[] = "rgba(222, 108, 27,1)";
$colors_new[] = "#7CFC00";
$colors_new[] = "#FFFF00";
$colors_new[] = "#9932CC";

$title_text = '';
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $title_text .= ' at Your Facility';
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $title_text .= ' at Your District';
}

// Jadelle Removals And Reasons
$jadelle_query = "SELECT case when ecr_client_visits.larc_reason = '' then 'No Reason Provided' else ecr_client_visits.larc_reason end as larc_reason, COUNT(*) AS total 
        FROM ecr_client_visits
	inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
        WHERE ecr_client_visits.larc_method = '13' ";

$jadelle_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";

if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $jadelle_query .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $jadelle_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$jadelle_query .= " GROUP BY ecr_client_visits.larc_reason";
//echo $jadelle_query;exit;
$jadelle_results = mysql_query($jadelle_query);
$all_jadelle = $jadelle_total = array();
if (mysql_num_rows($jadelle_results) > 0) {
    while ($jadelle = mysql_fetch_assoc($jadelle_results)) {
        $jadelle_total[] = $jadelle['total'];
        $all_jadelle[] = $jadelle['larc_reason'];
    }
}

// IUCD Removals And Reasons
$iucd_query = "SELECT case when ecr_client_visits.larc_reason = '' then 'No Reason Provided' else ecr_client_visits.larc_reason end as larc_reason, COUNT(*) AS total 
    FROM ecr_client_visits 
	inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
    WHERE ecr_client_visits.larc_method = '5'  ";
$iucd_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $iucd_query .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $iucd_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$iucd_query .= " 
    
GROUP BY ecr_client_visits.larc_reason";
$iucd_results = mysql_query($iucd_query);
$all_iucd = $iucd_total = array();
if (mysql_num_rows($iucd_results) > 0) {
    while ($iucd = mysql_fetch_assoc($iucd_results)) {
        $iucd_total[] = $iucd['total'];
        $all_iucd[] = $iucd['larc_reason'];
    }
}

// Implanon Removals And Reasons
$implanon_query = "SELECT case when ecr_client_visits.larc_reason = '' then 'No Reason Provided' else ecr_client_visits.larc_reason end as larc_reason, COUNT(*) AS total 
    FROM ecr_client_visits 
	inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
    WHERE ecr_client_visits.
    in ('8','81')  ";
$implanon_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $implanon_query .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $implanon_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$implanon_query .= " 
    GROUP BY ecr_client_visits.larc_reason";
$implanon_results = mysql_query($implanon_query);
$all_implanon = $implanon_total = array();
if (mysql_num_rows($implanon_results) > 0) {
    while ($implanon = mysql_fetch_assoc($implanon_results)) {
        $implanon_total[] = $implanon['total'];
        $all_implanon[] = $implanon['larc_reason'];
    }
}
//echo '<pre>';
//print_r($all_implanon);
//echo '</pre>';
//exit;
// New Clients Consumptions
$new_clients_consumptions_query = "SELECT 
                                ecr_client_visits.fp_method_name,fp_method, COUNT(*) AS total
                            FROM ecr_client_visits 
                            INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
                            inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
                            WHERE ecr_client_visits.fp_method_name IS NOT NULL  and fp_method_name <> '' and trim(fp_method_name) <> 'SELECT' ";
$new_clients_consumptions_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $new_clients_consumptions_query .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $new_clients_consumptions_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$new_clients_consumptions_query .= " 
                            GROUP BY ecr_client_visits.fp_method_name";
//echo $new_clients_consumptions_query;exit;
$new_clients_consumptions_results = mysql_query($new_clients_consumptions_query);
$all_new_clients_consumptions = $new_clients_consumptions_total = array();
if (mysql_num_rows($new_clients_consumptions_results) > 0) {
    while ($new_clients_consumption = mysql_fetch_assoc($new_clients_consumptions_results)) {
        $new_clients_consumptions_total[] = $new_clients_consumption['total'];
        $all_new_clients_consumptions[] = $new_clients_consumption['fp_method_name'];
    }
}
//echo '<pre>';
////print_r($new_clients_consumptions_total);
//print_r($all_new_clients_consumptions);
//echo '</pre>';
//exit;
// Followup Clients Consumptions
//$followup_clients_consumptions_query = "SELECT 
//                                ecr_client_visits.larc_method_name, COUNT(*) AS total
//                            FROM ecr_client_visits 
//                            INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
//                            WHERE ecr_client_visits.larc_method_name <> ''
//                                AND ecr_clients.crc_new_old LIKE 'old'
//                            GROUP BY ecr_client_visits.larc_method_name";
//$followup_clients_consumptions_results = mysql_query($followup_clients_consumptions_query);
//$all_followup_clients_consumptions = $followup_clients_consumptions_total = array();
//if (mysql_num_rows($followup_clients_consumptions_results) > 0) {
//    while ($followup_clients_consumption = mysql_fetch_assoc($followup_clients_consumptions_results)) {
//        $followup_clients_consumptions_total[] = $followup_clients_consumption['total'];
//        $all_followup_clients_consumptions[] = $followup_clients_consumption['larc_method_name'];
//    }
//}
// Client category
$client_referrals_query = "SELECT 
                                ecr_client_visits.gen_health_category, COUNT(*) AS total
                            FROM ecr_client_visits 
                            INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
	inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
                            WHERE ecr_client_visits.gen_health_category <> ''
                            AND ecr_client_visits.gen_health_category <> 'undefined' ";
$client_referrals_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $client_referrals_query .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $client_referrals_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$client_referrals_query .= " 
                            GROUP BY ecr_client_visits.gen_health_category";
$client_referrals_results = mysql_query($client_referrals_query);
$all_client_referrals = $client_referrals_total = array();
if (mysql_num_rows($client_referrals_results) > 0) {
    while ($client_referrals = mysql_fetch_assoc($client_referrals_results)) {
        $client_referrals_total[] = $client_referrals['total'];
        $all_client_referrals[] = ucfirst($client_referrals['gen_health_category']);
    }
}





/// fp category
$client_referrals_query = "SELECT 
                                ecr_client_visits.fp_category, COUNT(*) AS total
                            FROM ecr_client_visits 
                            INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
	inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
                            WHERE ecr_client_visits.fp_category <> ''
                            AND ecr_client_visits.fp_category <> 'undefined' ";
$client_referrals_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $client_referrals_query .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $client_referrals_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$client_referrals_query .= " 
                            GROUP BY ecr_client_visits.fp_category";
$fp_cat_results = mysql_query($client_referrals_query);
$all_fp_cat = $fp_cat_total = array();
if (mysql_num_rows($fp_cat_results) > 0) {
    while ($client_referral = mysql_fetch_assoc($fp_cat_results)) {
        $fp_cat_total[] = $client_referral['total'];
        $all_fp_cat[] = ucfirst($client_referral['fp_category']);
    }
}

/// visit_purpose category
$qry = "SELECT 
                                ecr_client_visits.visit_purpose, COUNT(*) AS total
                            FROM ecr_client_visits 
                            INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
	inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
                            WHERE ecr_client_visits.visit_purpose <> ''
                            AND ecr_client_visits.visit_purpose <> 'undefined' ";
$qry .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $qry .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $qry .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$qry .= " 
                            GROUP BY ecr_client_visits.visit_purpose";
//    echo $client_referrals_query;
$visit_purpose_results = mysql_query($qry);
$visits_grand_total = 0;
$all_visit_purpose = $visit_purpose_total = array();
if (mysql_num_rows($visit_purpose_results) > 0) {
    while ($row = mysql_fetch_assoc($visit_purpose_results)) {
        $visit_purpose_total[] = $row['total'];
        @$visits_grand_total += $row['total'];
        $all_visit_purpose[] = ucfirst(str_replace('_', ' ', $row['visit_purpose']));
    }
}
//echo '<pre>';
//print_r($visits_grand_total);
//echo '</pre>';
//exit;
// Method Mix
$method_mix_query = "SELECT 
                            ecr_client_visits.fp_method_name, COUNT(*) AS total
                        FROM ecr_client_visits 
                        INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
	inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
                        WHERE ecr_client_visits.fp_method_name <> '' ";
$method_mix_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $method_mix_query .= " and ecr_client_visits.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $method_mix_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$method_mix_query .= " 
                        GROUP BY ecr_client_visits.fp_method_name";
$method_mix_results = mysql_query($method_mix_query);
$all_method_mix = $method_mix_total = array();
if (mysql_num_rows($method_mix_results) > 0) {
    while ($method_mix = mysql_fetch_assoc($method_mix_results)) {
        $method_mix_total[] = $method_mix['total'];
        $all_method_mix[] = ucfirst($method_mix['fp_method_name']);
    }
}

// Educations And It's Count 
$educations_query = "SELECT ecr_clients.education, COUNT(*) AS total 
    FROM ecr_clients 
	inner join tbl_warehouse on ecr_clients.registered_at = tbl_warehouse.wh_id
    WHERE ecr_clients.education != ''  ";
$educations_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $educations_query .= " and tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $educations_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$educations_query .= " 
    GROUP BY ecr_clients.education";
$education_results = mysql_query($educations_query);
$all_educations = $total = array();
if (mysql_num_rows($education_results) > 0) {
    while ($education = mysql_fetch_assoc($education_results)) {
        $total[] = $education['total'];
        $all_educations[] = $education['education'];
    }
}

// Occupations And It's Count 
$occupations_query = "SELECT ecr_clients.occupation, COUNT(*) AS total 
    FROM ecr_clients 
	inner join tbl_warehouse on ecr_clients.registered_at = tbl_warehouse.wh_id
    WHERE ecr_clients.occupation != ''   ";
$occupations_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $occupations_query .= " and tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $occupations_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$occupations_query .= " 
    GROUP BY ecr_clients.occupation";
$occupation_results = mysql_query($occupations_query);
$all_occupations = $occupations_total = array();
if (mysql_num_rows($occupation_results) > 0) {
    while ($occupation = mysql_fetch_assoc($occupation_results)) {
        $occupations_total[] = $occupation['total'];
        $all_occupations[] = $occupation['occupation'];
    }
}

// Demographic Characteristics And It's Count 
$demographic_characteristics_query = "SELECT ecr_clients.catchment_area, COUNT(*) AS total 
    FROM ecr_clients 
	inner join tbl_warehouse on ecr_clients.registered_at = tbl_warehouse.wh_id
    WHERE ecr_clients.catchment_area != ''   ";
$demographic_characteristics_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $demographic_characteristics_query .= " and tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $demographic_characteristics_query .= " and tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$demographic_characteristics_query .= " 
    GROUP BY ecr_clients.catchment_area";
$demographic_characteristic_results = mysql_query($demographic_characteristics_query);
$all_demographic_characteristics = $demographic_characteristics_total = array();
if (mysql_num_rows($demographic_characteristic_results) > 0) {
    while ($demographic_characteristic = mysql_fetch_assoc($demographic_characteristic_results)) {
        $demographic_characteristics_total[] = $demographic_characteristic['total'];
        $all_demographic_characteristics[] = ucfirst($demographic_characteristic['catchment_area']);
    }
}

// Parity And It's Count 
$parities_query = "SELECT SUM(CASE WHEN parity_alive >= 1 AND parity_alive <= 2 THEN 1 ELSE 0 END) AS parity_1_to_2_child,
                    SUM(CASE WHEN parity_alive >= 3 AND parity_alive <= 4 THEN 1 ELSE 0 END) AS parity_3_to_4_child,
                    SUM(CASE WHEN parity_alive >= 5 AND parity_alive <= 6 THEN 1 ELSE 0 END) AS parity_5_to_6_child,
                    SUM(CASE WHEN parity_alive >= 7 AND parity_alive <= 10 THEN 1 ELSE 0 END) AS parity_7_to_10_child,
                    SUM(CASE WHEN parity_alive > 10 THEN 1 ELSE 0 END) AS parity_10_or_child,
                    SUM(CASE WHEN parity_alive = 0 THEN 1 ELSE 0 END) AS parity_no_child,
                    SUM(CASE WHEN parity_alive = '' THEN 1 ELSE 0 END) AS no_data
                FROM ecr_client_visits
	inner join tbl_warehouse on ecr_client_visits.wh_id= tbl_warehouse.wh_id  ";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $parities_query .= " WHERE tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $parities_query .= " WHERE tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$parities_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
$parities_query .= " ";
$result_parities = mysql_query($parities_query);
$parities_data_graph = mysql_fetch_assoc($result_parities);
// var_dump($parities_data_graph);die();
// Ages And It's Count 
$age_query = "SELECT SUM(CASE WHEN age_today < 18 THEN 1 ELSE 0 END) AS age_under_18,
                    SUM(CASE WHEN age_today >= 18 THEN age_today <= 24 ELSE 0 END) AS age_18_to_24,
                    SUM(CASE WHEN age_today >= 25 THEN age_today <= 30 ELSE 0 END) AS age_25_to_30,
                    SUM(CASE WHEN age_today >= 31 THEN age_today <= 35 ELSE 0 END) AS age_31_to_35,
                    SUM(CASE WHEN age_today >= 36 THEN age_today <= 40 ELSE 0 END) AS age_36_to_40,
                    SUM(CASE WHEN age_today < 45 THEN age_today >= 41 ELSE 0 END) AS age_41_to_45,
                    SUM(CASE WHEN age_today < 120 THEN age_today >= 45 ELSE 0 END) AS age_45_or_above
                FROM ecr_clients  
	inner join tbl_warehouse on ecr_clients.registered_at = tbl_warehouse.wh_id";
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
    $age_query .= " WHERE tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
}
if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3') {
    $age_query .= " WHERE tbl_warehouse.dist_id = '" . $_SESSION['user_district'] . "' ";
}
$age_query .= "  and tbl_warehouse.stkid = '" . $stk . "' ";
$age_query .= " ";
$result_ages = mysql_query($age_query);
$ages_data_graph = mysql_fetch_assoc($result_ages);
?>
<!--<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>-->
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.0/dist/chart.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0/dist/chartjs-plugin-datalabels.min.js"></script> 
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;


    }

    .name {
        position: absolute;
        bottom: 0;
        left: 0;
        margin-bottom: 23px;
        margin-left: 14px;
        margin-right: 15px;
        font-weight: 400;
        font-size: 33px;
        color: #ffffff;
    }
    .number {
        position: absolute;
        bottom: 0;
        right: 0;
        margin-bottom: 0;
        color: #ffffff;
        text-align: center;
        font-weight: 400;
        font-size: 54px;
        letter-spacing: 0.01em;
        line-height: 34px;
        margin-bottom: 18px;
        margin-right: 21px;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        if (!is_request_from_mobile()) {
            ?>
            <div class="page-content-wrapper">
                <div class="page-content"> 
                    <!-- BEGIN PAGE HEADER-->
                    <div class="row">
                        <div class="col-md-12">
                            <h2 class="font-blue-chambray" style="border-bottom: 3px solid #5dcf85;text-align: center">Main Dashboard ( ECR )</h2>
                            <div class="widgetx" data-toggle="collapse-widgetx">

                                <div class="widget-bodyx">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 style="border-bottom: 3px solid #5dcf85;text-align: center">Disaggregation of Recorded ECR Visits </h3>

                                            <!--                        <h4 class="font-blue-chambray">Visits Detailed Analysis</h4>-->



                                            <!--                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_15">
                                                                                            <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                                                                <div class="portlet-title">
                                                                                                    <div class="caption"><i class="fa fa-cogs"></i>Method Mix <?php echo $title_text; ?>
                                                                                                    </div>
                                                                                                    <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="portlet-body">
                                                                                            <div id="canvas-holder" style="width:90%">
                                                                                                <canvas id="ch10"></canvas>
                                                                                            </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>-->

                                            <div class="col-md-12" style="margin-left:0px;margin-right: 0px;" id="filters">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Filters
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder"  >
                                                            <form action="">
                                                                Choose Department / Stakeholder :  
                                                                <select  required name="stk" id="stk" class="m form-control input-sm" onchange="this.form.submit()">
                                                                    <?php
                                                                    $queryprov = "SELECT
	distinct stakeholder.stkname, 
	stakeholder.stkid 
FROM
	stakeholder
	INNER JOIN
	tbl_warehouse
	ON 
		stakeholder.stkid = tbl_warehouse.stkid
WHERE
	 tbl_warehouse.ecr_start_month is not null
                                                                        ";
                                                                    //query result
                                                                    $rsprov = mysql_query($queryprov) or die();

                                                                    while ($rowprov = mysql_fetch_array($rsprov)) {
                                                                        if ($rowprov['stkid'] == $stk) {
                                                                            $sel = "selected='selected'";
                                                                            $stk_name = $rowprov['stkname'];
                                                                        } else {
                                                                            $sel = "";
                                                                        }
                                                                        ?>
                                                                        <option value="<?php echo $rowprov['stkid']; ?>" <?php echo $sel; ?>><?php echo $rowprov['stkname']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 hide" style="margin-left:0px;margin-right: 0px;" id="filters">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Filters
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body dark">
                                                        <div    > 

                                                            <div class="tiles">

                                                                <div class="tile double bg-red-sunglo">
                                                                    <div class="tile-body">
                                                                        <i class="number">
                                                                            12
                                                                        </i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Meetings
                                                                        </div>
                                                                        <i class="fa fa-calendar"></i>
                                                                    </div>
                                                                </div>

                                                                <div class="tile double selectedx bg-yellow-saffron">
                                                                    <div class="corner">
                                                                    </div>
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-user"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Members
                                                                        </div>
                                                                        <div class="number">
                                                                            452
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="tile double bg-purple-studio">
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-shopping-cart"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Orders
                                                                        </div>
                                                                        <div class="number">
                                                                            121
                                                                        </div>
                                                                    </div>
                                                                </div> 
                                                                <div class="tile double bg-green-meadow">
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-comments"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Feedback
                                                                        </div>
                                                                        <div class="number">
                                                                            12
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="tile double bg-red-intense">
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-coffee"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Meetups
                                                                        </div>
                                                                        <div class="number">
                                                                            12 Jan
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tile double bg-green">
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-bar-chart-o"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Reports
                                                                        </div>
                                                                        <div class="number">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tile double bg-blue-steel">
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-briefcase"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Documents
                                                                        </div>
                                                                        <div class="number">
                                                                            124
                                                                        </div>
                                                                    </div>
                                                                </div> 
                                                                <div class="tile double bg-yellow-lemon selectedx">
                                                                    <div class="corner">
                                                                    </div> 
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-cogs"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Settings
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tile double bg-red-sunglo">
                                                                    <div class="tile-body">
                                                                        <i class="fa fa-plane"></i>
                                                                    </div>
                                                                    <div class="tile-object">
                                                                        <div class="name">
                                                                            Projects
                                                                        </div>
                                                                        <div class="number">
                                                                            34
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_8">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Purpose Wise No. of Visits - <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="ch_purpose"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_8">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>General Health Services - Category Breakdown <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="ch5"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_8">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Family Planning Services - Category Breakdown <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="ch_fp_cat"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>FP Method Wise Visits <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body" style="height: 400px;">
                                                        <div id="canvas-holder" style="width:90%;height:100%">
                                                            <canvas id="char2"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_3">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Implanon Removals with Reasons <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body" style="height: 400px;">
                                                        <div id="canvas-holder" style="width:90%;height:100%">
                                                            <canvas id="char3"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_4">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>IUCD Removals with Reasons <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body" style="height: 400px;">
                                                        <div id="canvas-holder" style="width:90%;height:100%">
                                                            <canvas id="char4"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_5">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Jadelle Removals with Reasons <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body" style="height: 400px;">
                                                        <div id="canvas-holder" style="width:90%;height:100%">
                                                            <canvas id="char5"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <h3 style="border-bottom: 1px solid #eee;text-align: center">Disaggregation of Registered ECR Clients</h3>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_6">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Age Wise Clients Registered <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="ch4"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_7">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Education Wise Clients Registered <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="char7"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_9">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Occupation Wise Clients Registered <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="char9"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_10">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Demographic Area Wise Clients Registered <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="char10"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_11">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Parity Alive <?php echo $title_text; ?>
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:400px;height: 400px;">
                                                            <canvas id="char11"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--<div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Title
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div id="canvas-holder" style="width:90%">
                                                            <canvas id="ch1"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Title
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                <div id="canvas-holder" style="width:90%">
                                                    <canvas id="ch3"></canvas>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Title
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                <div id="canvas-holder" style="width:90%">
                                                    <canvas id="ch6"></canvas>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>-->

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
        }//end of mobile
        else {
            ?>
            <div class="page-content-wrapper">
                <div class="page-content"> 
                    <!-- BEGIN PAGE HEADER-->
                    <div class="row">
                        <div class="col-md-12">
                            Dashboard is not available for mobile version.
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        <!-- // Content END --> 
    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    if (!is_request_from_mobile()) {
        ?>

        <script>
            $(document).ready(function() {
                    
                    
            });
        </script>

        <script>
                        
            var chartColors = window.chartColors;
            var color = Chart.helpers.color;
                        
                        
            //start of new chart
            // var ctx = document.getElementById('ch1').getContext('2d');
            // var data = {
            //     labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
            //     datasets: [{
            //             label: 'Trendline ',
            //             borderColor: 'rgb(255, 99, 132)',
            //             data: [0, 10, 5, 2, 20, 30, 45]
            //         }]
            // };
            // var options = {};
            // var chart = new Chart(ctx, {
            //     type: 'line',
            //     data: data,
            //     options: options
            // });

            //start of All New Clients Consumptions Chart
            var ctx = document.getElementById('char2').getContext('2d');
            var data = {
                labels: [<?= '"' . implode('","', $all_new_clients_consumptions) . '"'; ?>],
                datasets: [{
                        label: 'Visits',
                        backgroundColor: [
    <?php
    for ($loop = 0; isset($all_new_clients_consumptions[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $new_clients_consumptions_total); ?>]
                }]
        };
        var options = {
            plugins: {
                legend: {
                    display: false
                },
            }};
        var chart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });
                        
                   

        //start of Method Mix chart
        //        var ctx = document.getElementById('ch10').getContext('2d');
        //        var data = {
        //            labels: [<?= '"' . implode('","', $all_method_mix) . '"'; ?>],
        //            datasets: [{
        //                    label: 'Method Mix',
        //                    backgroundColor: [
        //                    <?php
    for ($loop = 0; isset($all_method_mix[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>//
                        //                        "<?= $colors_new[$loop]; ?>",
                        //                        <?php
        }
    }
    ?>//
        //                    ],
        //                    data: [<?= implode(',', $method_mix_total); ?>]
        //                }]
        //        };
        //         
        //        var chart = new Chart(ctx, {
        //            type: 'doughnut',
        //            data: data,
        //            options: {
        //                responsive: true,
        //                legend: {
        //                    display: false
        ////                    position: "left",
        ////                    align: "middle"
        //                }
        //        }
        //        });

                    
        //start of FP Client Referrals chart
        var ctx = document.getElementById('ch_fp_cat').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_fp_cat) . '"'; ?>],
            datasets: [{
                    label: 'FP',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_fp_cat[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    // borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $fp_cat_total); ?>]
                }]
        };
                         
        var chart = new Chart(ctx, {
            type: 'doughnut',
            plugins: [ChartDataLabels],
            data: data,
            options: { 
                legend: {
                    display: true,
                    position: "right"
                },
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }}
            }
        });
                        
                        
        //start of visit purpose chart
        var ctx = document.getElementById('ch_purpose').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_visit_purpose) . '"'; ?>],
            datasets: [{
                    label: 'Purpose',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_visit_purpose[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    // borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $visit_purpose_total); ?>]
                }]
        };
                         
        var chart = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            plugins: [ChartDataLabels],
            options: { 
                legend: {
                    display: true,
                    position: "right",
                    align:"start"
                },
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }
                }
            }
        });
        //start of Client Referrals chart
        var ctx = document.getElementById('ch5').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_client_referrals) . '"'; ?>],
            datasets: [{
                    label: 'Client Referrals',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_client_referrals[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    // borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $client_referrals_total); ?>]
                }]
        };
                         
        var chart = new Chart(ctx, {
            type: 'doughnut',
            plugins: [ChartDataLabels],
            data: data,
            options: { 
                legend: {
                    display: true,
                    position: "right"
                },
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }}
            }
        });

        //start of Implanon Removal & Reasons Chart
        var ctx = document.getElementById('char3').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_implanon) . '"'; ?>],
            datasets: [{
                    label: 'Reasons And Removals',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_implanon[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $implanon_total); ?>]
                }]
        };
        var options = {
            plugins: {
                legend: {
                    display: false
                },
            }};
        var chart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });

        //start of IUCD Removal & Reasons Chart
        var ctx = document.getElementById('char4').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_iucd) . '"'; ?>],
            datasets: [{
                    label: 'Reasons And Removals',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_iucd[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $iucd_total); ?>]
                }]
        };
        var options = {
            plugins: {
                legend: {
                    display: false
                },
            }};
        var chart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });

        //start of Jadelle Removal & Reasons Chart
        var ctx = document.getElementById('char5').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_jadelle) . '"'; ?>],
            datasets: [{
                    label: 'Reasons And Removals',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_jadelle[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $jadelle_total); ?>]
                }]
        };
        var options = {
            plugins: {
                legend: {
                    display: false
                },
            }};
        var chart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });
                        
        //start of Age Chart
        var ctx = document.getElementById('ch4').getContext('2d');
        var data = {
            labels: ['Under 18', '18 to 24', '25 to 30', '31 to 35', '36 to 40', '41 to 45', '45 or Above'],
            datasets: [{
                    label: 'Clients Age Calculation',
                    backgroundColor: [
    <?php
    if (!empty($ages_data_graph)) {
        $loop = 0;
        ?>
        <?php
        foreach ($ages_data_graph as $key => $value) {
            if (!empty($colors_new[$loop])) {
                ?>
                                                "<?= $colors_new[$loop]; ?>",
                <?php
                $loop++;
            }
        }
        ?>
    <?php } ?>
                    ],
                    data: [<?= implode(',', $ages_data_graph); ?>]
                }]
        };
                        
        var chart = new Chart(ctx, {
            type: 'pie',
            plugins: [ChartDataLabels],
            data: data,
            options: {
                responsive: true,
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                legend: {
                    position: "right",
                    align: "middle"
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }}}
        });
                        
        //start of Educations Chart
        var ctx = document.getElementById('char7').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_educations) . '"'; ?>],
            datasets: [{
                    label: 'Education',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_educations[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    data: [<?= implode(',', $total); ?>]
                }]
        };
                        
        var chart = new Chart(ctx, {
            type: 'pie',
            plugins: [ChartDataLabels],
            data: data,
            options: {
                responsive: true,
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                legend: {
                    position: "right",
                    align: "middle"
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }}}
        });

        //start of Occupations Chart
        var ctx = document.getElementById('char9').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_occupations) . '"'; ?>],
            datasets: [{
                    label: 'Occupation',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_occupations[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    data: [<?= implode(',', $occupations_total); ?>]
                }]
        };
        var chart = new Chart(ctx, {
            type: 'pie',
            plugins: [ChartDataLabels],
            data: data,
            options: {
                responsive: true,
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                legend: {
                    display: false,
                    //                    position: "right",
                    //                    align: "middle"
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }}}
        });

        //start of Demographic Characteristics Chart
        var ctx = document.getElementById('char10').getContext('2d');
        var data = {
            labels: [<?= '"' . implode('","', $all_demographic_characteristics) . '"'; ?>],
            datasets: [{
                    label: 'Demographic Characteristics',
                    backgroundColor: [
    <?php
    for ($loop = 0; isset($all_demographic_characteristics[$loop]); $loop++) {
        if (!empty($colors_new[$loop])) {
            ?>
                                        "<?= $colors_new[$loop]; ?>",
            <?php
        }
    }
    ?>
                    ],
                    data: [<?= implode(',', $demographic_characteristics_total); ?>]
                }]
        };
        var options = {};
        var chart = new Chart(ctx, {
            type: 'pie',
            plugins: [ChartDataLabels],
            data: data,
            options: {
                responsive: true,
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                legend: {
                    position: "right",
                    align: "middle"
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }}}
        });

        //start of Parity Chart
        var ctx = document.getElementById('char11').getContext('2d');
        var data = {
            labels: ['1 to 2 child', '3 to 4 child', '5 to 6 child', '7 to 10 child', '>10 child', 'No Child', 'No Data Provided'],
            datasets: [{
                    label: 'Parity Alive',
                    backgroundColor: [
    <?php
    if (!empty($parities_data_graph)) {
        $loop = 0;
        ?>
        <?php
        foreach ($parities_data_graph as $key => $value) {
            if (!empty($colors_new[$loop])) {
                ?>
                                                "<?= $colors_new[$loop]; ?>",
                <?php
                $loop++;
            }
        }
        ?>
    <?php } ?>
                    ],
                    data: [<?= implode(',', $parities_data_graph); ?>]
                }]
        };
        var options = {};
        var chart = new Chart(ctx, {
            type: 'pie',
            plugins: [ChartDataLabels],
            data: data,
            options: {
                responsive: true,
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },
                legend: {
                    position: "right",
                    align: "middle"
                },
                plugins:{
                                                
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }}}
        });

        //start of new chart
        // var ctx = document.getElementById('ch3').getContext('2d');
        // var data = {
        //     labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        //     datasets: [{
        //             label: 'Monthly Comparison',
        //             backgroundColor: [
        //                 color(chartColors.red).alpha(0.5).rgbString(),
        //                 color(chartColors.orange).alpha(0.7).rgbString(),
        //                 color(chartColors.yellow).alpha(0.8).rgbString(),
        //                 color(chartColors.green).alpha(0.7).rgbString(),
        //                 color(chartColors.blue).alpha(0.8).rgbString(),
        //                 color(chartColors.red).alpha(0.9).rgbString(),
        //             ],
        //             //                    borderColor: 'rgb(250, 105, 185)',
        //             data: [0, 10, 5, 2, 20, 30, 45]
        //         }]
        // };
        // var options = {};
        // var chart = new Chart(ctx, {
        //     type: 'radar',
        //     data: data,
        //     options: options
        // });
                        
        // //start of new chart
        // var ctx = document.getElementById('ch6').getContext('2d');
        // var data = {
        //     labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        //     datasets: [{
        //             label: 'Monthly Comparison',
        //             backgroundColor: [
        //                 color(chartColors.red).alpha(0.5).rgbString(),
        //                 color(chartColors.orange).alpha(0.7).rgbString(),
        //                 color(chartColors.yellow).alpha(0.8).rgbString(),
        //                 color(chartColors.green).alpha(0.7).rgbString(),
        //                 color(chartColors.blue).alpha(0.8).rgbString(),
        //                 color(chartColors.red).alpha(0.9).rgbString(),
        //             ],
        //             //                    borderColor: 'rgb(250, 105, 185)',
        //             data: [0, 10, 5, 2, 20, 30, 45]
        //         }]
        // };
        // var options = {};
        // var chart = new Chart(ctx, {
        //     type: 'polarArea',
        //     data: data,
        //     options: options
        // });
                        
                        
                       
                		
        </script>

        <?php
    }
    ?>
</body>
</html>