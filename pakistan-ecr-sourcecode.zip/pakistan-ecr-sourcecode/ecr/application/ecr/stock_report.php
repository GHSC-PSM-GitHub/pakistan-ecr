<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$from_date = date('Y-m-01');
$to_date = date('Y-m-d');
$indicator = '';

$wh_id = '0';
if (!empty($_SESSION['user_warehouse']) && $_SESSION['user_level'] == '7') {
    $wh_id = $_SESSION['user_warehouse'];
}
elseif (!empty($_REQUEST['wh_id'])){
    $wh_id = $_REQUEST['wh_id'];
}


if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
if (!empty($_REQUEST['to_date']))
    $to_date = $_REQUEST['to_date'];
//if(!empty($_REQUEST['indicator']))$indicator=$_REQUEST['indicator'];


if (!empty($_REQUEST['stakeholder'])){
    $stakeholder = $_REQUEST['stakeholder'];
}
else{
    $stakeholder = 9;
}
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
    <link rel="stylesheet" type="text/css" href="../../public/assets/global/plugins/select2/select2.css"/>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Live ECR Stock Tracker</h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">Date <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $to_date ?>"   max="<?= date('Y-m-d') ?>" id="to_date" name="to_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">Stakeholder</label>
                                                    <div class="controls">
                                                        <select name="stakeholder" id="stakeholder" class="input-large  select2me" onchange="change_stk()" >

                                                            <?php
                                                            $qry = "SELECT
                                                                                        distinct stakeholder.stkname, 
                                                                                        stakeholder.stkid 
                                                                                FROM
                                                                                        stakeholder
                                                                                        INNER JOIN
                                                                                        tbl_warehouse
                                                                                        ON 
                                                                                                stakeholder.stkid = tbl_warehouse.stkid
                                                                                WHERE
                                                                                        tbl_warehouse.ecr_start_month is not null
                                                                                                                                                   ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            $stk_name = '';
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                $sel = '';

                                                                if($stakeholder == $row['stkid']){
                                                                    $sel =  'selected="selected"';
                                                                    $stk_name = $row['stkname'];
                                                                }
                                                                echo "<option value=\"" . $row['stkid'] . "\" $sel>" . $row['stkname'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">District</label>
                                                    <div class="controls" id="districtsCol">
                                                        <select name="district" id="district" class="form-control " onchange="change_dist()" >

                                                            <?php
                                                            if ($_SESSION['user_level'] < '3') {
//                                                                echo '<option value="">All</option>';
                                                            }
                                                            if ($_SESSION['user_level'] == 1 && $_SESSION['user_province1'] == 2){
                                                                $prov_helper = " IN (2,4) ";
                                                            }
                                                            else{
                                                                $prov_helper = " = '". $_SESSION['user_province1']. "'";
                                                            }
                                                            $qry = "SELECT
                                                                            distinct PkLocID,
                                                                            LocName
                                                                    FROM
                                                                            tbl_locations

                                                                    INNER JOIN
                                                                    tbl_warehouse
                                                                    ON
                                                                            tbl_locations.PkLocID = tbl_warehouse.dist_id
                                                                    WHERE
                                                                            ParentID $prov_helper AND LocLvl = '3' AND
                                                                    tbl_warehouse.stkid = $stakeholder
                                                                    ORDER BY
                                                                        LocName
                                                                               ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                if ($_SESSION['user_level'] > '2' && !empty($_SESSION['user_district'])) {
                                                                    $district = $_SESSION['user_district'];
                                                                    if ($row['PkLocID'] != $_SESSION['user_district'])
                                                                        continue;
                                                                }
                                                                $sel = ($_REQUEST['district'] == $row['PkLocID']) ? 'selected="selected"' : '';
                                                                echo "<option value=\"" . $row['PkLocID'] . "\" $sel>" . $row['LocName'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>


                                            <?php
                                            if ($_SESSION['user_level'] < '7') {
                                                $prov_id = $_SESSION['user_province1'];
                                                $hf_arr = array();
                                                $qry = "SELECT 
                                                                tbl_warehouse.wh_id,tbl_warehouse.wh_name, 
                                                                tbl_locations.LocName as dist_name FROM
                                                            tbl_warehouse
                                                                INNER JOIN
                                                                tbl_locations
                                                                ON 
                                                                        tbl_warehouse.dist_id = tbl_locations.PkLocID
                                                            WHERE
                                                            tbl_warehouse.stkid = '" . $stakeholder . "'
                                                            AND tbl_warehouse.prov_id= '" . $prov_id . "' 
                                                            AND tbl_warehouse.is_active = 1 
                                                            and ecr_start_month is not null ";
                                                if ($_SESSION['user_level'] == '3'){
                                                $qry .=" AND tbl_warehouse.dist_id= '" . $_SESSION['user_district'] . "'  ";
                                                }
                                                $qry .="
                                                    ORDER BY tbl_locations.LocName,tbl_warehouse.wh_name        

                                                    ";
//                                        echo $qry;exit;
                                                $qryRes = mysql_query($qry);
                                                while ($row = mysql_fetch_assoc($qryRes)) {
                                                    $hf_arr[] = $row;
                                                }
                                                $hf_count = count($hf_arr);
                                                //echo '<pre>';
                                                //print_r($hf_arr);
                                                //echo '</pre>';
                                                //exit; 
                                                ?>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="control-label" for="selectbasic">Health Facility <span class="font-red">*</span> </label>
                                                        <div class="controls" id="hf_div">
                                                            <select required id="wh_id" name="wh_id" class="input-large  select2me">


                                                                <?php
                                                                $wh_name = '';
                                                                if (!empty($hf_count) && $hf_count > 1) {
                                                                    echo '<option value=""> SELECT </option>';
                                                                }
                                                                foreach ($hf_arr as $k => $val) {
                                                                    if($val['wh_id'] == $wh_id){
                                                                        $wh_name = $val['wh_name'];
                                                                        $sel =' selected ';
                                                                    }else{
                                                                        $sel = '';
                                                                    }
                                                                    
                                                                    echo ' <option '.$sel.' value="' . $val['wh_id'] . '">'.$val['dist_name'].' - ' . $val['wh_name'] . '</option>';
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                            ?>


                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body"  style="overflow: auto;">
                                        <img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        
                                        <h4>Live Stock Tracking : <?php echo @$wh_name;?></h4>
                                        
                                        <?php
                                        $from_date = date('Y-m-01', strtotime($to_date));

                                        $prev_month = date('Y-m-01', strtotime("-1 month", strtotime($from_date)));

                                        $begin = new DateTime($from_date);
                                        $end = new DateTime($to_date);
                                        $date_arr = array();
                                        for ($i = $begin; $i <= $end; $i->modify('+1 day')) {
                                            $this_date = $i->format("Y-m-d");
                                            $date_arr[$this_date] = $this_date;
                                        }


                                        $qry3 = "SELECT
                                                tbl_warehouse.wh_id, 
                                                tbl_warehouse.wh_name, 
                                                tbl_warehouse.dist_id, 
                                                tbl_warehouse.ecr_start_month, 
                                                dist.LocName as dist_name
                                        FROM
                                                tbl_warehouse
                                                INNER JOIN
                                                tbl_locations AS dist
                                                ON 
                                                        tbl_warehouse.dist_id = dist.PkLocID
                                        WHERE
                                                tbl_warehouse.ecr_start_month IS NOT NULL AND
                                                prov_id = 2 AND
                                                stkid = 1";
//                                        if (!empty($district)) {
//                                            $qry3 .= " and tbl_warehouse.dist_id = '" . $district . "' ";
//                                        }
                                        if (!empty($wh_id)) {
                                            $qry3 .= " and tbl_warehouse.wh_id = '" . $wh_id . "' ";
                                        }
//                                           echo $qry2;exit;
                                        $res3 = mysql_query($qry3);
                                        $wh_arr = array();
                                        while ($row = mysql_fetch_assoc($res3)) {
                                            $wh_arr[] = $row;
                                        }

                                        $qry2 = "
                                            SELECT *, 
                                                itminfo_tab.itm_name
                                            From 
                                                tbl_hf_data 
                                            INNER JOIN
                                                itminfo_tab
                                            ON 
                                                    tbl_hf_data.item_id = itminfo_tab.itm_id
                                             where 
                                                warehouse_id = '" . $wh_id . "' and reporting_date='" . $prev_month . "' AND
	itminfo_tab.itm_category = 1 and itm_id <> 10578
                                        ";
//                                           echo $qry2;exit;
                                        $res2 = mysql_query($qry2);
                                        $ob_arr = $item_arr = array();
                                        while ($row = mysql_fetch_assoc($res2)) {
                                            $item_arr[$row['item_id']] = $row['itm_name'];
                                            $ob_arr[$row['item_id']] = $row;
                                        }
//                                        echo '<pre>';
//                                        print_r($items_fp);
//                                        print_r($item_arr);
//                                        echo '</pre>';
//                                        exit;



                                        $qry5 = "
                                            SELECT *, 
                                                itminfo_tab.itm_name
                                            From 
                                                tbl_hf_data 
                                            INNER JOIN
                                                itminfo_tab
                                            ON 
                                                    tbl_hf_data.item_id = itminfo_tab.itm_id
                                             where 
                                                warehouse_id = '" . $wh_id . "' and reporting_date='" . $from_date . "' AND
	itminfo_tab.itm_category = 1 and itm_id <> 10578
                                        ";
//                                           echo $qry5;exit;
                                        $res5 = mysql_query($qry5);
                                        $rcv_arr = array();
                                        while ($row = mysql_fetch_assoc($res5)) {
                                            $rcv_arr[$row['item_id']] = $row['received_balance'];
                                            $adjp_arr[$row['item_id']] = $row['adjustment_positive'];
                                            $adjn_arr[$row['item_id']] = $row['adjustment_negative'];
                                        }

//                                        echo '<pre>';
//                                        print_r($rcv_arr);
//                                        print_r($adjp_arr);
//                                        print_r($adjn_arr);
//                                        echo '</pre>';
//                                        exit;

                                        $qry = "
                                           Select a.wh_id, wh_name,date_of_visit,fp_method, 
	SUM(a.issuance) as issuance
	from
( (
                                                    SELECT  
                                                            ecr_client_visits.wh_id, 
                                                            ecr_client_visits.wh_name,
                                                            ecr_client_visits.date_of_visit,
                                                            ecr_client_visits.fp_method, 
                                                            SUM(ecr_client_visits.fp_qty) as issuance
                                                    FROM
                                                            ecr_client_visits
                                                            where fp_method > 0
                                                            and date_of_visit between '" . $from_date . "' and '" . $to_date . "' ";
                                            $qry .=" and ecr_client_visits.wh_id='" . $wh_id . "' ";
                                        $qry .="
                                                            group by 

                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.fp_method
                                                            order by 
                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.fp_method
                                                    )
                                                    UNION ALL
                                                    (
                                                    SELECT  
                                                            ecr_client_visits.wh_id, 
                                                            ecr_client_visits.wh_name,
                                                            ecr_client_visits.date_of_visit,
                                                            ecr_client_visits.additional_item, 
                                                            SUM(ecr_client_visits.additional_item_qty) as issuance
                                                    FROM
                                                            ecr_client_visits
                                                            where additional_item >0
                                                            and date_of_visit between '" . $from_date . "' and '" . $to_date . "' ";
                                            $qry .=" and ecr_client_visits.wh_id='" . $wh_id . "' ";
                                        $qry .="
                                                            group by 

                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.additional_item
                                                            order by 
                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.additional_item
                                                    )
) as a
group by 	
	a.wh_id,
	a.date_of_visit, 
	a.fp_method


                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            @$data_arr[$row['fp_method']][$row['date_of_visit']] += $row['issuance'];
                                        }
//                                        echo '<pre>';
//                                        print_r($data_arr);
//                                        echo '</pre>';  
//                                        exit;

                                        $c = 1;

                                        $cb_arr = $iss_till_date = array();
                                        echo '<table id="table_1" class="table table-bordered table-condensed">';
                                        echo '<tr class="bg-info">';
                                        echo '<td>#</td>';
                                        echo '<td> Item</td>';
                                        echo '<td class="bg-warning"> Closing Balance of :' . date('M-Y', strtotime($prev_month)) . '</td>';
                                        echo '<td class="bg-success"> Received in :' . date('M-Y', strtotime($from_date)) . '</td>';
                                        echo '<td class="bg-success"> Pos Adj ' . date('M-Y', strtotime($from_date)) . '</td>';
                                        echo '<td class="bg-success"> Neg Adj ' . date('M-Y', strtotime($from_date)) . '</td>';
                                        foreach ($date_arr as $k => $v) {
                                            echo '<td><a href="facility_visits_list.php?from_date='. date('Y-m-d', strtotime($v)) .'&fac_id='.$wh_id.'">' . date('d-M', strtotime($v)) . '</a></td>';
                                        }
                                        echo '<td class="bg-warning"> Stock On Hand</td>';
                                        echo '</tr>';


                                        foreach ($item_arr as $itm_id => $item_row) {
                                            if(!empty($items_fp[$itm_id])){
                                                $item_name = $items_fp[$itm_id];
                                            }
                                            else{
                                                continue;
                                            }
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $item_name . '</td>';
                                            echo '<td align="right"  class="bg-warning">' . number_format($ob_arr[$itm_id]['closing_balance']) . '</td>';
                                            echo '<td align="right"  class="bg-success">' . number_format($rcv_arr[$itm_id]) . '</td>';
                                            echo '<td align="right"  class="bg-success">' . number_format($adjp_arr[$itm_id]) . '</td>';
                                            echo '<td align="right"  class="bg-success">' . number_format($adjn_arr[$itm_id]) . '</td>';
                                            $cb_arr[$itm_id] = 0;
                                            $iss_till_date[$itm_id] = 0;
                                            if (!empty($ob_arr[$itm_id]['closing_balance'])) {
                                                $cb_arr[$itm_id] = $ob_arr[$itm_id]['closing_balance'] ;
                                            } else {
                                                $cb_arr[$itm_id] = 0;
                                            }
                                            
                                            if(!empty($rcv_arr[$itm_id] )) {
                                                $cb_arr[$itm_id] += $rcv_arr[$itm_id];
                                            }
                                            if(!empty($adjp_arr[$itm_id])) {
                                                $cb_arr[$itm_id] += $adjp_arr[$itm_id];
                                            }
                                            if(!empty($adjn_arr[$itm_id])) {
                                                $cb_arr[$itm_id] -= $adjn_arr[$itm_id];
                                            }
                                            
                                            foreach ($date_arr as $k => $v) {
                                                if (!empty($data_arr[$itm_id][$v])) {
                                                    $cb_arr[$itm_id] -= $data_arr[$itm_id][$v];
                                                    $iss_till_date[$itm_id] += $data_arr[$itm_id][$v];
                                                }
                                                if (!empty($cb_arr[$itm_id]) && $cb_arr[$itm_id] < 0 && !empty($data_arr[$itm_id][$v]) && $data_arr[$itm_id][$v] > 0) {
                                                    $cls = " bg-danger ";
                                                } else {
                                                    $cls = "";
                                                }
                                                echo '<td class="' . $cls . '" align="right" title="Stock On '.$k.':&#013;&#013;Issued till date: '.$iss_till_date[$itm_id].' &#013;Balance Till Date:'.$cb_arr[$itm_id]. '"><a href="facility_visits_list.php?from_date='. date('Y-m-d', strtotime($v)) .'&fac_id='.$wh_id.'&item_id='.$itm_id.'" style="color: black;" >' . @number_format($data_arr[$itm_id][$v]) .'</a></td>';
                                            }


                                            if (!empty($cb_arr[$itm_id]) && $cb_arr[$itm_id] < 0) {
                                                $cls2 = " bg-danger ";
                                            } else {
                                                $cls2 = "";
                                            }
                                            echo '<td class="' . $cls2 . '" align="right">' . number_format($cb_arr[$itm_id]) . '</td>';
                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                        NOTE : Please note that, this report can only show correct data if closing balance of last month is reported correctly. So please double check the figures in last months consumption data entry screen.
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

    <script>
        change_dist();
        function change_stk(){
            const stk = $('#stakeholder').val();
            $.ajax({
                url: "ajax_stk_dist.php",
                type: 'post',
                data: {
                    stk: stk
                },
                success: function(html){
                    $("#districtsCol").html(html);
                }
            });
            change_dist();
        }

        function change_dist(){
            const stk = $('#stakeholder').val();
            const dist = $('#district').val();
            const sel_hf = <?= $wh_id ?>;

            $.ajax({
                url: "ajax_dist_hf.php",
                type: 'post',
                data: {
                    stk: stk,
                    dist: dist,
                    sel_hf: sel_hf
                },
                success: function(html){
                    $("#hf_div").html(html);
                    $('#wh_id').select2();
                }
            });
        }
    </script>

    <script type="text/javascript" src="../../public/assets/global/plugins/select2/select2.min.js"></script>
<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>