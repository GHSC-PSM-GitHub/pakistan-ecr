<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;
?>
<link href="<?php echo PUBLIC_URL; ?>assets/global/css/components-rounded.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo PUBLIC_URL; ?>assets/global/css/profile.css" rel="stylesheet" type="text/css"/>

</head>

<?php
if (!empty($_SESSION['landing_page_stats'])) {
//if (false) {
    $landing_page_stats = $_SESSION['landing_page_stats'];
    $wh_info = $_SESSION['wh_info'];
} else {
    $qry = "
            Select 'fac' as module,count(*) as num from tbl_warehouse 
                left JOIN 	stakeholder	ON 		tbl_warehouse.stkofficeid = stakeholder.stkid 
                where tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' and is_active='1' and lvl = 7
            UNION ALL
            Select 'ecr' as module,count(*) as num from tbl_warehouse where tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' and ecr_start_month is not null    
            UNION ALL
            Select 'clients',count(*) from ecr_clients  	
                INNER JOIN tbl_warehouse
                ON  ecr_clients.registered_at = tbl_warehouse.wh_id WHERE tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."'
            UNION ALL
            Select 'visits',count(*) from ecr_client_visits 
                INNER JOIN ecr_clients on ecr_client_visits.client_id = ecr_clients.pk_id
                INNER JOIN tbl_warehouse ON  ecr_clients.registered_at = tbl_warehouse.wh_id WHERE tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."'
            UNION ALL
            SELECT 'old',count(*) FROM ecr_clients INNER JOIN tbl_warehouse
                ON  ecr_clients.registered_at = tbl_warehouse.wh_id WHERE tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' and crc_new_old = 'old'
            UNION ALL
            SELECT 'new',count(*) FROM ecr_clients INNER JOIN tbl_warehouse
                ON  ecr_clients.registered_at = tbl_warehouse.wh_id WHERE tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' and crc_new_old <> 'old'
             
        ";
    if ($_SESSION['user_level'] == '3' && !empty($_SESSION['user_district'])) {
        $qry .= "

            UNION ALL
            Select 'dist_fac' as module,count(*) as num from tbl_warehouse 	INNER JOIN	stakeholder	ON tbl_warehouse.stkofficeid = stakeholder.stkid where tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' and is_active='1' and dist_id = '" . $_SESSION['user_district'] . "' and stakeholder.lvl = 7
            UNION ALL
            Select 'dist_ecr' as module,count(*) as num from tbl_warehouse where tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' and ecr_start_month is not null and dist_id = '" . $_SESSION['user_district'] . "'
            ";
    }
    if ($_SESSION['user_level'] == '7' && !empty($_SESSION['user_warehouse'])) {
        $qry .= "

            UNION ALL
            Select 'fac_clients',count(*) from ecr_clients   where registered_at = '" . $_SESSION['user_warehouse'] . "'
            UNION ALL
            Select 'fac_visits',count(*) from ecr_client_visits INNER JOIN ecr_clients on ecr_client_visits.client_id = ecr_clients.pk_id  where wh_id = '" . $_SESSION['user_warehouse'] . "' ";
    }
//    echo $qry;exit;
    $res = mysql_query($qry);
    $landing_page_stats = array();
    while ($row = mysql_fetch_assoc($res)) {
        $landing_page_stats[$row['module']] = $row['num'];
    }
    $_SESSION['landing_page_stats'] = $landing_page_stats;

//    echo '<pre>';
//    print_r($_SESSION);
//    echo '</pre>';
//    exit;
}
?>


<body class="page-header-fixed page-quick-sidebar-over-content">
    <!-- BEGIN HEADER -->
    <div class="page-container">
        <?php include $_SESSION['menu']; ?>
        <div class="page-content-wrapper" style="">
            <div class="page-content bg-grey">
                <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS</h3>
                <?php
                if ($_SERVER['SERVER_NAME'] == 'c.lmis.gov.pk') {
                    echo '<a href="https://play.google.com/store/apps/details?id=com.electronic_client_record&pcampaignid=web_share" download>Click to Download Android Application of ECR Module ( LIVE )</a>';
                } else {
//                    echo '<a href="../../user_uploads/ecr/ecr_test.apk" download>Click to Download Android Application of ECR Module ( BETA )</a>';
                }
                ?>
                <?php
                if (!is_request_from_mobile()) {
                    ?>
                    <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx" style="margin-bottom: 20px;" style="margin-bottom: 20px;"><i class="fa fa-download"></i> Download FP Client Register</a>
                    <?php
                }
                ?>
                <div class="row margin-top-10">
<div class="col-md-12">
                    <div class="col-lg-12 col-md-12">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="dashboard-stat2">
                            <span class="notex note-infox "><h3 class="font-green-sharp">System Update: </h3>Please note that, we have released new version of ECR. In FP Visits, a new Radio button is included: 'Type of Visit', therefore you will now see separate indicators for 'Issuance' & 'Referrals'.</span>
                        </div>
                    </div>
                    </div>
                    </div>
                    <?php
                    
if(!empty($min_date) && $min_date!=$ecr_start){
    ?>
                    <div class="col-md-12">
                    <div class="col-lg-12 col-md-12">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="dashboard-stat2">
                            <span class="notex note-infox "><h3 class="font-red-haze">Announcement: </h3>Please note that previous data has been locked. Your facility is only allowed to add or modify data since : <?php echo date('jS F Y',strtotime($min_date))?></span>
                        </div>
                    </div>
                    </div>
                    </div>
                    <?php
                    }
                    ?>
                    
                    <div class="col-md-12">
                        <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12">

                            <div class="col-md-12 ">
                                <div class="dashboard-stat2">
                                    <!-- STAT -->
<?php
if ($_SESSION['user_level'] > '2') {
    ?>
                                        <!-- END STAT -->
                                        <div>
                                            <h3 class=""><?= $_SESSION['user_name'] ?></h3>
                                            <h4 class=""><?= $wh_info['wh_name'] ?></h4>
                                            <hr/>
                                            <div class="margin-top-10 profile-desc-link"><i class="fa fa-globe font-blue-madison"></i>      &nbsp;Province:<a class="pull-right"><?= @$wh_info['prov_name'] ?></a></div>
                                            <div class="margin-top-10 profile-desc-link"><i class="fa fa-map-marker font-blue-madison"></i> &nbsp;District:<a class="pull-right"><?= @$wh_info['dist_name'] ?></a></div>
        <!--                                    <div class="margin-top-10 profile-desc-link"><i class="fa fa-building font-blue-madison"></i>   &nbsp;Department:<a class="pull-right"><?= @$wh_info['stkname'] ?></a></div>-->
                                            <div class="margin-top-10 profile-desc-link"><i class="fa fa-clock-o font-blue-madison"></i>    &nbsp;Started On:<a class="pull-right"><?= @date('Y-M-d', strtotime($wh_info['reporting_start_month'])) ?></a></div>
                                            <div class="margin-top-10 profile-desc-link"><i class="fa fa-sort-amount-desc font-blue-madison"></i>&nbsp;Level:<a class="pull-right"><?= @$wh_info['lvl_name'] ?></a></div>

    <?php
    if (!empty($wh_info['parent_fac']) && $wh_info['parent_fac'] > '0') {
        ?>
                                                <div class="margin-top-10 profile-desc-link"><i class="fa fa-h-square font-blue-madison"></i>&nbsp;Parent Hospital:<a class="pull-right"><?= @$wh_info['parent_fac'] ?></a></div>
                                                <?php
                                            }
                                            ?>
                                            <?php
                                            if (!empty($wh_info['ecr_start_month'])) {
                                                ?>
                                                <div class=" margin-top-20 well center" align="center">

                                                    <h4 class="font-green align-center">ECR Reporting : <span class="label label-success center"><i class="fa fa-check font-white"></i> Enabled</span></h4>
                                                    
        <?php
        if (!empty($wh_info['ecr_start_month']) && $wh_info['ecr_start_month'] != '0000-00-00') {
            ?>
                                                        <div class="margin-top-10 profile-desc-link">&nbsp; ECR Enabled Since : <span class="label label-info center"><i class="fa fa-calendar font-white"></i> <?= date('jS M Y', strtotime(@$wh_info['ecr_start_month'])) ?></span></div>
                                                        
                                                        <?php
                                                    }
                                                    ?>
                                                        <?php
        if (!empty($wh_info['ecr_data_open_since']) && $wh_info['ecr_data_open_since'] != '0000-00-00') {
            ?>
                                                        <div class="margin-top-10 profile-desc-link">&nbsp; Modifications Allowed Since : <span class="label label-warning center"><i class="fa fa-pencil font-white"></i> <?= date('jS M Y', strtotime(@$wh_info['ecr_data_open_since'])) ?></span></div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                                    <?php
                                                }
                                                ?>
                                        </div>
                                            <?php
                                        } else {
                                            ?>
                                        <div>
                                            <h3 class=""><?= $_SESSION['user_name'] ?></h3>
                                            <h4 class=""><?= $wh_info['wh_name'] ?></h4>
                                            <hr/>
                                            <div class="margin-top-10 profile-desc-link"><i class="fa fa-sort-amount-desc font-blue-madison"></i>&nbsp;Level:<a class="pull-right">Provincial</a></div>

                                        </div>
    <?php
}
?>
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-8 col-md-8">
<?php
if ($_SESSION['user_level'] < '7') {
    ?>
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <div class="dashboard-stat2">
                                        <div class="display">
                                            <div class="number">
                                                <h3 class="font-green-sharp"><?= $landing_page_stats['fac']; ?><small class="font-green-sharp"></small></h3>
                                                <small>Total Facilities in your province</small>
                                            </div>
                                            <!--                                    <div class="icon">
                                                                                    <i class="icon-pin"></i>
                                                                                </div>-->
                                        </div>
                                        <div class="progress-info">
                                            <div class="progress">
                                                <span style="width: 100%;" class="progress-bar progress-bar-success green-sharp">
                                                    <span class="sr-only"></span>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <div class="dashboard-stat2">
                                        <div class="display">
                                            <div class="number">
                                                <h3 class="font-red-haze"><?= @$landing_page_stats['ecr']; ?></h3>
                                                <small>Facilities Upgraded to ECR in your province</small>
                                            </div>
                                            <!--                                    <div class="icon">
                                                                                    <i class="icon-bag"></i>
                                                                                </div>-->
                                        </div>
                                        <div class="progress-info">
                                            <div class="progress">
                                                <span style="width: <?= @$landing_page_stats['ecr'] * 100 / $landing_page_stats['fac']; ?>%;" class="progress-bar progress-bar-success red-haze">
                                                    <span class="sr-only"></span>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
    <?php
}

if ($_SESSION['user_level'] == '7') {
    ?>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="dashboard-stat2">
                                        <div class="display">
                                            <div class="number">
                                                <h3 class="font-green-sharp"><?= $landing_page_stats['fac_clients']; ?><small class="font-green-sharp"></small></h3>
                                                <small>Registrations at your facility</small>
                                            </div>
                                            <!--                                    <div class="icon">
                                                                                    <i class="icon-pin"></i>
                                                                                </div>-->
                                        </div>
                                        <div class="progress-info">
                                            <div class="progress">
                                                <span style="width: 100%;" class="progress-bar progress-bar-success green-sharp">
                                                    <span class="sr-only"></span>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="dashboard-stat2">
                                        <div class="display">
                                            <div class="number">
                                                <h3 class="font-red-haze"><?= @$landing_page_stats['fac_visits']; ?></h3>
                                                <small>Total Visits at your facility</small>
                                            </div>
                                            <!--                                    <div class="icon">
                                                                                    <i class="icon-bag"></i>
                                                                                </div>-->
                                        </div>
                                        <div class="progress-info">
                                            <div class="progress">
                                                <span style="width: 100%;" class="progress-bar progress-bar-success red-haze">
                                                    <span class="sr-only"></span>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
    <?php
}

if ($_SESSION['user_level'] == '3') {
    ?>
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <div class="dashboard-stat2">
                                        <div class="display">
                                            <div class="number">
                                                <h3 class="font-green-sharp"><?= $landing_page_stats['dist_fac']; ?><small class="font-green-sharp"></small></h3>
                                                <small>Total Facilities in Your District</small>
                                            </div>
                                            <!--                                    <div class="icon">
                                                                                    <i class="icon-pin"></i>
                                                                                </div>-->
                                        </div>
                                        <div class="progress-info">
                                            <div class="progress">
                                                <span style="width: 100%;" class="progress-bar progress-bar-success green-sharp">
                                                    <span class="sr-only"></span>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <div class="dashboard-stat2">
                                        <div class="display">
                                            <div class="number">
                                                <h3 class="font-red-haze"><?= @$landing_page_stats['dist_ecr']; ?></h3>
                                                <small>Facilities Upgraded to ECR in Your District</small>
                                            </div>
                                            <!--                                    <div class="icon">
                                                                                    <i class="icon-bag"></i>
                                                                                </div>-->
                                        </div>
                                        <div class="progress-info">
                                            <div class="progress">
                                                <span style="width: <?= @$landing_page_stats['dist_ecr'] * 100 / $landing_page_stats['dist_fac']; ?>%;" class="progress-bar progress-bar-success red-haze">
                                                    <span class="sr-only"></span>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
    <?php
}
?>

                            <?php
                            if ($_SESSION['user_level'] == '2') {
                                echo '<div class="row"></div>';
                            }
                            ?>
                            <div class="  col-md-3 col-sm-6 col-xs-12">
                                <div class="dashboard-stat2">
                                    <div class="display">
                                        <div class="number">
                                            <h3 class="font-purple-soft"><?= @$landing_page_stats['clients']; ?></h3>
                                            <small>Total Clients in ECR System <br/> &nbsp;</small>
                                        </div>
                                        <div class="icon">
                                            <i class="icon-user"></i>
                                        </div>
                                    </div>
                                    <div class="progress-info">
                                        <div class="progress">
                                            <span style="width: 100%;" class="progress-bar progress-bar-success purple-soft">
                                                <span class="sr-only"></span>
                                            </span>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                            <!--                        <div class="  col-md-3 col-sm-6 col-xs-12">
                                                        <div class="dashboard-stat2">
                                                            <div class="display">
                                                                <div class="number">
                                                                    <h3 class="font-purple-soft"><?= @$landing_page_stats['new']; ?></h3>
                                                                    <small>New Clients in PWD Sindh ECR <br/> &nbsp;</small>
                                                                </div>
                                                                <div class="icon">
                                                                    <i class="icon-user"></i>
                                                                </div>
                                                            </div>
                                                            <div class="progress-info">
                                                                <div class="progress">
                                                                    <span style="width: <?= @$landing_page_stats['new'] * 100 / $landing_page_stats['clients']; ?>%;" class="progress-bar progress-bar-success red">
                                                                        <span class="sr-only"></span>
                                                                    </span>
                                                                </div> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="  col-md-3 col-sm-6 col-xs-12">
                                                        <div class="dashboard-stat2">
                                                            <div class="display">
                                                                <div class="number">
                                                                    <h3 class="font-purple-soft"><?= @$landing_page_stats['old']; ?></h3>
                                                                    <small>Old Clients in PWD Sindh ECR <br/> &nbsp;</small>
                                                                </div>
                                                                <div class="icon">
                                                                    <i class="icon-user"></i>
                                                                </div>
                                                            </div>
                                                            <div class="progress-info">
                                                                <div class="progress">
                                                                    <span style="width: <?= @$landing_page_stats['old'] * 100 / $landing_page_stats['clients']; ?>%;" class="progress-bar progress-bar-success blue">
                                                                        <span class="sr-only"></span>
                                                                    </span>
                                                                </div> 
                                                            </div>
                                                        </div>
                                                    </div>-->
                            <div class=" col-md-3 col-sm-6 col-xs-12">
                                <div class="dashboard-stat2">
                                    <div class="display">
                                        <div class="number">
                                            <h3 class="font-yellow"><?= @$landing_page_stats['visits']; ?></h3>
                                            <small>Total Visits in ECR System<br/> &nbsp;</small>
                                        </div>
                                        <div class="icon">
                                            <i class="icon-wrench"></i>
                                        </div>
                                    </div>
                                    <div class="progress-info">
                                        <div class="progress">
                                            <span style="width: 100%;" class="progress-bar progress-bar-success yellow">
                                                <span class="sr-only"></span>
                                            </span>
                                        </div> 
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
<?php
///// folllowing acccess is to be controlled to limited users only

if ($_SESSION['user_role'] == '2' && $_SESSION['user_level'] == '2') {
    ?>
                        <div class="row">
                            <div class="col-md-12">
                                <hr/>
                                <h4>Re-Consolidate ECR Data :</h4>                
                        <?php
                        $months = array();
                        for ($y = 2022; $y <= date('Y'); $y++) {
                            for ($m = 1; $m <= 12; $m++) {
                                ///// implementing hard limit of Oct 2022, because ECR launched in oct 2022
                                $month2 = $y . '-' . sprintf("%02d", $m) . '-01';
                                $launch_month = '2022-10-01';
                                if ($month2 < $launch_month) {
                                    continue;
                                }

                                if ($y == date('Y') && $m > date('m'))
                                    continue;

                                $mon = $m;
                                $mon = sprintf("%02d", $m);
                                $months[] = $y . '-' . $mon . '-01';
                            }
                        }

                        foreach ($months as $k => $mon) {
                            echo '<a target="_blank" class="btn btn-success"  href="aggregate_data.php?month='.$mon.'" style="margin-bottom: 20px;" ><i class="fa fa-laptop"></i> ' . date('M Y', strtotime($mon)) . '</a>';
                        }
                        ?>

                                <br/><span class="note note-info "> ( Click on any month, to quickly re-consolidate the client based data to monthly aggregated data )</span>

                            </div>
                        </div>
                                <?php
                            }
                            ?>

                </div>
            </div>
        </div>
                    <?php include PUBLIC_PATH . "/html/footer.php"; ?>
</body>
</html>