<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$id = '';
if (!empty($_REQUEST['client_id']))
    $id = htmlspecialchars($_REQUEST['client_id']);

$client_id = $id;
$items_fp = $items_larc = array();

$qry = "SELECT
                list_detail.pk_id,
                list_detail.list_value,
                list_detail.description,
                list_detail.rank,
                list_detail.reference_id,
                list_detail.parent_id,
                list_detail.list_master_id
            FROM
                list_detail
            ORDER BY
                list_detail.rank ,
                list_detail.list_value ASC
        ";
$qryRes = mysql_query($qry);
$list_arr = array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $list_arr[$row['list_master_id']][$row['pk_id']]['name'] = $row['list_value'];
    $list_arr[$row['list_master_id']][$row['pk_id']]['description'] = $row['description'];
}

$client_arr = $visit_arr = array();

if (!empty($_REQUEST['client_id'])) {
    $qry = "SELECT * FROM
                    ecr_clients
                WHERE 
                    pk_id = '" . $id . "'
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $client_arr = $row;
    }

    $qry = "SELECT * FROM
                    ecr_client_visits
                WHERE 
                    client_id = '" . $id . "'
                        ORDER BY pk_id desc
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $visit_arr[] = $row;
    }
//echo '<pre>';
//print_r($_SESSION);
//print_r($client_arr);
//echo '</pre>';
//exit;
}
?>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-green">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Clients Information</h3>
                            </div>
                            <div class="widget-body">
                                <div class="row">
                                    <div class="col-md-12 table-responsive">
<?php
if (!empty($_REQUEST['show_msg']) && !empty($msg_array[$_REQUEST['show_msg']]['txt'])) {
    if (!empty($msg_array[$_REQUEST['show_msg']]['cls'])) {
        $cls = $msg_array[$_REQUEST['show_msg']]['cls'];
    } else {
        $cls = 'success';
    }
    echo '<div class="col-md-12 col-lg-12"> <div class="note note-' . $cls . '" >' . $msg_array[$_REQUEST['show_msg']]['txt'] . '</div>  
                                                        </div>';
}
?>
                                        <table class="table table-bordered table-condensed table-striped">
                                            <tr>
                                                <th>Clients Name</th>
                                                <th>Father/Husband</th>
                                                <th>CNIC / Foreign ID</th>
                                                <th>Contact</th>
                                                <th>CRC</th>
                                                <th>Catchment</th>
                                                <th>Occupation</th>
                                                <th>Education</th>
                                                <th>Age Today</th>
                                                <th>Years of Marriage</th>
                                            </tr>
                                            <?php
                                            $v = $client_arr;

                                            echo '<tr>';
                                            echo '<td>' . ucfirst($v['client_name']) . '</td>';
                                            echo '<td>' . ucfirst($v['father_name']) . '</td>';
                                            echo '<td>';
                                            if(!empty($v['cnic'] && $v['nationality'] != 'others')){
                                                echo ''. $v['cnic'] . '';
                                            }
                                            if(!empty($v['nationality'] && $v['nationality'] != 'pakistani')){
                                                echo 'Nationality : '.ucfirst($v['nationality']).'<br/>ID:'. $v['foreigner_identity'] . '';
                                            }
                                            echo '</td>';
                                            echo '<td>' . $v['contact_number'] . '</td>';
                                            echo '<td>' . ucfirst($v['crc_new_old']) . '</td>';
                                            echo '<td>' . ucfirst($v['catchment_area']) . '</td>';
                                            echo '<td>' . ucfirst($v['occupation']) . '</td>';
                                            echo '<td>' . ucfirst($v['education']) . '</td>';
                                            echo '<td>' . $v['age_today'] . '</td>';
                                            echo '<td>' . $v['age_when_married'] . '</td>';
                                            echo '</tr>';
                                            
                                            $client_name = $v['client_name'];
                                            ?>
                                        </table>
                                        <?php
                                            if(!empty($client_arr['registered_at']) && $client_arr['registered_at']==$_SESSION['user_warehouse'])
                                            {
                                                echo '<a class="btn btn-xs btn-danger" href="edit_client.php?client_id='.$client_id.'"><i class="fa fa-pencil"></i> Edit Clients Personal Information </a>';
                                            }
                                             echo '<a class="btn btn-xs btn-success" href="add_visit.php?client_id='.$client_id.'"><i class="fa fa-plus"></i> Add A New Visit of '.ucwords($client_name).'</a>';
                                        
                                        ?>
                                        Registration Date: <?php
                                        
                                            echo '<td>' . date('Y-M-d',strtotime($v['created_on'])) . '</td>';
                                        
                                        ?>
                                    </div>
                                </div>

                            </div>



                        </div>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Previous Visits of "<?php echo ucwords($v['client_name']).'" ('.$v['serial_number'].')'?></h3>
                            </div>
                            <div class="widget-body">
                                <div class="row">
                                    <div class="col-md-12 table-responsive">

                                        <table class="table table-bordered table-condensed table-striped">
                                            <thead>
                                                <tr class="bg-success">
                                                    <th  >#</th>
                                                    <th  >Visit Info</th>
                                                    <th  >Last Pregnancy/Procedure</th>
                                                    <th  >Services Details</th>
                                                    <th  >Activity Info</th>
                                                    <th  >Action</th>
                                                </tr>
                                                
                                            </thead>
                                            <tbody>
                                                
                                                <?php
                                                $c=1;
                                                foreach($visit_arr as $k => $v){
                                                    echo '<tr>';
                                                    echo '<td>'.$c++.'</td>';
                                                    echo '<td>
<!--<ul class="list-group">
        <li class="list-group-item">Cras justo odio</li>      
        <li class="list-group-item">Cras justo odio</li>      
        <li class="list-group-item">Cras justo odio</li>      
</ul>        -->
<span class="bold">Facility:</span><span class="">'.$v['wh_name'].'</span> ';
                                                     echo '<br/><span class="bold">Date:</span><span class="">'.(!empty($v['date_of_visit'])?date('d-M-Y',strtotime($v['date_of_visit'])):'').'</span>';
                                                        echo ' </br><span class="bold">Reason:</span><span class="">'.$v['remarks_of_date'].'</span>';
                                                        echo ' </br><span class="bold">Purpose:</span><span class="">'.strtoupper($v['visit_purpose']).'</span></td>';
                                                    
                                                        echo '<td><span class="bold">Outcome:</span><span class="">'.ucfirst($v['outcome_last_preg']).'</span>
                                                                <br/><span class="bold">Alive: </span><span class="">'.(!empty($v['parity_alive'])?$v['parity_alive']:'0').' </span>';
                                                        echo '<br/><span class="bold">Death:</span><span class="">'.(!empty($v['parity_death'])?$v['parity_death']:'0').'</span>';
                                                   
                                                    echo '<br/><span class="bold">Period:</span><span class="">'.$v['period_from_last_preg'].'</span> ';
                                                    
                                                    echo '<td>';
                                                    
                                                    if(!empty($v['visit_purpose']))
                                                    {
                                                        
                                                        echo '<span class="badge badge-warning">Purpose of Visit: '.strtoupper($v['visit_purpose']).'</span><br/><br/>';
                                                        if($v['visit_purpose']=='fp'){
                                                            
                                                            echo '<span class="bold">Category:</span><span class="">'.$v['fp_category'].'</span>';
                                                            if(!empty($v['type_of_visit']) && $v['type_of_visit']=='1'){
                                                                echo '<br/><span class="bold">Type of Visit:</span><span class="">Issuance / Procedure</span>';
                                                            }
                                                            if(!empty($v['type_of_visit']) && $v['type_of_visit']=='2'){
                                                                echo '<br/><span class="bold">Type of Visit:</span><span class="">Referral to other facility</span>';
                                                            }
                                                            echo '<br/><span class="bold">Method:</span><span class="">'.$v['fp_method_name'].' : '.$v['fp_qty'].'</span>';
                                                            if(!empty($v['additional_item']) && $v['additional_item'] == '1'){
                                                                 echo '<br/><span class="bold">Additional RC:</span><span class="">'.$v['additional_item_qty'].'</span>';
                                                            }
                                                            echo '<br/><span class="bold">Ref by:</span><span class="">'.$v['fp_referred_from'].'('.$v['fp_referred_from_desig'].')</span>';
                                                            
                                                            //// in the following line, using both variables to display the 'Ref To', one of them is old one, other is new.
                                                            echo '<br/><span class="bold">Ref to:</span><span class="">'.$v['fp_referred_to'].$v['ref_to_fac_name'].'</span>';
                                                            echo '<br/><span class="bold">Ref for:</span><span class="">'.$v['fp_referred_for'].'</span>';
                                                            echo '<br/><span class="bold">Ref Reason:</span><span class="">'.$v['fp_reason_of_referral'].'</span>';
                                                            
                                                        }elseif($v['visit_purpose']=='ghs'){
                                                    
                                                            echo '<br/><span class="bold">Category:</span>'.$v['gen_health_category'].'';
                                                            echo '<br/><span class="bold">Diagnosis:</span>'.ucfirst($v['gen_health_diagnosis']).'';
                                                            echo '<br/><span class="bold">Treatment:</span>'.ucfirst($v['gen_health_treatment']).'';
                                                            echo '<br/><span class="bold">Ref To:</span>'.$v['gen_health_referred_to'].'</span>';
                                                    
                                                        }elseif($v['visit_purpose']=='larc_removal'){
                                                            
                                                            echo '<br/><span class="bold">Method:</span>'.$v['larc_method_name'].' ';
                                                            echo '<br/><span class="bold">Period:</span>'.$v['larc_period'].' ';
                                                            echo '<br/><span class="bold">Reason:</span>'.$v['larc_reason'].'</span>';
                                                            
                                                        }
                                                    
                                                    }
                                                    else{
                                                        // for now printing all info for old data... 
                                                        /// not necessary when launched
                                                            echo '<span class="badge badge-warning">FP Services:</span>';
                                                            echo '<br/><span class="bold">Category:</span><span class="">'.$v['fp_category'].'</span>';
                                                            echo '<br/><span class="bold">Method:</span><span class="">'.$v['fp_method_name'].' : '.$v['fp_qty'].'</span>';
                                                            echo '<br/><span class="bold">Ref by:</span><span class="">'.$v['fp_referred_from'].'('.$v['fp_referred_from'].')</span>';
                                                            echo '<br/><span class="bold">Ref to:</span><span class="">'.$v['fp_referred_to'].'</span>';
                                                            echo '<br/><span class="bold">Ref for:</span><span class="">'.$v['fp_referred_for'].'('.$v['fp_reason_of_referral'].')</span>';
                                                            
                                                    
                                                            echo '<br/><br/><span class="badge badge-warning">GHS:</span>';
                                                            echo '<br/><span class="bold">Category:</span>'.$v['gen_health_category'].'';
                                                            echo '<br/><span class="bold">Diagnosis:</span>'.ucfirst($v['gen_health_diagnosis']).'';
                                                            echo '<br/><span class="bold">Treatment:</span>'.ucfirst($v['gen_health_treatment']).'';
                                                            echo '<br/><span class="bold">Ref To:</span>'.$v['gen_health_referred_to'].'</span>';
                                                    
                                                            
                                                            echo '<br/><br/><span class="badge badge-warning">LARC Removal:</span>';
                                                            echo '<br/><span class="bold">Method:</span>'.$v['larc_method_name'].' ';
                                                            echo '<br/><span class="bold">Period:</span>'.$v['larc_period'].' ';
                                                            echo '<br/><span class="bold">Reason:</span>'.$v['larc_reason'].'</span>';
                                                    }
                                                    echo '</td>';
                                                    
                                                    echo '<td>';
                                                    echo '<span class="">'.$v['activity_under'].'</span>';
                                                    echo '<br/><span class="">UC: '.$v['activity_uc'].'</span>';
                                                    echo '<br/><span class="">Number:'.$v['activity_num'].'</span>';
                                                    echo '</td>';
                                                    
                                                    echo '<td>';
                                                     echo '<a class="btn btn-xs btn-success" href="view_visit.php?visit_id='.$v['pk_id'].'"><i class="fa fa-file"></i> View Details</a>';
                                                
                                                    if(!empty($v['wh_id']) && $v['wh_id']==$_SESSION['user_warehouse'])
                                                    {
                                                        if(strtotime($min_date) <= strtotime($v['date_of_visit'])){
                                                            echo '<a class="btn btn-xs btn-info" href="edit_visit.php?visit_id='.$v['pk_id'].'"><i class="fa fa-plus"></i> Edit Visit</a>';
                                                        }
                                                        echo '<a onclick="return confirm(\'Are you sure to Delete this Visit?\')" class="btn btn-xs btn-danger" href="del_visit_action.php?visit_id='.$v['pk_id'].'&client_id='.$v['client_id'].'"><i class="fa fa-times"></i> Del Visit</a>';

                                                    }

                                                    echo '</td>';
                                                    
                                                    echo '</tr>';
                                                }
                                                
                                                        
                                                ?>
                                            </tbody>
                                        </table>
                                        <?php
                                        echo '<a class="btn btn-xs btn-success" href="add_visit.php?client_id='.$client_id.'"><i class="fa fa-plus"></i> Add A New Visit of '.ucwords($client_name).'</a>';
                                        ?>


                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

</body>
</html>