<?php
include("../includes/classes/AllClasses.php");
//********
//Params:
//month : format = 2022-10-01 /// mandatory
//dist : /// optional
//wh_id : /// optional
//
//********

$ajax = 'no'; /// for sending ajax call , send param ajax=yes
$debug ='no';/// debug=yes for debug info
$param_month = $_REQUEST['month']; ////format = 2022-10-01

if(!empty($_REQUEST['wh_id']) && $_REQUEST['wh_id'] > 0)
    $wh_id = $_REQUEST['wh_id'];
if(!empty($_REQUEST['dist']) && $_REQUEST['dist'] > 0)
    $dist = $_REQUEST['dist'];
if(!empty($_REQUEST['ajax']) )
    $ajax = $_REQUEST['ajax'];

if(!empty($param_month) && $param_month > ''){
	
   @$debug=$_REQUEST['debug']; 
    /// the logic is in following file
    include("include_agg_function.php");

    if(!empty($ajax) && $ajax == 'yes'){
        echo 'Reload done.';
    }else{
        echo 'Completed. A total of '.$count_i.' inserts and  '.$count_u .' updates completed.';
        echo '<br/>You may close this window.';
    }
}
else{
   echo ' Invalid Params';    
}
exit;
?>