<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$from_date = date('Y-m-01');
$to_date = date('Y-m-d');
$indicator = '';
$stakeholder = '';

if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
if (!empty($_REQUEST['to_date']))
    $to_date = $_REQUEST['to_date'];
if (!empty($_REQUEST['facid']))
    $facility_id = $_REQUEST['facid'];
if (!empty($_REQUEST['stakeholder'])){
    $stakeholder = $_REQUEST['stakeholder'];
}
else{
    $stakeholder = 9;
}
//if(!empty($_REQUEST['indicator']))$indicator=$_REQUEST['indicator'];
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
<link rel="stylesheet" type="text/css" href="../../public/assets/global/plugins/select2/select2.css"/>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Facility Issuance Report - Method Wise Summary </h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">From <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $from_date ?>"   max="<?= date('Y-m-d') ?>" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">To <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $to_date ?>"  max="<?= date('Y-m-d') ?>" id="to_date" name="to_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">Stakeholder</label>
                                                    <div class="controls">
                                                        <select name="stakeholder" id="stakeholder" class="input-large  select2me" onchange="change_stk()" >

                                                            <?php
                                                            $qry = "SELECT
                                                                                        distinct stakeholder.stkname, 
                                                                                        stakeholder.stkid 
                                                                                FROM
                                                                                        stakeholder
                                                                                        INNER JOIN
                                                                                        tbl_warehouse
                                                                                        ON 
                                                                                                stakeholder.stkid = tbl_warehouse.stkid
                                                                                WHERE
                                                                                        tbl_warehouse.ecr_start_month is not null
                                                                                                                                                   ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            $stk_name = '';
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                $sel = '';

                                                                if($stakeholder == $row['stkid']){
                                                                    $sel =  'selected="selected"';
                                                                    $stk_name = $row['stkname'];
                                                                }
                                                                echo "<option value=\"" . $row['stkid'] . "\" $sel>" . $row['stkname'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">District</label>
                                                    <div class="controls" id="districtsCol">
                                                        <select name="district" id="district" class="form-control "  >

                                                            <?php
                                                            if ($_SESSION['user_level'] < '3') {
//                                                                echo '<option value="">All</option>';
                                                            }
                                                            if ($_SESSION['user_level'] == 1){
                                                                $prov_helper = " IN (2,4) ";
                                                            }
                                                            else{
                                                                $prov_helper = " = '". $_SESSION['user_province1']. "'";
                                                            }
                                                            $qry = "SELECT
                                                                            distinct PkLocID,
                                                                            LocName
                                                                    FROM
                                                                            tbl_locations

                                                                    INNER JOIN
                                                                    tbl_warehouse
                                                                    ON
                                                                            tbl_locations.PkLocID = tbl_warehouse.dist_id
                                                                    WHERE
                                                                            ParentID $prov_helper AND LocLvl = '3' AND
                                                                    tbl_warehouse.stkid = $stakeholder
                                                                    ORDER BY
                                                                        LocName
                                                                               ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                if ($_SESSION['user_level'] > '2' && !empty($_SESSION['user_district'])) {
                                                                    $district = $_SESSION['user_district'];
                                                                    if ($row['PkLocID'] != $_SESSION['user_district'])
                                                                        continue;
                                                                }
                                                                $sel = ($_REQUEST['district'] == $row['PkLocID']) ? 'selected="selected"' : '';
                                                                echo "<option value=\"" . $row['PkLocID'] . "\" $sel>" . $row['LocName'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>


                                            <!--                                            <div class="col-md-2">
                                                                                            <div class="control-group ">
                                                                                                <label class="control-label">Aggregate By</label>
                                                                                                <div class="controls" id="districtsCol">
                                                                                                    <select name="agg_by" id="agg_by" class="form-control "  >
                                            
                                            <?php
//                                                            echo '<option value="fac">Facilities</option>';
//                                                            echo '<option value="dist">Districts</option>';
                                            ?>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>-->
                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>

                                        <?php
//                                                echo '<pre>';
//                                                print_r($_REQUEST);
//                                                echo '</pre>';
//                                                exit;

                                        @$district = $_REQUEST['district'];
                                        @$from_date = $_REQUEST['from_date'];
                                        @$to_date = $_REQUEST['to_date'];

                                        $from_date = date('Y-m-d', strtotime($from_date));
                                        $to_date = date('Y-m-d', strtotime($to_date));

                                        $fac = $items = array();


                                        if (!empty($district) && $district != '') {

                                            $qry4 = "
                                            (
                                                    SELECT   
                                                            tbl_warehouse.dist_id, 
                                                            tbl_locations.LocName as dist_name,
                                                            ecr_client_visits.wh_id, 
                                                            ecr_client_visits.wh_name,
                                                            ecr_client_visits.date_of_visit,
                                                            ecr_client_visits.fp_method, 
                                                            SUM(ecr_client_visits.fp_qty) as issuance
                                                    FROM
                                                            ecr_client_visits
                                                            INNER JOIN
                                                            tbl_warehouse
                                                            ON 
                                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                                            INNER JOIN
                                                            tbl_locations
                                                            ON 
                                                                    tbl_warehouse.dist_id = tbl_locations.PkLocID
                                                            where fp_method > 0
                                                            and date_of_visit between '" . $from_date . "' and '" . $to_date . "'
                                                               and tbl_warehouse.dist_id = '" . $district . "' AND
                                                                    tbl_warehouse.stkid = " . $stakeholder . "
                                                            group by 

                                                                ecr_client_visits.wh_id,
                                                                ecr_client_visits.date_of_visit, 
                                                                ecr_client_visits.fp_method
                                                            order by 
                                                                tbl_warehouse.dist_id,
                                                                ecr_client_visits.wh_id,
                                                                ecr_client_visits.date_of_visit, 
                                                                ecr_client_visits.fp_method
                                                    )
                                                    UNION ALL
                                                    (
                                                    SELECT  
                                                    tbl_warehouse.dist_id, 
                                                    tbl_locations.LocName as dist_name,
                                                            ecr_client_visits.wh_id, 
                                                            ecr_client_visits.wh_name,
                                                            ecr_client_visits.date_of_visit,
                                                            ecr_client_visits.additional_item, 
                                                            SUM(ecr_client_visits.additional_item_qty) as issuance
                                                    FROM
                                                            ecr_client_visits
                                                            
                                                            INNER JOIN
                                                            tbl_warehouse
                                                            ON 
                                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                                            INNER JOIN
                                                            tbl_locations
                                                            ON 
                                                                    tbl_warehouse.dist_id = tbl_locations.PkLocID
                                                            where additional_item >0
                                                            and date_of_visit between '" . $from_date . "' and '" . $to_date . "'
                                                               and tbl_warehouse.dist_id = '" . $district . "' AND
                                                                    tbl_warehouse.stkid = " . $stakeholder . "
                                                            group by 

                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.additional_item
                                                            order by 
                                                            tbl_warehouse.dist_id,
                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.additional_item
                                                    )
                                        ";


//                                            echo $qry;
                                            $res = mysql_query($qry4);
                                            $data_arr = array();
                                            while ($row = mysql_fetch_assoc($res)) {
//                                            if(empty($district)){
//                                                $row['wh_id']=1;
//                                            }

                                                @$data_arr[$row['wh_id']][$row['fp_method']] += $row['issuance'];
                                                $fac[$row['wh_id']]['wh_name'] = $row['wh_name'];
                                                $fac[$row['wh_id']]['dist_id'] = $row['dist_id'];
                                                $fac[$row['wh_id']]['dist_name'] = $row['dist_name'];
                                                $items[$row['fp_method']] = $items_fp[$row['fp_method']];
                                            }
                                        }
//                                        echo '<pre>';
//                                        print_r($fac);
//                                        echo '</pre>';   
//                                        exit;

                                        $c = 1;

                                        if (!empty($data_arr)) {
                                            echo '<table id="table_1" border="1" class="table table-bordered table-condensed">';
                                            echo '<tr>';
                                            echo '<td colspan="'.(3 + count($items_fp)).'" style="text-align:center;" >Facility Issuance Report - Method Wise Summary From '. $from_date .' to '. $to_date .'</td>';
                                            echo '</tr>';
                                            echo '<tr>';
                                            echo '<td>#</td>';
                                            echo '<td> District</td>';
                                            if (!empty($district)) {
                                                echo '<td> Facility Name  </td>';
                                            }
                                            foreach ($items_fp as $itm_id => $itm_name) {
                                                if ($itm_id == '31' || $itm_id == '32') {
                                                    ///// 31/32 included back in upon email . ref : LMIS-2530
                                                    //continue;
                                                }
                                                echo '<td>' . $itm_name . '</td>';
                                            }
                                            echo '</tr>';
                                            foreach ($fac as $fac_id => $fac_name) {
                                                echo '<tr>';
                                                echo '<td>' . $c++ . '</td>';

                                                echo '<td>';
                                                if (empty($district)) {
//                                                 echo 'All ';
                                                    echo $fac_name['dist_name'] . '  ';
                                                } else {
                                                    echo $fac_name['dist_name'] . '  ';
                                                }
                                                if (!empty($district)) {
                                                    // echo '<a href="summarized_issuance_report.php?from_date='.$from_date.'&to_date='.$to_date.'&district='.$fac_name['dist_id'].'"> <i class="fa fa-search font-blue"> View Details</i> </a> ';
                                                }
                                                echo '</td>';

                                                if (!empty($district)) {
                                                    echo '<td wh_id="' . $fac_id . '">' . $fac_name['wh_name'];
                                                    echo '<a href="daily_issuance_report.php?from_date=' . $from_date . '&to_date=' . $to_date . '&facid=' . $fac_id . '"> <i class="fa fa-search font-blue"></i> View Details</a> ';
                                                    echo '</td>';
                                                }
                                                foreach ($items_fp as $itm_id => $itm_name) {
                                                    if ($itm_id == '31' || $itm_id == '32') {
                                                        ///// 31/32 included back in upon email . ref : LMIS-2530
//                                                    continue;
                                                    }
                                                    if (!empty($data_arr[$fac_id][$itm_id])) {
                                                        echo '<td>';
                                                        echo '<a href="daily_issuance_report.php?from_date=' . $from_date . '&to_date=' . $to_date . '&facid=' . $fac_id . '&item_id=' . $itm_id . '">';
                                                        echo '' . @$data_arr[$fac_id][$itm_id] . '';
                                                        echo '</a> ';

                                                        echo '</td>';
                                                    } else {
                                                        echo '<td class="bg-danger"></td>';
                                                    }
                                                }
                                                echo '</tr>';
                                            }
                                            echo '</table>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <span class="note note-info"> NOTE : Contraceptive Surgery Cases have been included in this report, upon request via mail sent on 24th Feb 2023.</span>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
<?php
include PUBLIC_PATH . "/html/footer.php";
?>

    <script>

        function change_stk(){
            const stk = $('#stakeholder').val();
            $.ajax({
                url: "ajax_stk_dist.php",
                type: 'post',
                data: {
                    stk: stk
                },
                success: function(html){
                    $("#districtsCol").html(html);
                }
            });
        }
    </script>

    <script type="text/javascript" src="../../public/assets/global/plugins/select2/select2.min.js"></script>
</body>
</html>