<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$colors_new = array();
$colors_new[] = "#8251b8";
$colors_new[] = "#4c8ce6";
$colors_new[] = "#3fccc0";
$colors_new[] = "rgba(139,195,74,1)";
$colors_new[] = "rgba(33,150,243,1)";
$colors_new[] = "rgba(247, 184, 35,1)";
$colors_new[] = "rgba(250, 85, 192,1)";
$colors_new[] = "rgba(245, 146, 93,1)";
$colors_new[] = "rgba(56, 37, 184,1)";
$colors_new[] = "rgba(222, 108, 27,1)";
$colors_new[] = "#7CFC00";
$colors_new[] = "#FFFF00";
$colors_new[] = "#9932CC";


$txt_display = array();
$txt_display['visit_purpose'] = 'Purpose of visit';
$txt_display['outcome_last_preg'] = 'Outcome of Last Pregnancy';
$txt_display['period_from_last_preg'] = 'Total period from last pregnancy/procedure';
$txt_display['fp_category'] = 'FP Services - Category of Client';
//$txt_display['fp_method'] = 'FP Services - Method';
$txt_display['fp_referred_to'] = 'FP Services - Referred to';
$txt_display['fp_referred_for'] = 'FP Services - Referred For';
$txt_display['larc_method_name'] = 'LARC - Method Name';
$txt_display['larc_period'] = 'LARC -Period after which LARC is removed';
$txt_display['larc_reason'] = 'LARC -Reason of LARC Removal';
$txt_display['gen_health_category'] = 'GHS - Category of Patient';
$txt_display['activity_under'] = 'Activity Done Under';


$list_id = array();
$list_id['visit_purpose'] = 'Purpose of visit';
$list_id['outcome_last_preg'] = 'Outcome of Last Pregnancy';
$list_id['period_from_last_preg'] = 'Total period from last pregnancy/procedure';
$list_id['fp_category'] = 'FP Services - Category of Client';
//$list_id['fp_method'] = 'FP Services - Method';
$list_id['fp_referred_to'] = 'FP Services - Referred to';
$list_id['fp_referred_for'] = 'FP Services - Referred For';
$list_id['larc_method_name'] = 'LARC - Method Name';
$list_id['larc_period'] = 'LARC -Period after which LARC is removed';
$list_id['larc_reason'] = 'LARC -Reason of LARC Removal';
$list_id['gen_health_category'] = 'GHS - Category of Patient';
$list_id['activity_under'] = 'Activity Done Under';

$from_date=date('Y-m-01');
$to_date = date('Y-m-d');
$indicator = '';
$stakeholder = '';

if(!empty($_REQUEST['from_date']))$from_date=$_REQUEST['from_date'];
if(!empty($_REQUEST['to_date']))$to_date=$_REQUEST['to_date'];
if(!empty($_REQUEST['indicator']))$indicator=$_REQUEST['indicator'];
if(!empty($_REQUEST['district']))$district=$_REQUEST['district'];
if (!empty($_REQUEST['stakeholder'])){
    $stakeholder = $_REQUEST['stakeholder'];
}



/// visit_purpose category
//$qry = "SELECT 
//            ecr_client_visits.visit_purpose, COUNT(*) AS total
//        FROM ecr_client_visits 
//        INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
//        inner join tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
//        WHERE ecr_client_visits.visit_purpose <> ''
//        AND ecr_client_visits.visit_purpose <> 'undefined'    GROUP BY ecr_client_visits.visit_purpose";
////    echo $client_referrals_query;
//$visit_purpose_results = mysql_query($qry);
//$data_labels = $data_counts = array();
//if (mysql_num_rows($visit_purpose_results) > 0) {
//    while ($row = mysql_fetch_assoc($visit_purpose_results)) {
//        $data_counts[] = $row['total'];
//        $data_labels[] = ucfirst(str_replace('_', ' ', $row['visit_purpose']));
//    }
//}
//echo '<pre>';
//print_r($data_counts);
//echo '</pre>';
//exit;

?>
<!--<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>-->
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.0/dist/chart.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0/dist/chartjs-plugin-datalabels.min.js"></script> 
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
<link rel="stylesheet" type="text/css" href="../../public/assets/global/plugins/select2/select2.css"/>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Indicator Report</h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">From <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?=$from_date ?>"   max="<?= date('Y-m-d') ?>" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">To <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $to_date ?>"  max="<?= date('Y-m-d') ?>" id="to_date" name="to_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3" id="" >
                                                <div class="control-group">
                                                    <label class="control-label" for="indicator">Indicator <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <select id="indicator" name="indicator" class="form-control">

                                                            <option value=""> SELECT </option>
                                                            <?php
                                                            foreach($txt_display as $val => $disp){
                                                                $sel='';
                                                                if($indicator == $val) $sel = 'selected';
                                                                echo '<option value="'.$val.'" '.$sel.'>'.$disp.'</option>';
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">Stakeholder</label>
                                                    <div class="controls">
                                                        <select name="stakeholder" id="stakeholder" class="input-large  select2me" onchange="change_stk()" >

                                                            <?php
                                                            $qry = "SELECT
                                                                                        distinct stakeholder.stkname, 
                                                                                        stakeholder.stkid 
                                                                                FROM
                                                                                        stakeholder
                                                                                        INNER JOIN
                                                                                        tbl_warehouse
                                                                                        ON 
                                                                                                stakeholder.stkid = tbl_warehouse.stkid
                                                                                WHERE
                                                                                        tbl_warehouse.ecr_start_month is not null
                                                                                                                                                   ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            $stk_name = '';
                                                            echo "<option value=\"\" selected> All </option>";
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                $sel = '';

                                                                if($stakeholder == $row['stkid']){
                                                                    $sel =  'selected="selected"';
                                                                    $stk_name = $row['stkname'];
                                                                }
                                                                echo "<option value=\"" . $row['stkid'] . "\" $sel>" . $row['stkname'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <?php
                                            if($_SESSION['user_level'] < '7'){
                                        
                                            ?>
                                            <div class="col-md-2">
                                                <div class="control-group ">
                                                    <label class="control-label">District</label>
                                                    <div class="controls" id="districtsCol">
                                                        <select name="district" id="district" class="form-control "  >

                                                            <?php 
                                                            if($_SESSION['user_level'] < '3'){
                                                                echo '<option value="">All</option>';
                                                                }
                                                            $qry = "SELECT
                                                                                       PkLocID,
                                                                                       LocName
                                                                               FROM
                                                                                       tbl_locations
                                                                               WHERE
                                                                                      ParentID = " . $_SESSION['user_province1'] . " AND LocLvl = '3'
                                                                               ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            $title_display='';
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                if($_SESSION['user_level'] > '2' && !empty($_SESSION['user_district'])){
                                                                    $district=$_SESSION['user_district'];
                                                                    if($row['PkLocID'] != $_SESSION['user_district']) continue;
                                                                }
                                                                $sel = ($_REQUEST['district'] == $row['PkLocID']) ? 'selected="selected"' : '';
                                                                
                                                                echo "<option value=\"" . $row['PkLocID'] . "\" $sel>" . $row['LocName'] . "</option>";
                                                                
                                                                if($_REQUEST['district'] == $row['PkLocID']){
                                                                    $title_display = $row['LocName'];
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            }
                                            ?>
                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>
                                <hr/>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        
                                        $title = 'Visits Breakdown ';
                                        
//                                                echo '<pre>';
//                                                print_r($_REQUEST);
//                                                echo '</pre>';
//                                                exit;

                                        $col_name   = $_REQUEST['indicator'];
                                        $from_date  = $_REQUEST['from_date'];
                                        $to_date    = $_REQUEST['to_date'];
                                        
                                        $from_date = date('Y-m-d',strtotime($from_date));
                                        $to_date = date('Y-m-d',strtotime($to_date));
                                        
                                        $qry = "
                                            SELECT
                                                    count(*) as no_of_visits, 
                                                    ".$col_name." as ind_name
                                            FROM
                                                    ecr_client_visits
                                                    INNER JOIN tbl_warehouse on ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                                    where date_of_visit between '".$from_date."' and '".$to_date."'
                                                    and ".$col_name." is not null and ".$col_name." <> ''
                                                        ";
                                        
                                        if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7'){
                                            $qry .= " and ecr_client_visits.wh_id = '".$_SESSION['user_warehouse']."' ";
                                            $title .= ' of Your Facility';
                                        }
                                        if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '3'){
                                            $qry .= " and tbl_warehouse.dist_id = '".$_SESSION['user_district']."' ";
                                            $title .= ' of Your District';
                                        }
                                        if(!empty($district)){
                                            $qry .= " and tbl_warehouse.dist_id = '".$district."' ";
                                        }
                                        if(!empty($stakeholder)){
                                            $qry .= " and tbl_warehouse.stkid = '".$stakeholder."' ";
                                        }
                                        $qry .=" group by ".$col_name."

                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        $data_arr_arranged_helper = array();
                                        while($row= mysql_fetch_assoc($res)){
                                            $data_arr[] = $row;
                                            $data_arr_arranged_helper[$row['ind_name']] = $row['no_of_visits'];
                                            
                                                $data_counts[] = $row['no_of_visits'];
                                                $data_labels[] = ucfirst(str_replace('_', ' ', $row['ind_name']));
                                        }
//                                        echo '<pre>';
//                                        print_r($data_arr);
//                                        print_r($data_counts);
//                                        print_r($data_labels);
//                                        echo '</pre>';

                                        //Arranging Indicators for FP Services - Referred For
                                        if ($col_name == 'fp_referred_for'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Tubal Ligation', 'no_of_visits' => @$data_arr_arranged_helper['Tubal Ligation']);
                                            $data_arr[] = array('ind_name' => 'Nonscalpel vasectomy', 'no_of_visits' => @$data_arr_arranged_helper['Nonscalpel vasectomy']);
                                            $data_arr[] = array('ind_name' => 'Insertion of implant', 'no_of_visits' => @$data_arr_arranged_helper['Insertion of implant']);
                                            $data_arr[] = array('ind_name' => 'Insertion of IUCD', 'no_of_visits' => @$data_arr_arranged_helper['Insertion of IUCD']);
                                            $data_arr[] = array('ind_name' => 'Removal of implant', 'no_of_visits' => @$data_arr_arranged_helper['Removal of implant']);
                                            $data_arr[] = array('ind_name' => 'Removal of IUCD', 'no_of_visits' => @$data_arr_arranged_helper['Removal of IUCD']);
                                        }
                                        //End

                                        //Arranging Total period from last pregnancy/procedure
                                        if ($col_name == 'period_from_last_preg'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Within 48 hours', 'no_of_visits' => @$data_arr_arranged_helper['Within 48 hours']);
                                            $data_arr[] = array('ind_name' => 'More than 48 hours to 6 weeks', 'no_of_visits' => @$data_arr_arranged_helper['More than 48 hours to 6 weeks']);
                                            $data_arr[] = array('ind_name' => 'More than 6 weeks to 6 months', 'no_of_visits' => @$data_arr_arranged_helper['More than 6 weeks to 6 months']);
                                            $data_arr[] = array('ind_name' => 'More than 6 month to 1 year', 'no_of_visits' => @$data_arr_arranged_helper['More than 6 month to 1 year']);
                                            $data_arr[] = array('ind_name' => 'More than 1 to 2 year', 'no_of_visits' => @$data_arr_arranged_helper['More than 1 to 2 year']);
                                            $data_arr[] = array('ind_name' => 'More than 2 years', 'no_of_visits' => @$data_arr_arranged_helper['More than 2 years']);
                                        }
                                        //End

                                        //Arranging Outcome of Last Pregnancy
                                        if ($col_name == 'outcome_last_preg'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'NVD (Normal Vaginal Delivery)', 'no_of_visits' => @$data_arr_arranged_helper['NVD (Normal Vaginal Delivery)']);
                                            $data_arr[] = array('ind_name' => 'LSCS (Lower Segment Cesarean Section)', 'no_of_visits' => @$data_arr_arranged_helper['LSCS (Lower Segment Cesarean Section)']);
                                            $data_arr[] = array('ind_name' => 'Abortion', 'no_of_visits' => @$data_arr_arranged_helper['Abortion']);
                                        }
                                        //End

                                        //Arranging Purpose of Visit
                                        if ($col_name == 'visit_purpose'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'fp', 'no_of_visits' => @$data_arr_arranged_helper['fp']);
                                            $data_arr[] = array('ind_name' => 'larc_removal', 'no_of_visits' => @$data_arr_arranged_helper['larc_removal']);
                                            $data_arr[] = array('ind_name' => 'ghs', 'no_of_visits' => @$data_arr_arranged_helper['ghs']);
                                        }
                                        //End

                                        //Arranging FP Services - Category of Client
                                        if ($col_name == 'fp_category'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Family Planning Method', 'no_of_visits' => @$data_arr_arranged_helper['Family Planning Method']);
                                            $data_arr[] = array('ind_name' => 'Counselling', 'no_of_visits' => @$data_arr_arranged_helper['Counselling']);
                                            $data_arr[] = array('ind_name' => 'Follow up', 'no_of_visits' => @$data_arr_arranged_helper['Follow up']);
                                        }
                                        //End

                                        //Arranging FP Services - Referred to
                                        if ($col_name == 'fp_referred_to'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Family Welfare Center', 'no_of_visits' => @$data_arr_arranged_helper['Family Welfare Center']);
                                            $data_arr[] = array('ind_name' => 'Mobile Service Unit', 'no_of_visits' => @$data_arr_arranged_helper['Mobile Service Unit']);
                                            $data_arr[] = array('ind_name' => 'Reproductive Health Centre', 'no_of_visits' => @$data_arr_arranged_helper['Reproductive Health Centre']);
                                            $data_arr[] = array('ind_name' => 'Family Health Day', 'no_of_visits' => @$data_arr_arranged_helper['Family Health Day']);
                                            $data_arr[] = array('ind_name' => 'Family Health Mela', 'no_of_visits' => @$data_arr_arranged_helper['Family Health Mela']);
                                            $data_arr[] = array('ind_name' => 'Others', 'no_of_visits' => @$data_arr_arranged_helper['Others']);
//                                            $data_arr[] = array('ind_name' => 'null', 'no_of_visits' => @$data_arr_arranged_helper['null']);
//                                            $data_arr[] = array('ind_name' => 'N/A', 'no_of_visits' => @$data_arr_arranged_helper['N/A']);
                                        }
                                        //End

                                        //Arranging LARC -Period after which LARC is removed
                                        if ($col_name == 'larc_period'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Less than 3 months', 'no_of_visits' => @$data_arr_arranged_helper['Less than 3 months']);
                                            $data_arr[] = array('ind_name' => 'More than 3 months to 6 months', 'no_of_visits' => @$data_arr_arranged_helper['More than 3 months to 6 months']);
                                            $data_arr[] = array('ind_name' => 'More than 6 months to 1 year', 'no_of_visits' => @$data_arr_arranged_helper['More than 6 months to 1 year']);
                                            $data_arr[] = array('ind_name' => 'Less than 2 years', 'no_of_visits' => @$data_arr_arranged_helper['Less than 2 years']);
                                            $data_arr[] = array('ind_name' => 'Less than 3 years', 'no_of_visits' => @$data_arr_arranged_helper['Less than 3 years']);
                                            $data_arr[] = array('ind_name' => 'More than 3 year', 'no_of_visits' => @$data_arr_arranged_helper['More than 3 year']);
                                        }
                                        //End

                                        //Arranging LARC -Reason of LARC Removal
                                        if ($col_name == 'larc_reason'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Wanted to get pregnant', 'no_of_visits' => @$data_arr_arranged_helper['Wanted to get pregnant']);
                                            $data_arr[] = array('ind_name' => 'Husband disapproval', 'no_of_visits' => @$data_arr_arranged_helper['Husband disapproval']);
                                            $data_arr[] = array('ind_name' => 'Side effects', 'no_of_visits' => @$data_arr_arranged_helper['Side effects']);
                                            $data_arr[] = array('ind_name' => 'Complication', 'no_of_visits' => @$data_arr_arranged_helper['Complication']);
                                            $data_arr[] = array('ind_name' => 'Completion of Period', 'no_of_visits' => @$data_arr_arranged_helper['Completion of Period']);
                                            $data_arr[] = array('ind_name' => 'Opting for Another method', 'no_of_visits' => @$data_arr_arranged_helper['Opting for Another method']);
                                        }
                                        //End

                                        //Arranging GHS - Category of Patient
                                        if ($col_name == 'gen_health_category'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Antenatal', 'no_of_visits' => @$data_arr_arranged_helper['Antenatal']);
                                            $data_arr[] = array('ind_name' => 'Postnatal', 'no_of_visits' => @$data_arr_arranged_helper['Postnatal']);
                                            $data_arr[] = array('ind_name' => 'Reproductive Health Issuess', 'no_of_visits' => @$data_arr_arranged_helper['Reproductive Health Issuess']);
                                            $data_arr[] = array('ind_name' => 'Child Health', 'no_of_visits' => @$data_arr_arranged_helper['Child Health']);
                                            $data_arr[] = array('ind_name' => 'Nutrition', 'no_of_visits' => @$data_arr_arranged_helper['Nutrition']);
                                            $data_arr[] = array('ind_name' => 'General Ailment', 'no_of_visits' => @$data_arr_arranged_helper['General Ailment']);
                                            $data_arr[] = array('ind_name' => 'Other', 'no_of_visits' => @$data_arr_arranged_helper['Other']);
                                        }
                                        //End

                                        //Arranging Activity Done Under
                                        if ($col_name == 'activity_under'){
                                            $data_arr= array();
                                            $data_arr[] = array('ind_name' => 'Routine / Service Delivery Point', 'no_of_visits' => @$data_arr_arranged_helper['Routine / Service Delivery Point']);
                                            $data_arr[] = array('ind_name' => 'Camp (Family Health Day)', 'no_of_visits' => @$data_arr_arranged_helper['Camp (Family Health Day)']);
                                            $data_arr[] = array('ind_name' => 'Family Health Mela', 'no_of_visits' => @$data_arr_arranged_helper['Family Health Mela']);
                                            $data_arr[] = array('ind_name' => 'Extension Service Camp', 'no_of_visits' => @$data_arr_arranged_helper['Extension Service Camp']);
                                            $data_arr[] = array('ind_name' => 'Other', 'no_of_visits' => @$data_arr_arranged_helper['Other']);
                                        }
                                        //End

                                            $msg = "";
                                        if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7'){
                                            $msg = " (At this Facility) ";
                                        }
                                        
                                        $c=1;
                                        
                                        
                                        echo '<img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>';
                                        echo '<img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>';
                                        echo '<h3 align="center">'.$title.'</h3>';
                                        echo '<table id="table_1" border="1" style="width:90%;" class="table table-bordered table-hover table-condensed">';
                                        echo '<tr class="bg-info">';
                                        echo '<td>#</td>';
                                        echo '<td> Indicator ('.$txt_display[$col_name].') </td>';
                                        echo '<td>No of visits'.$msg.'</td>';
                                        echo '</tr>';
                                        foreach($data_arr as $k => $row){
                                            /*echo '<pre>';print_r($data_arr);exit();*/
                                            echo '<tr>';
                                            echo '<td>'.$c++.'</td>';
                                            echo '<td>'.strtoupper($row['ind_name']).'</td>';
                                            echo '<td align="right">'.number_format($row['no_of_visits']).'</td>';
                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        
                                        <div class="col-md-9" style="margin-left:0px;margin-right: 0px;" id="graph_row_8">
                                                <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                    <div class="portlet-title">
                                                        <div class="caption"><i class="fa fa-cogs"></i>Visits Breakdown - <?=$txt_display[$col_name]?> 
                                                        </div>
                                                        <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                <div id="canvas-holder" style="width:500px;height: 500px;">
                                                    <canvas id="ch_purpose"></canvas>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

    <script type="text/javascript" src="../../public/assets/global/plugins/select2/select2.min.js"></script>

    <script>

        function change_stk(){
            const stk = $('#stakeholder').val();
            $.ajax({
                url: "ajax_stk_dist.php",
                type: 'post',
                data: {
                    stk: stk
                },
                success: function(html){
                    $("#districtsCol").html(html);
                }
            });
        }
    </script>

    <script> 
    
       //start of visit purpose chart
        var ctx = document.getElementById('ch_purpose').getContext('2d');
        var data = {
            labels: [<?= '"'.implode('","', $data_labels).'"';?>],
            datasets: [{
                    label: 'Purpose',
                    backgroundColor: [
                    <?php for($loop = 0; isset($data_labels[$loop]); $loop++){
                        if(!empty($colors_new[$loop])){ ?>
                        "<?= $colors_new[$loop];?>",
                    <?php } } ?>
                    ],
                    // borderColor: 'rgb(250, 105, 185)',
                    data: [<?= implode(',', $data_counts);?>]
                }]
        };
         
        var chart = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            plugins: [ChartDataLabels],
            options: { 
                    legend: {
                        display: true,
                        position: "right"
                    },
                   
                tooltips: {
                    enabled: true,
                    callbacks: {
                        label: function(tooltipItem, data) {
                            //get the concerned dataset
                            var dataset = data.datasets[tooltipItem.datasetIndex];
                            //calculate the total of this data set
                            var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
                                return previousValue + currentValue;
                            });
                            //get the current items value
                            var currentValue = dataset.data[tooltipItem.index];
                            //calculate the precentage based on the total and current item, also this does a rough rounding to give a whole number
                            var percentage = Math.floor(((currentValue/total) * 100)+0.5);

                            return data.labels[tooltipItem.index]+ " : " +currentValue+" ( "+percentage + "% )";
                        }
                    }
                },plugins:{
                                        
                    datalabels: {
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => {
                                sum += data;
                            });
                            let percentage = (value*100 / sum).toFixed(2)+"%";
                            return percentage;
                        },
                        color: '#fff',
                        font: {
                            size: 14,
                        }
                    }
                }
            }
        }); 
    </script>

</body>
</html>