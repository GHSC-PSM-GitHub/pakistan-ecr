<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$from_date = date('Y-m-01');
$to_date = date('Y-m-d');
$indicator = '';

if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
if (!empty($_REQUEST['to_date']))
    $to_date = $_REQUEST['to_date'];
if (!empty($_REQUEST['facid']))
    $facid = $_REQUEST['facid'];
if (!empty($_REQUEST['item_id']))
    $item_id = $_REQUEST['item_id'];

if(empty($facid) && $_SESSION['user_level'] =='7'){
       $facid = $_SESSION['user_warehouse'];
}
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    @media print{

        table {
            border:1px solid #999;
        }
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"><?php echo (!empty($facid))?'Drill Down - Summarized Issuance Report':'Daily Issuance Report'; ?></h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                     <?php 
                                     if(empty($facid) && $_SESSION['user_level'] < '7'){
                                         echo 'Access Not Allowed. This is a Facility Level Report.';
                                     } 
                                    if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7'){
                                     ?>
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">From <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $from_date ?>"   max="<?= date('Y-m-d') ?>" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">To <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $to_date ?>"  max="<?= date('Y-m-d') ?>" id="to_date" name="to_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3 " >
                                                <div class="control-group">
                                                    <label class="control-label" for="fp_method"> Item </label>
                                                    <div class="controls">
                                                        <select id="item_id" name="item_id"  class="form-control">
                                                            <option value=""> ALL </option>
                                                            <?php
                                                            $prod_name = '';
                                                            foreach ($items_fp as $k => $v) {
                                                                if(!empty($item_id) && $item_id == $k){
                                                                    $sel = 'selected ';
                                                                    $prod_name = $v;
                                                                }
                                                                else {
                                                                    $sel = '';
                                                                }
                                                                echo '<option '.$sel.' value="' . $k . '" max_val="' . (!empty($items_fp_max[$k]) ? $items_fp_max[$k] : '1') . '">' . $v . '</option>';
                                                            }
                                                            ?>
                                                        </select>

                                                        <input type="hidden" name="fp_method_name" id="fp_method_name">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="hidden" value="<?php echo $facid; ?>" name="facid">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                     }
                                     ?>

                                </form>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <h4>Showing issuance details from <?php echo date('Y-M-d',strtotime($from_date));?> to <?php echo date('Y-M-d',strtotime($to_date));?> <?php echo (!empty($prod_name)?', For :'.$prod_name:'');?>  </h4>
                                        <img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <?php
//                                                echo '<pre>';
//                                                print_r($_REQUEST);
//                                                echo '</pre>';
//                                                exit;

                                        $from_date = $_REQUEST['from_date'];
                                        $to_date = $_REQUEST['to_date'];

                                        $from_date = date('Y-m-d', strtotime($from_date));
                                        $to_date = date('Y-m-d', strtotime($to_date));

                                        $qry = "
                                           Select a.wh_id, wh_name,date_of_visit,fp_method, 
	SUM(a.issuance) as issuance
	from
( (
                                                    SELECT  
                                                            ecr_client_visits.wh_id, 
                                                            ecr_client_visits.wh_name,
                                                            ecr_client_visits.date_of_visit,
                                                            ecr_client_visits.fp_method, 
                                                            SUM(ecr_client_visits.fp_qty) as issuance
                                                    FROM
                                                            ecr_client_visits
                                                            where fp_method > 0
                                                            and date_of_visit between '" . $from_date . "' and '" . $to_date . "' ";
                                       
                                        if(!empty($facid) ){
                                             $qry .=" and ecr_client_visits.wh_id='".$facid."' ";
                                        }
                                        if(!empty($item_id) ){
                                             $qry .=" and ecr_client_visits.fp_method='".$item_id."' ";
                                        }
                                        $qry .="
                                                            group by 

                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.fp_method
                                                            order by 
                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.fp_method
                                                    )
                                                    UNION ALL
                                                    (
                                                    SELECT  
                                                            ecr_client_visits.wh_id, 
                                                            ecr_client_visits.wh_name,
                                                            ecr_client_visits.date_of_visit,
                                                            ecr_client_visits.additional_item, 
                                                            SUM(ecr_client_visits.additional_item_qty) as issuance
                                                    FROM
                                                            ecr_client_visits
                                                            where additional_item >0
                                                            and date_of_visit between '" . $from_date . "' and '" . $to_date . "' ";
                                        
                                        if(!empty($facid) ){
                                             $qry .=" and ecr_client_visits.wh_id='".$facid."' ";
                                        }
                                        
                                        if(!empty($item_id) ){
                                             $qry .=" and ecr_client_visits.additional_item='".$item_id."' ";
                                        }
                                        $qry .="
                                                            group by 

                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.additional_item
                                                            order by 
                                                            ecr_client_visits.wh_id,
                                                            ecr_client_visits.date_of_visit, 
                                                            ecr_client_visits.additional_item
                                                    )
) as a
group by 	
	a.wh_id,
	a.date_of_visit, 
	a.fp_method


                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
//                                        echo '<pre>';
//                                        print_r($items_fp);
//                                        echo '</pre>';    

                                        $c = 1;

                                        echo '<table id="table_1" border="1" class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td>#</td>';
                                        echo '<td> Facility ID</td>';
                                        echo '<td> Facility Name  </td>';
                                        echo '<td> Date of Visit</td>';
                                        echo '<td> Item / Method </td>';
                                        echo '<td> Qty </td>';
                                        echo '</tr>';
                                        foreach ($data_arr as $k => $row) {
                                            if($row['fp_method'] == '31' || $row['fp_method'] == '32') {
                                                ///// 31/32 included back in upon email . ref : LMIS-2530
                                                //continue;
                                            }
                                            
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $row['wh_id'] . '</td>';
                                            echo '<td>' . $row['wh_name'] . '</td>';
                                            echo '<td>';
                                                echo '<a href="facility_visits_list.php?from_date='.$row['date_of_visit'].'&fac_id='.$row['wh_id'].'">';
                                                    echo ''. date('d-M-Y',strtotime($row['date_of_visit'])) .'';
                                                echo '</a>';
                                            echo '</td>';
                                            echo '<td>';
                                                echo '<a href="facility_visits_list.php?from_date='.$row['date_of_visit'].'&fac_id='.$row['wh_id'].'&item_id='.$row['fp_method'].'">';
                                                    echo ''. $items_fp[$row['fp_method']].'';
                                                echo '</a>';
                                            echo '</td>';
                                            echo '<td>' . $row['issuance'] . '</td>';
                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <span class="note note-info"> NOTE : Contraceptive Surgery Cases have been included in this report, upon request via mail sent on 24th Feb 2023.</span>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

    <script>
        $(document).ready(function() {
    
    
        });
    </script>

</body>
</html>