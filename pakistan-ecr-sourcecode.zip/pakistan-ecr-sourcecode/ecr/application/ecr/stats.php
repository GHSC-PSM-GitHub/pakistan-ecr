<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$colors_new = array();
$colors_new[] = "#8251b8";
$colors_new[] = "#4c8ce6";
$colors_new[] = "#3fccc0";
$colors_new[] = "rgba(139,195,74,1)";
$colors_new[] = "rgba(33,150,243,1)";
$colors_new[] = "rgba(247, 184, 35,1)";
$colors_new[] = "rgba(250, 85, 192,1)";
$colors_new[] = "rgba(245, 146, 93,1)";
$colors_new[] = "rgba(56, 37, 184,1)";
$colors_new[] = "rgba(222, 108, 27,1)";
$colors_new[] = "#7CFC00";
$colors_new[] = "#FFFF00";
$colors_new[] = "#9932CC";


$from_date = date('Y-m-01');
$to_date = date('Y-m-d');
if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
if (!empty($_REQUEST['to_date']))
    $to_date = $_REQUEST['to_date'];

$whr = " AND date_of_visit > '" . $from_date . "' AND  date_of_visit < '" . $to_date . "' ";

$data_counts = array();
$qry = "
SELECT
	count(ecr_client_visits.pk_id) AS cnt, 
	ecr_client_visits.wh_id, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.date_of_visit
FROM
	ecr_client_visits
WHERE
	ecr_client_visits.from_api is null ".$whr."
GROUP BY
	ecr_client_visits.wh_id, 
	ecr_client_visits.date_of_visit

order by ecr_client_visits.date_of_visit
	";
//    echo $client_referrals_query;
$visit_purpose_results = mysql_query($qry);
while($row = mysql_fetch_assoc($visit_purpose_results))
{
//    echo '<pre>';
//    print_r($row);
//    echo '</pre>';
//    exit;
    @$data_counts['web'][$row['date_of_visit']][$row['wh_id']]   = $row['cnt'];
    @$data_counts_date['web'][$row['date_of_visit']]             += $row['cnt'];
    @$data_counts_wh['web'][$row['wh_id']]                       += $row['cnt'];
    $wh_names[$row['wh_id']]                                    = $row['wh_name'];
    $dates[$row['date_of_visit']]                               = $row['date_of_visit'];
}

//echo '<pre>';
//print_r($data_counts_date);
//print_r($data_counts_wh);
//print_r($dates);
//echo '</pre>';
//exit;

$qry = "SELECT
	count(ecr_client_visits.pk_id) AS cnt, 
	ecr_client_visits.wh_id, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.date_of_visit
FROM
	ecr_client_visits
WHERE
	ecr_client_visits.from_api = '1' AND
	(
		app_local_visit_id = 0 OR
		app_local_visit_id IS NULL
	) ".$whr."
GROUP BY
	ecr_client_visits.wh_id, 
	ecr_client_visits.date_of_visit

order by ecr_client_visits.date_of_visit
	";
//    echo $client_referrals_query;
$visit_purpose_results = mysql_query($qry);
while($row = mysql_fetch_assoc($visit_purpose_results))
{
    @$data_counts['app_online'][$row['date_of_visit']][$row['wh_id']]   = $row['cnt'];
    @$data_counts_date['app_online'][$row['date_of_visit']]             += $row['cnt'];
    @$data_counts_wh['app_online'][$row['wh_id']]                       += $row['cnt'];
    $wh_names[$row['wh_id']]                                    = $row['wh_name'];
    $dates[$row['date_of_visit']]                               = $row['date_of_visit'];
}


$qry = "

SELECT
	count(ecr_client_visits.pk_id) AS cnt, 
	ecr_client_visits.wh_id, 
	ecr_client_visits.wh_name, 
	ecr_client_visits.date_of_visit
FROM
	ecr_client_visits
WHERE
	ecr_client_visits.from_api = '1' and app_local_visit_id > 0 ".$whr."
GROUP BY
	ecr_client_visits.wh_id, 
	ecr_client_visits.date_of_visit
order by ecr_client_visits.date_of_visit
	";
//    echo $client_referrals_query;
$visit_purpose_results = mysql_query($qry);

while($row = mysql_fetch_assoc($visit_purpose_results))
{
    @$data_counts['app_offline'][$row['date_of_visit']][$row['wh_id']]   = $row['cnt'];
    @$data_counts_date['app_offline'][$row['date_of_visit']]             += $row['cnt'];
    @$data_counts_wh['app_offline'][$row['wh_id']]                       += $row['cnt'];
    $wh_names[$row['wh_id']]                                    = $row['wh_name'];
    $dates[$row['date_of_visit']]                               = $row['date_of_visit'];
}


//echo '<pre>';
//print_r($dates);
//echo '</pre>';
//exit;
?> 
</head> 
<style>
    
</style>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">ECR Module Usage Stats</h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">From <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $from_date ?>"   max="<?= date('Y-m-d') ?>" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">To <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $to_date ?>"  max="<?= date('Y-m-d') ?>" id="to_date" name="to_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>
                                <hr/>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        $c = 1;


                                        echo '<img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>';
                                        echo '<img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>';
//                                        echo '<h3 align="center">ECR Stats - Visits Recorded Against Web / Online App / Offline App</h3>';
                                        echo '<div class="col-md-12" style="overflow-x: auto">';
                                        echo '<table id="table_1"  border="1" style="width:90%;" class="table table-bordered table-hover table-condensed" >';
                                        echo '<thead>';
                                        echo '<tr>';
                                        echo '<td colspan="'.(2 + count($dates)).'" style="text-align:center;"> <h3 align="center">ECR Stats - Visits Recorded Against Web / Online App / Offline App From '. $from_date .' to '. $to_date .'</h3></td>';
                                        echo '</tr>';
                                        echo '<tr class="bg-info">';
                                        echo '<th>Sr</th>';
                                        echo '<th>Type</th>';
                                        foreach ($dates as $date=>$d) {
                                            echo '<th>'.date('d-M-Y',strtotime($date)).'</th>';
                                        }
                                        echo '</tr>';
                                        echo '</thead>';

                                        echo '<tbody>';
                                        echo '<tr>';
                                        echo '<th>' . $c++ . '</th>';
                                        echo '<td>Android App - Online</td>';
                                        foreach ($dates as $date=>$d) {
                                            if(!empty($data_counts_date['app_online'][$date])){
                                                $val = $data_counts_date['app_online'][$date];
                                            }else{
                                                $val = 0;
                                            }
                                            
                                            echo '<td>'.$val.'</td>';
                                            @$graph_online .= $val.',';
                                            @$graph_dates .= "'".$date."',";
                                        }
                                        echo '</tr>';
                                        echo '<tr>';
                                        echo '<th>' . $c++ . '</th>';
                                        echo '<td>Android App - Offline Mode</td>';
                                        foreach ($dates as $date=>$d) {
                                            if(!empty($data_counts_date['app_offline'][$date])){
                                                $val = $data_counts_date['app_offline'][$date];
                                            }else{
                                                $val = 0;
                                            }
                                            
                                            echo '<td>'.$val.'</td>';
                                            @$graph_offline .= $val.',';
                                        }
                                        echo '</tr>';
                                        echo '<tr>';
                                        echo '<th>' . $c++ . '</th>';
                                        echo '<td>Web Based LMIS System</td>';
                                        foreach ($dates as $date=>$d) {
                                            if(!empty($data_counts_date['web'][$date])){
                                                $val = $data_counts_date['web'][$date];
                                            }else{
                                                $val = 0;
                                            }
                                            
                                            echo '<td>'.$val.'</td>';
                                            @$graph_web .= $val.',';
                                        }
                                        echo '</tr>';
                                        echo '</tbody>';

                                        echo '</table>';
                                        echo '</div>';
                                        echo '</div>';
                                        ?>
                                        
                                        
                                        
                                        <figure class="highcharts-figure">
                                            <div id="container2"></div>
                                            <p class="highcharts-description">
                                            </p>
                                        </figure>


                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>
    <script>
Highcharts.chart('container2', {
chart: {
        type: 'spline'
    },
    title: {
        text: 'Trend Line',
        align: 'center'
    },

    

    yAxis: {
        title: {
            text: 'Number of Visits Recorded'
        }
    },
xAxis: {
        categories: [<?=$graph_dates?>]
    },
     
colors: ['#2f7ed8', '#0d233a', '#8bbc21' ],
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
 

    series: [{
        name: 'Android App - Online Usage',
        data: [<?=$graph_online?>]
    }, {
        name: 'Android App - Offline Usage',
        data: [<?=$graph_offline?>]
    }, {
        name: 'Web System',
        data: [<?=$graph_web?>]
    }],

    responsive: {
        rules: [{
            condition: {
                maxWidth: 500
            },
            chartOptions: {
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom'
                }
            }
        }]
    }

});
    
</script>
</body>
</html>