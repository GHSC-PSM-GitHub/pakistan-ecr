<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;        
$from_date = date('Y-m-01');
$to_date = date('Y-m-d');
$stk = $_SESSION['user_stakeholder1'];

$district = $_REQUEST['district'];

$stakeholder = '';
$dd='';
if(!empty($district)){
    $dd='&district='.$district;
}

if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
if (!empty($_REQUEST['to_date']))
    $to_date = $_REQUEST['to_date'];

if (!empty($_REQUEST['stakeholder'])){
    $stakeholder = $_REQUEST['stakeholder'];
}
else{
    $stakeholder = 9;
}
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    table.table thead .sorting_disabled, table.table thead .sorting {
        background: #2272b7 !important;
        color: #FFF !important;
    }
    
</style>
    <link rel="stylesheet" type="text/css" href="../../public/assets/global/plugins/select2/select2.css"/>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Performance Report  </h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">From <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $from_date ?>"   max="<?= date('Y-m-d') ?>" min="2022-10-01" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">To <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $to_date ?>"  max="<?= date('Y-m-d') ?>" min="2022-10-01"  id="to_date" name="to_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>



                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">Stakeholder</label>
                                                    <div class="controls">
                                                        <select name="stakeholder" id="stakeholder" class="input-large  select2me" onchange="change_stk()" >

                                                            <?php
                                                            $qry = "SELECT
                                                                                        distinct stakeholder.stkname, 
                                                                                        stakeholder.stkid 
                                                                                FROM
                                                                                        stakeholder
                                                                                        INNER JOIN
                                                                                        tbl_warehouse
                                                                                        ON 
                                                                                                stakeholder.stkid = tbl_warehouse.stkid
                                                                                WHERE
                                                                                        tbl_warehouse.ecr_start_month is not null
                                                                                                                                                   ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            $stk_name = '';
//                                                            echo "<option value=\"\" selected> All </option>";
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                $sel = '';

                                                                if($stakeholder == $row['stkid']){
                                                                    $sel =  'selected="selected"';
                                                                    $stk_name = $row['stkname'];
                                                                }
                                                                echo "<option value=\"" . $row['stkid'] . "\" $sel>" . $row['stkname'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group ">
                                                    <label class="control-label">District</label>
                                                    <div class="controls" id="districtsCol">
                                                        <select name="district" id="district" class="form-control "  >

                                                            <?php
                                                            if ($_SESSION['user_level'] < '3') {
//                                                                echo '<option value="">All</option>';
                                                            }
                                                            if ($_SESSION['user_level'] == 1){
                                                                $prov_helper = " IN (2,4) ";
                                                            }
                                                            else{
                                                                $prov_helper = " = '". $_SESSION['user_province1']. "'";
                                                            }
                                                            if ($stakeholder == 1){
                                                                $lvl_helper = " AND lvl = 3";
                                                            }
                                                            else{
                                                                $lvl_helper = "";
                                                            }
                                                            $qry = "SELECT
                                                                            distinct PkLocID,
                                                                            LocName
                                                                    FROM
                                                                            tbl_locations

                                                                    INNER JOIN
                                                                    tbl_warehouse
                                                                    ON
                                                                            tbl_locations.PkLocID = tbl_warehouse.dist_id
                                                                    
	                                                                INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid 
                                                                    WHERE
                                                                            tbl_locations.ParentID $prov_helper AND LocLvl = '3' AND
                                                                    tbl_warehouse.stkid = $stakeholder $lvl_helper 
                                                                    ORDER BY
                                                                        LocName
                                                                               ";
                                                            $rsfd = mysql_query($qry) or die(mysql_error());
                                                            while ($row = mysql_fetch_array($rsfd)) {
                                                                if ($_SESSION['user_level'] > '2' && !empty($_SESSION['user_district'])) {
                                                                    $district = $_SESSION['user_district'];
                                                                    if ($row['PkLocID'] != $_SESSION['user_district'])
                                                                        continue;
                                                                }
                                                                $sel = ($_REQUEST['district'] == $row['PkLocID']) ? 'selected="selected"' : '';
                                                                echo "<option value=\"" . $row['PkLocID'] . "\" $sel>" . $row['LocName'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>
                                
                                
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                    <div class="table-responsive" style="overflow: auto;">
                                        <h4>Client Registrations - Summary</h4>
<!--                                        <a id="btnExport" onclick="javascript:xport.toCSV('table_1','Client_registrations');"><img style="cursor:pointer;" src="<?php echo PUBLIC_URL; ?>images/excel-32.png"  title="Export to Excel" /></a>-->
                                        <img src="../../public/images/excel-16.png" <i id="btnExport"  table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <?php
                                        $totals=array();
                                        $begin = new DateTime( $from_date );
                                        $end   = new DateTime( $to_date );
                                        $date_arr = array();
                                        for($i = $begin; $i <= $end; $i->modify('+1 day')){
                                            $this_date=$i->format("Y-m-d");
                                            $date_arr[$this_date]=$this_date;
                                        }  
//                                                echo '<pre>';
//                                                print_r($date_arr);
//                                                echo '</pre>';
//                                                exit;


                                        $from_date = date('Y-m-d', strtotime($from_date));
                                        $to_date = date('Y-m-d', strtotime($to_date));

                                        
                                        $qry2= "SELECT
                                                tbl_warehouse.wh_id, 
                                                tbl_warehouse.wh_name, 
                                                tbl_warehouse.dist_id, 
                                                tbl_warehouse.ecr_start_month, 
                                                dist.LocName as dist_name
                                        FROM
                                                tbl_warehouse
                                                INNER JOIN
                                                tbl_locations AS dist
                                                ON 
                                                        tbl_warehouse.dist_id = dist.PkLocID
                                        WHERE
                                                tbl_warehouse.ecr_start_month IS NOT NULL AND
                                                prov_id ='".$_SESSION['user_province1']."'";
                                        if(!empty($district)){
                                            $qry2 .= " and tbl_warehouse.dist_id = '".$district."' ";
                                        }
                                        if(!empty($stakeholder)){
                                            $qry2 .= "AND tbl_warehouse.stkid='".$stakeholder."'";
                                        }
                                        if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7'){
                                            $qry2 .= " and tbl_warehouse.wh_id = '".$_SESSION['user_warehouse']."' ";
                                        }
//                                        echo $qry2;exit;
                                        $res2 = mysql_query($qry2);
                                        $data_arr = $wh_arr = array();
                                        while ($row = mysql_fetch_assoc($res2)) {
                                            $wh_arr[$row['wh_id']] = $row;
                                            @$totals['total_wh']+=1;
                                        }


                                        if (!empty($district)) {
                                            $qry = 'SELECT
                                                            ecr_clients.registered_at, 
                                                            DATE_FORMAT(ecr_clients.created_on, "%Y-%m-%d") as date, 
                                                            count(ecr_clients.pk_id) AS total_registered, 
                                                            tbl_warehouse.wh_name
                                                    FROM
                                                            ecr_clients
                                                            INNER JOIN
                                                            tbl_warehouse
                                                            ON 
                                                            ecr_clients.registered_at = tbl_warehouse.wh_id
                                                    WHERE  created_on between "' . $from_date . '" and "' . $to_date . ' 23:59:59"
                                                        and tbl_warehouse.dist_id = "'.$district.'" 
                                                        and prov_id ="'.$_SESSION['user_province1'].'" ';
                                            if(!empty($stakeholder)){
                                                $qry .= "AND tbl_warehouse.stkid='".$stakeholder."'";
                                            }
                                            
                                        if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7'){
                                            $qry .= " and tbl_warehouse.wh_id = '".$_SESSION['user_warehouse']."' ";
                                        }
                                            $qry .='
                                                    GROUP BY
                                                            ecr_clients.registered_at, 
                                                            DATE_FORMAT(ecr_clients.created_on, "%Y-%m-%d")
                                                                
                                                        
                                        ';
                                        } else {
                                            // district wise aggregate
                                            $stk = '';
                                            if(!empty($stakeholder)){
                                                $stk .= "AND tbl_warehouse.stkid='".$stakeholder."'";
                                            }
                                            $qry = 'SELECT
                                                            ecr_clients.registered_at, 
                                                            DATE_FORMAT(ecr_clients.created_on, "%Y-%m-%d") as date, 
                                                            count(ecr_clients.pk_id) AS total_registered, 
                                                            tbl_warehouse.wh_name
                                                    FROM
                                                            ecr_clients
                                                            INNER JOIN
                                                            tbl_warehouse
                                                            ON 
                                                            ecr_clients.registered_at = tbl_warehouse.wh_id
                                                    WHERE  created_on between "' . $from_date . '" and "' . $to_date . ' 23:59:59"
                                                        and prov_id ="'.$_SESSION['user_province1'].'"
                                                        '. $stk .'
                                                        
                                                    GROUP BY
                                                            ecr_clients.registered_at, 
                                                            DATE_FORMAT(ecr_clients.created_on, "%Y-%m-%d")
                                                                
                                                        
                                        ';
                                        }
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        while ($row = mysql_fetch_assoc($res)) {
                                         
                                            @$data_arr[$row['registered_at']][$row['date']] = $row['total_registered'];
                                            @$totals['clients'][$row['date']]          +=$row['total_registered'];
                                            @$totals['clients'][$row['registered_at']] +=$row['total_registered'];
                                            @$totals['clients']['all'] +=$row['total_registered'];
                                        }
//                                        echo '<pre>';
//                                        print_r($wh_arr);
//                                        print_r($data_arr);
//                                        echo '</pre>';    
//                                        exit;
                                        $c = 1;

                                        echo '<table id="table_1" border="1" class="table table-bordered table-condensed">';
                                        echo '<thead>';
                                        echo '<tr>';
                                        echo '<td colspan="'.(3 + count($date_arr)).'" style="text-align:center;"> Client Registrations - Summary From '. $from_date .' to '. $to_date .'</td>';
                                        echo '</tr>';
                                        echo '<tr >';
                                        echo '<th>#</th>';
                                        echo '<th> District</th>';
                                        echo '<th> Facility Name  </th>';
                                        foreach ($date_arr as $k => $v) {
                                            echo '<th><a href="daily_performance.php?from_date=' . date('Y-m-d',strtotime($v)) .''.$dd. '">' . date('d-M-Y',strtotime($v)) . '</a></th>';
//                                            echo '<th>' . date('d-M-Y',strtotime($v)) . '</th>';
                                        }
                                        
                                        echo '<th class="info">Total</th>';
                                        echo '</tr>';
                                        echo '</thead>';
                                        foreach ($wh_arr as $wh_id => $wh) {
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';

                                            echo '<td>' . $wh['dist_name'] ;
//                                            if (empty($district)) {
//                                                echo '<a href="summarized_issuance_report.php?from_date=' . $from_date . '&to_date=' . $to_date . '&district=' . $fac_name['dist_id'] . '"> <i class="fa fa-search font-blue"> View Details</i> </a> ';
//                                            }
                                            echo '</td>';

                                                echo '<td >' . $wh['wh_name'];
                                                echo '</td>';
                                             foreach ($date_arr as $k => $v) {
                                                if (!empty($data_arr[$wh_id][$k])) {
                                                echo '<td align="right">' . $data_arr[$wh_id][$k] . ' </td>';
                                                } else {
                                                echo '<td></td>';
                                                }
                                            }
                                            
                                            echo '<td class="info" align="right">' . @$totals['clients'][$wh_id]  . ' </td>';
                                            echo '</tr>';
                                        }
                                        echo '<tr class="info">';
                                            echo '<td > TOTALS</td>';
                                            echo '<td > </td>';

                                            echo '<td>'.$totals['total_wh'].' Facilities</td>';

                                              
                                             foreach ($date_arr as $k => $v) {
                                                if (!empty($totals['clients'][$k])) {
                                                echo '<td align="right">' . $totals['clients'][$k] . ' </td>';
                                                } else {
                                                echo '<td align="right">0</td>';
                                                }
                                            }
                                            echo '<td align="right">' . @$totals['clients']['all']  . ' </td>';
                                            
                                            echo '</tr>';
                                        echo '</table>';
                                        ?>
                                    </div>
                                    </div>
                                </div>
                            
                            
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body" style="overflow: auto;">
                                        <h4>Visits - Summary</h4>
<!--                                        <a id="btnExport" onclick="javascript:xport.toCSV('table_2','Visits_summary');"><img style="cursor:pointer;" src="<?php echo PUBLIC_URL; ?>images/excel-32.png"  title="Export to Excel" /></a>-->
                                        <img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_2" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_2" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>
<?php
                                        
                                        if (!empty($district)) {
                                            $qry = 'SELECT
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id, 
                                                    count(ecr_client_visits.pk_id) as total_visits
                                            FROM
                                                    ecr_client_visits
                                            INNER JOIN
                                            tbl_warehouse
                                            ON 
                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                            INNER JOIN ecr_clients on ecr_client_visits.client_id = ecr_clients.pk_id

                                            WHERE  date_of_visit between "' . $from_date . '" and "' . $to_date . '"
                                                and tbl_warehouse.dist_id = "'.$district.'" ';

                                            if (!empty($stakeholder)) {
                                                $qry .= "AND tbl_warehouse.stkid='" . $stakeholder . "'";
                                            }
                                        if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7'){
                                            $qry .= " and tbl_warehouse.wh_id = '".$_SESSION['user_warehouse']."' ";
                                        }
                                            $qry .='
                                            group by 
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id
                                        ';
                                        } else {
                                            // district wise aggregate
                                            $stk = '';
                                            if(!empty($stakeholder)){
                                                $stk .= "AND tbl_warehouse.stkid='".$stakeholder."'";
                                            }
                                            $qry = 'SELECT
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id, 
                                                    count(ecr_client_visits.pk_id) as total_visits
                                            FROM
                                                    ecr_client_visits
                                            INNER JOIN
                                            tbl_warehouse
                                            ON 
                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                            INNER JOIN ecr_clients on ecr_client_visits.client_id = ecr_clients.pk_id

                                            WHERE  date_of_visit between "' . $from_date . '" and "' . $to_date . '"
                                            '. $stk .'
                                            group by 
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id
                                        ';
                                        }
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_visits=array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                         
                                            @$data_visits[$row['wh_id']][$row['date_of_visit']] = $row['total_visits'];
                                            @$totals['visits'][$row['date_of_visit']]          +=$row['total_visits'];
                                            @$totals['visits'][$row['wh_id']]                  +=$row['total_visits'];
                                            @$totals['visits']['all']                  +=$row['total_visits'];
                                        }
//                                        echo '<pre>';
//                                        print_r($wh_arr);
//                                        print_r($data_arr);
//                                        echo '</pre>';    
//                                        exit;
                                        $c = 1;

                                        echo '<table id="table_2" border="1" class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td colspan="'.(3 + count($date_arr)).'" style="text-align:center;"> Visits - Summary From '. $from_date .' to '. $to_date .'</td>';
                                        echo '</tr>';
                                        echo '<tr class="info">';
                                        echo '<td>#</td>';
                                        echo '<td> District</td>';
                                        echo '<td> Facility Name  </td>';
                                        foreach ($date_arr as $k => $v) {
                                            echo '<td><a href="daily_performance.php?from_date=' . date('Y-m-d',strtotime($v)) .''.$dd.  '">' . date('d-M-Y',strtotime($v)) . '</a></td>';
                                        }
                                        echo '<td class="info">Total</td>';
                                        echo '</tr>';
                                        foreach ($wh_arr as $wh_id => $wh) {
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';

                                            echo '<td>' . $wh['dist_name'] ;
//                                            if (empty($district)) {
//                                                echo '<a href="summarized_issuance_report.php?from_date=' . $from_date . '&to_date=' . $to_date . '&district=' . $fac_name['dist_id'] . '"> <i class="fa fa-search font-blue"> View Details</i> </a> ';
//                                            }
                                            echo '</td>';

                                                echo '<td >' . $wh['wh_name'];
                                                echo '</td>';
                                             foreach ($date_arr as $k => $v) {
                                                if (!empty($data_visits[$wh_id][$k])) {
                                                echo '<td align="right">' . $data_visits[$wh_id][$k] . ' </td>';
                                                } else {
                                                echo '<td></td>';
                                                }
                                            }
                                            echo '<td  class="info" align="right">' . @$totals['visits'][$wh_id]  . ' </td>';
                                            
                                            echo '</tr>';
                                        }
                                        
                                        
                                            echo '<tr class="info">';
                                            echo '<td colspan="2"> TOTALS</td>';

                                            echo '<td>'.$totals['total_wh'].' Facilities</td>';

                                              
                                             foreach ($date_arr as $k => $v) {
                                                if (!empty($totals['visits'][$k])) {
                                                echo '<td align="right">' . $totals['visits'][$k] . ' </td>';
                                                } else {
                                                echo '<td align="right">0</td>';
                                                }
                                            }
                                            echo '<td align="right">' . $totals['visits']['all']  . ' </td>';
                                            
                                            echo '</tr>';
                                        echo '</table>';
                                        ?>
                                    </div>
                                </div>
                                
                            
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body" style="overflow: auto;">
                                        <h4>Visits - Purpose Wise Breakdown </h4>
<!--                                        <a id="btnExport" onclick="javascript:xport.toCSV('table_3','visit_purpose');"><img style="cursor:pointer;" src="<?php echo PUBLIC_URL; ?>images/excel-32.png"  title="Export to Excel" /></a>-->
                                        <img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_3" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_3" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>
<?php
                                        
                                        if (!empty($district)) {
                                            $qry = 'SELECT
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id, 
                                                    count(ecr_client_visits.pk_id) as total_visits, 
	ecr_client_visits.visit_purpose
                                            FROM
                                                    ecr_client_visits
                                            INNER JOIN
                                            tbl_warehouse
                                            ON 
                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                            INNER JOIN ecr_clients on ecr_client_visits.client_id = ecr_clients.pk_id

                                            WHERE  date_of_visit between "' . $from_date . '" and "' . $to_date . '"
                                                and tbl_warehouse.dist_id = "'.$district.'" ';

                                            if(!empty($stakeholder)){
                                                $qry2 .= "AND tbl_warehouse.stkid='".$stakeholder."'";
                                            }
                                        if(!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7'){
                                            $qry .= " and tbl_warehouse.wh_id = '".$_SESSION['user_warehouse']."' ";
                                        }
                                            $qry .='
                                            group by 
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id, 
	ecr_client_visits.visit_purpose
                                        ';
                                        } else {
                                            // district wise aggregate
                                            $stk = '';
                                            if(!empty($stakeholder)){
                                                $stk .= "AND tbl_warehouse.stkid='".$stakeholder."'";
                                            }
                                            $qry = 'SELECT
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id, 
                                                    count(ecr_client_visits.pk_id) as total_visits, 
	ecr_client_visits.visit_purpose
                                            FROM
                                                    ecr_client_visits
                                            INNER JOIN
                                            tbl_warehouse
                                            ON 
                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                            INNER JOIN ecr_clients on ecr_client_visits.client_id = ecr_clients.pk_id

                                            WHERE  date_of_visit between "' . $from_date . '" and "' . $to_date . '"
                                            '. $stk .'
                                            group by 
                                                    ecr_client_visits.date_of_visit, 
                                                    ecr_client_visits.wh_id, 
	ecr_client_visits.visit_purpose
                                        ';
                                        }
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_visits=array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                         
                                            @$data_purpose[$row['wh_id']][$row['date_of_visit']][$row['visit_purpose']]     = $row['total_visits'];
                                            @$totals['purpose'][$row['visit_purpose']][$row['date_of_visit']]          +=$row['total_visits'];
                                            @$totals['purpose'][$row['visit_purpose']][$row['wh_id']]                  +=$row['total_visits'];
                                            @$totals['purpose'][$row['visit_purpose']]['all']                  +=$row['total_visits'];
                                        }
//                                        echo '<pre>';
//                                        print_r(@$totals);
//                                        print_r(@$data_purpose);
//                                        echo '</pre>';    
//                                        exit;
                                        $c = 1;

                                        echo '<table id="table_3" border="1" class="table table-bordered table-condensed">';
                                        echo '<tr>';
                                        echo '<td colspan="'.(3 + count($date_arr)).'" style="text-align:center;"> Visits - Purpose Wise Breakdown  From '. $from_date .' to '. $to_date .'</td>';
                                        echo '</tr>';
                                        echo '<tr class="info">';
                                        echo '<td>#</td>';
                                        echo '<td> District</td>';
                                        echo '<td> Facility Name  </td>';
                                        foreach ($date_arr as $k => $v) {
                                            echo '<td><a href="daily_performance.php?from_date=' . date('Y-m-d',strtotime($v)) . ''.$dd. '">' . date('d-M-Y',strtotime($v)) . '</a></td>';
                                        }
                                        echo '<td class="info">Total Visits</td>';
                                        echo '</tr>';
                                        foreach ($wh_arr as $wh_id => $wh) {
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';

                                            echo '<td>' . $wh['dist_name'] ;
//                                            if (empty($district)) {
//                                                echo '<a href="summarized_issuance_report.php?from_date=' . $from_date . '&to_date=' . $to_date . '&district=' . $fac_name['dist_id'] . '"> <i class="fa fa-search font-blue"> View Details</i> </a> ';
//                                            }
                                            echo '</td>';

                                                echo '<td >' . $wh['wh_name'];
                                                echo '</td>';
                                             foreach ($date_arr as $k => $v) {
                                                if (!empty($data_purpose[$wh_id][$k])) {
                                                echo '<td align="left">';
                                                    echo 'FPS:' . (!empty($data_purpose[$wh_id][$k]['fp'])?'<span class="badge badge-info">'.$data_purpose[$wh_id][$k]['fp'].'</span>':'0');
                                                    echo '<br/>LAR:'.(!empty($data_purpose[$wh_id][$k]['larc_removal'])?'<span class="badge badge-success">'.$data_purpose[$wh_id][$k]['larc_removal'].'</span>':'0');
                                                    echo '<br/>GHS:'.(!empty($data_purpose[$wh_id][$k]['ghs'])?'<span class="badge badge-warning">'.$data_purpose[$wh_id][$k]['ghs'].'</span>':'0');
                                                echo  ' </td>';
                                                } else {
                                                echo '<td></td>';
                                                }
                                            }
                                            echo '<td  class="info" align="left">';
                                                    echo 'FPS:' . (!empty($totals['purpose']['fp'][$wh_id])?'<span class="badge badge-info">'.$totals['purpose']['fp'][$wh_id].'</span>':'0');
                                                    echo '<br/>LAR:'.(!empty($totals['purpose']['larc_removal'][$wh_id])?'<span class="badge badge-success">'.$totals['purpose']['larc_removal'][$wh_id].'</span>':'0');
                                                    echo '<br/>GHS:'.(!empty($totals['purpose']['ghs'][$wh_id])?'<span class="badge badge-warning">'.$totals['purpose']['ghs'][$wh_id].'</span>':'0');
                                                echo  '  </td>';
                                            echo '</tr>';
                                        }
                                        
                                        
                                            echo '<tr class="info">';
                                            echo '<td colspan="2"> TOTALS</td>';

                                            echo '<td>'.$totals['total_wh'].' Facilities</td>';

                                              
                                             foreach ($date_arr as $k => $v) {
                                                    
                                            echo '<td  align="left">';
                                                echo 'FPS:' . (!empty($totals['purpose']['fp'][$k])?'<span class="badge badge-info">'.$totals['purpose']['fp'][$k].'</span>':'0');
                                                echo '<br/>LAR:'.(!empty($totals['purpose']['larc_removal'][$k])?'<span class="badge badge-success">'.$totals['purpose']['larc_removal'][$k].'</span>':'0');
                                                echo '<br/>GHS:'.(!empty($totals['purpose']['ghs'][$k])?'<span class="badge badge-warning">'.$totals['purpose']['ghs'][$k].'</span>':'0');
                                            echo  '  </td>';
                                            }
                                            echo '<td  align="left">';
                                                echo 'FPS:' . (!empty($totals['purpose']['fp']['all'])?'<span class="badge badge-info">'.$totals['purpose']['fp']['all'].'</span>':'0');
                                                echo '<br/>LAR:'.(!empty($totals['purpose']['larc_removal']['all'])?'<span class="badge badge-success">'.$totals['purpose']['larc_removal']['all'].'</span>':'0');
                                                echo '<br/>GHS:'.(!empty($totals['purpose']['ghs']['all'])?'<span class="badge badge-warning">'.$totals['purpose']['ghs']['all'].'</span>':'0');
                                            echo  '  </td>';
                                            
                                            echo '</tr>';
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                        <span class="note note-warning">Legend: <span class="badge badge-info">FPS</span>='Family Planning Services', <span class="badge badge-warning">GHS</span>='General Health Services', <span class="badge badge-success">LAR</span>='LARC Removal'</span>
                                    </div>
                                </div>
                                
                            
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
<?php
include PUBLIC_PATH . "/html/footer.php";
?>

    <script>

        function change_stk(){
            const stk = $('#stakeholder').val();
            $.ajax({
                url: "ajax_stk_dist.php",
                type: 'post',
                data: {
                    stk: stk
                },
                success: function(html){
                    $("#districtsCol").html(html);
                }
            });
        }
    </script>

    <script type="text/javascript" src="../../public/assets/global/plugins/select2/select2.min.js"></script>

</body>
</html>