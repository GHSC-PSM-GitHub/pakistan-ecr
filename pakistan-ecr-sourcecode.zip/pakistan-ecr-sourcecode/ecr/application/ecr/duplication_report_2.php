<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Duplication Report - Based on duplicate Serial Numbers</h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    


                                </form>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        
                                        $qry = "
                                          SELECT
                                                ecr_clients.serial_number,
                                                count(*) as cnt,
                                                GROUP_CONCAT(ecr_clients.cnic) as cnic,
                                                GROUP_CONCAT(ecr_clients.pk_id) as pk_id,
                                                GROUP_CONCAT(ecr_clients.registered_at) as registered_at,
                                                GROUP_CONCAT(client_name) as cname,
                                                GROUP_CONCAT(father_name) as fname,
                                                GROUP_CONCAT(contact_number) as contact,
                                                GROUP_CONCAT(REPLACE(tbl_warehouse.wh_name, ',', ' ')) as wh_name
                                        FROM
                                                ecr_clients
                                                inner join tbl_warehouse on ecr_clients.registered_at = tbl_warehouse.wh_id
										";
                                        if($_SESSION['user_id']!= '9744'){
                                            $qry .= " WHERE  ecr_clients.registered_at = '".$_SESSION['user_warehouse']."' ";
                                        }
                                           $qry .= "     group by ecr_clients.serial_number
                                                having count(*) > 1
                                                order by count(*) desc,pk_id
                                        limit 200
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
//                                        echo '<pre>';
//                                        print_r($data_arr);
//                                        echo '</pre>';    

                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                            echo '<tr>';
                                            echo '<td>#</td>';
                                            echo '<td>serial_number</td>';
                                            echo '<td>CNIC</td>';
                                            echo '<td>Possible Duplicates</td>';
                                            echo '<td>No of Visits</td>';
                                            echo '<td>Registered at</td>';
                                            echo '<td>Name</td>';
                                            echo '<td>F/H Name</td>';
                                            echo '<td>Contact</td>';
                                            echo '<td>Action</td>';
                                            echo '</tr>';
                                        foreach ($data_arr as $k => $obj) {
                                           
                                            
                                            $q3 = "
                                                select count(*) as visits
                                                from ecr_client_visits 
                                                where client_id in 
                                                (select pk_id from ecr_clients where serial_number = '".$obj['serial_number']."')";
                                            
                                            $res3 = mysql_query($q3);
                                            $visits = mysql_fetch_assoc($res3);
                                            
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $obj['serial_number'] . '</td>';
                                            echo '<td>' . $obj['cnic'] . '</td>';
                                            echo '<td>' . $obj['cnt'] . '</td>';
                                            echo '<td>' . $visits['visits'] . '</td>';
                                            echo '<td>' . str_replace(',', '</br>', $obj['wh_name']);
//                                            if((!empty($obj['registered_at']) && $obj['registered_at']==$_SESSION['user_warehouse'])  || $_SESSION['user_id']== '9744')
//                                            {
//                                                echo '<br/><a class="btn btn-xs btn-danger" href="edit_client.php?client_id='.$obj['pk_id'].'"><i class="fa fa-pencil"></i> Edit </a>';
//                                            }
//                                            
                                            echo '</td>';
                                            echo '<td>' . str_replace(',', '</br>', $obj['cname']) . '</td>';
                                            echo '<td>' . str_replace(',', '</br>', $obj['fname']) . '</td>';
                                            echo '<td>' . str_replace(',', '</br>', $obj['contact']) . '</td>';
                                            echo '<td> <a class="btn btn-xs btn-success" href="duplication_view.php?param=serial_number&value='.$obj['serial_number'].'">View</a> ';
                                            if($_SESSION['user_id']== '9744')
                                            {
                                            echo ' <a target="_blank" class="btn btn-xs btn-warning" href="merge.php?param=serial_number&value='.$obj['serial_number'].'">Merge</a> ';
                                            }
                                            echo '</td>';
                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>