<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$dist = $_REQUEST['dist'];
$type = $_REQUEST['type'];
$a_date = '2023-06-01';


$data_counts = array();
$qry = "SELECT
	tbl_locations.PkLocID, 
	tbl_locations.LocName, 
	tbl_warehouse.hf_type_id, 
	tbl_warehouse.dist_id, 
	tbl_warehouse.wh_id, 
	tbl_warehouse.wh_name, 
	tbl_hf_type.hf_type
FROM
	tbl_warehouse
	INNER JOIN
	tbl_locations
	ON 
		tbl_warehouse.dist_id = tbl_locations.PkLocID
	INNER JOIN
	tbl_hf_type
	ON 
		tbl_warehouse.hf_type_id = tbl_hf_type.pk_id
	INNER JOIN
	stakeholder
	ON 
		tbl_warehouse.stkofficeid = stakeholder.stkid
WHERE
	tbl_warehouse.prov_id = ".$_SESSION['user_province1']." 
            
	and ecr_start_month is not null ";
$qry .= "
	and tbl_warehouse.is_active = 1
        and tbl_warehouse.dist_id = ".$dist."
        and tbl_warehouse.hf_type_id = ".$type."
	and stakeholder.lvl = 7

Order BY
        LocName,tbl_hf_type.hf_type
	";
//    echo $qry;
$visit_purpose_results = mysql_query($qry);
while ($row = mysql_fetch_assoc($visit_purpose_results)) {
    $dist_names[$row['dist_id']] = $row['LocName'];
    $type_names[$row['hf_type_id']] = $row['hf_type'];
    $hf_names[$row['wh_id']] = $row['wh_name'];
}



$qry = "SELECT
	tbl_locations.PkLocID, 
	tbl_locations.LocName, 
	tbl_warehouse.hf_type_id, 
	tbl_warehouse.dist_id, 
	tbl_warehouse.wh_id, 
	tbl_warehouse.wh_name,
	tbl_hf_type.hf_type
FROM
	tbl_warehouse
	INNER JOIN
	tbl_locations
	ON 
		tbl_warehouse.dist_id = tbl_locations.PkLocID
	INNER JOIN
	stakeholder
	ON 
		tbl_warehouse.stkofficeid = stakeholder.stkid
	INNER JOIN
	tbl_hf_type
	ON 
		tbl_warehouse.hf_type_id = tbl_hf_type.pk_id
        and tbl_warehouse.dist_id = ".$dist."
        and tbl_warehouse.hf_type_id = ".$type."
WHERE
	tbl_warehouse.prov_id = ".$_SESSION['user_province1']." 
           -- AND	tbl_warehouse.stkid = ".$_SESSION['user_stakeholder1']."
	and ecr_start_month is not null

	and tbl_warehouse.is_active = 1
	and stakeholder.lvl = 7

Order BY
        LocName
	";
//    echo $client_referrals_query;
$visit_purpose_results = mysql_query($qry);
while ($row = mysql_fetch_assoc($visit_purpose_results)) {
    @$dist_counts_ecr[$row['dist_id']][$row['hf_type_id']] = $row['cc'];
    @$type_counts_ecr[$row['hf_type_id']] += $row['cc'];

    $dist_names[$row['dist_id']] = $row['LocName'];
    $type_names[$row['hf_type_id']] = $row['hf_type'];
}


$qry = "SELECT
	tbl_warehouse.dist_id, 
	tbl_warehouse.hf_type_id, 
        ecr_client_visits.wh_id,
	count(ecr_client_visits.pk_id) AS visits
FROM
	ecr_client_visits
	INNER JOIN
	tbl_warehouse
	ON 
		ecr_client_visits.wh_id = tbl_warehouse.wh_id
WHERE
	date_of_visit > '".$a_date."'
        and tbl_warehouse.dist_id = ".$dist."
        and tbl_warehouse.hf_type_id = ".$type."
GROUP BY
	 ecr_client_visits.wh_id
HAVING
	count(ecr_client_visits.pk_id) > 5
ORDER BY
	count(ecr_client_visits.pk_id) ASC  
	";
$active_res = mysql_query($qry);
while ($row = mysql_fetch_assoc($active_res)) {
    @$active_hf[$row['wh_id']] = $row['visits'];
}

//echo '<pre>';
//print_r($active_counts_ecr);
//echo '</pre>';
//exit;
?> 

<style>
    #container2 {
        max-width: 400px;
        margin: 0 auto;
    }

    .highcharts-figure,
    .highcharts-data-table table {
        min-width: 380px;
        max-width: 600px;
        margin: 0 auto;
    }

    .highcharts-data-table table {
        font-family: Verdana, sans-serif;
        border-collapse: collapse;
        border: 1px solid #ebebeb;
        margin: 10px auto;
        text-align: center;
        width: 100%;
        max-width: 500px;
    }

    .highcharts-data-table caption {
        padding: 1em 0;
        font-size: 1.2em;
        color: #555;
    }

    .highcharts-data-table th {
        font-weight: 600;
        padding: 0.5em;
    }

    .highcharts-data-table td,
    .highcharts-data-table th,
    .highcharts-data-table caption {
        padding: 0.5em;
    }

    .highcharts-data-table thead tr,
    .highcharts-data-table tr:nth-child(even) {
        background: #f8f8f8;
    }

    .highcharts-data-table tr:hover {
        background: #f1f7ff;
    }


</style>
</head> 
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/solid-gauge.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">ECR - Actively Reporting Facilities </h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 


                                        </div>
                                    </div>


                                </form>
                                <hr/>
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        $c = 1;
                                        $c = 1;
                                        echo '<img src="../../public/images/excel-16.png" <i id="btnExport" table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>';
                                        echo '<img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>';
//                                        echo '<h3 align="center">ECR Facilities Status - Facility List</h3>';
                                        echo '<table id="table_1"  border="1" style="width:90%;" class="table table-bordered table-hover table-condensed" >';
                                        echo '<thead>';
                                        echo '<tr>';
                                        echo '<td colspan="'.(2 + count($hf_names)).'" style="text-align:center;"> <h3 align="center"> ECR Facilities Status - Facility List </h3></td>';
                                        echo '</tr>';
                                        echo '<tr class="bg-info">';
                                        echo '<th>Sr</th>';
                                        echo '<th>Facility</th>';
                                        echo '<th>Actively Reporting ?</th>';
                                        echo '<th>Visits Recorded Since '.$a_date.'</th>';
                                       
                                        echo '</tr>';
                                        echo '</thead>';

                                        echo '<tbody>';

                                        foreach ($hf_names as $wh_id => $wh_name) {
                                            if(!empty($active_hf[$wh_id])&&$active_hf[$wh_id]>0&&$active_hf[$wh_id]<20){
                                                $cls = 'warning';
                                            }elseif(!empty($active_hf[$wh_id])&&$active_hf[$wh_id]>=20){
                                                $cls = '';
                                            }else{
                                                $cls = 'danger';
                                            }
                                            
                                            echo '<tr class="'.$cls.'">';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $wh_name . '</td>';
                                            echo '<td>' . ((!empty($active_hf[$wh_id])&&$active_hf[$wh_id]>0)?'Active':'-') . '</td>';
                                            echo '<td>' . ((!empty($active_hf[$wh_id]))?$active_hf[$wh_id]:'0') . '</td>';
                                            echo '</tr>';
                                        }
                                        echo '</tbody>';

                                        echo '</table>';
                                        ?>
                                        

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

    <script> 
        
        $('#show_breakdown').click(function () {
                $("#table_a tbody tr").first().show("fast", function showNext() {
                    $(this).next("tr").show("fast", showNext);
                });
                $(this).hide();
            });
        
        
        // Uncomment to style it like Apple Watch
        /*
if (!Highcharts.theme) {
    Highcharts.setOptions({
        chart: {
            backgroundColor: 'black'
        },
        colors: ['#F62366', '#9DFF02', '#0CCDD6'],
        title: {
            style: {
                color: 'silver'
            }
        },
        tooltip: {
            style: {
                color: 'silver'
            }
        }
    });
}
// */

        /**
         * In the chart render event, add icons on top of the circular shapes
         */
        function renderIcons() { }

        Highcharts.chart('container2', {

            chart: {
                type: 'solidgauge',
                height: '110%',
                events: {
                    render: renderIcons
                }
            },

            title: {
                text: 'Upgraded Facilities',
                style: {
                    fontSize: '24px'
                }
            },

            tooltip: {
                borderWidth: 0,
                backgroundColor: 'none',
                shadow: false,
                style: {
                    fontSize: '16px'
                },
                valueSuffix: '%',
                pointFormat: '{series.name}<br><span style="font-size:2em; color: {point.color}; font-weight: bold">{point.y}</span>',
                positioner: function (labelWidth) {
                    return {
                        x: (this.chart.chartWidth - labelWidth) / 2,
                        y: (this.chart.plotHeight / 2) + 15
                    };
                }
            },

            pane: {
                startAngle: 0,
                endAngle: 360,
                background: []
            },

            yAxis: {
                min: 0,
                max: 100,
                lineWidth: 0,
                tickPositions: []
            },

            plotOptions: {
                solidgauge: {
                    dataLabels: {
                        enabled: false
                    },
                    linecap: 'round',
                    stickyTracking: false,
                    rounded: true
                }
            },

            series: [{
                    name: 'RHS-A',
                    data: [{
                            color: Highcharts.getOptions().colors[0],
                            radius: '110%',
                            innerRadius: '95%',
                            y: <?php echo (!empty($type_total[4]['converted']) && !empty($type_total[4]['total']))?round($type_total[4]['converted']*100/$type_total[4]['total'],1):0; ?>
                        }]
                }, {
                    name: 'OB-GYN Units',
                    data: [{
                            color: Highcharts.getOptions().colors[5],
                            radius: '90%',
                            innerRadius: '75%',
                            y: <?php echo (!empty($type_total[130]['converted']) && !empty($type_total[130]['total']))?round($type_total[130]['converted']*100/$type_total[130]['total'],1):0; ?>
                        }]
                }, {
                    name: 'FWC',
                    data: [{
                            color: Highcharts.getOptions().colors[2],
                            radius: '70%',
                            innerRadius: '56%',
                            y: <?php echo (!empty($type_total[1]['converted']) && !empty($type_total[1]['total']))?round($type_total[1]['converted']*100/$type_total[1]['total'],2):0; ?>
                        }]
                },   {
                    name: 'MSU',
                    data: [{
                            color: Highcharts.getOptions().colors[4],
                            radius: '50%',
                            innerRadius: '37%',
                            y: <?php echo (!empty($type_total[2]['converted']) && !empty($type_total[2]['total']))?round($type_total[2]['converted']*100/$type_total[2]['total'],1):0; ?>
                        }]
                }]
        });

    </script>

</body>
</html>