<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$param = $_REQUEST['param'];
$value = $_REQUEST['value'];

?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS
                                     
                        <?php
                        if(!is_request_from_mobile())
                        {
                        ?>
                            <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                         <?php
                        }
                        ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Duplication Details </h3>
                            </div>
                            <div class="widget-body">
                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <?php
                                        
                                        $qry = "
                                          SELECT 
                                            ecr_clients.*,
                                            tbl_warehouse.wh_name,
                                            (select count(*) from ecr_client_visits where client_id = ecr_clients.pk_id) as visits
                                        FROM
                                                ecr_clients
                                        INNER JOIN
                                        tbl_warehouse
                                        ON 
                                        ecr_clients.registered_at = tbl_warehouse.wh_id
                                        Where ecr_clients.".$param." = '".$value."'
                                        ";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);
                                        $data_arr = array();
                                        while ($row = mysql_fetch_assoc($res)) {
                                            $data_arr[] = $row;
                                        }
//                                        echo '<pre>';
//                                        print_r($data_arr);
//                                        echo '</pre>';    

                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                               echo '<tr class="info">';
                                        echo ' 
                                                <th>#</th>
                                                <th>Registered At</th>
                                                <th>System ID</th>
                                                <th>System Registration No.</th>
                                                <th>Reg Date</th>
                                                <th>Clients Name</th>
                                                <th>Father/Husband</th>
                                                <th>CNIC</th>
                                                
                                                <th>Contact</th>
                                                <th>CRC</th>
                                                <th>Catchment</th>
                                                <th>Occupation</th>
                                                <th>Education</th>
                                                <th>Age Today</th>
                                                <th>Years of Marriage</th>
                                                <th>Visits</th>
                                                <th>Actions</th>
                                                
                                            ';
                                        echo '</tr>';
                                        foreach ($data_arr as $pk_id => $v) {
                                            
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $v['wh_name'] . '</td>';
                                            echo '<td>' . $v['pk_id'] . '</td>';
                                            echo '<td>' . $v['serial_number'] . '</td>';
                                            echo '<td>' . date('Y-M-d',strtotime($v['created_on'])) . '</td>';
                                            echo '<td>' . $v['client_name'];
                                            if(!empty($v['status']) && $v['status'] == '2'){
                                                echo '<a class=" pull-right">( <i class="fa fa-flag font-red"></i>Duplicate ) </a>';
                                            }
                                            echo '</td>';
                                            echo '<td>' . $v['father_name'] . '</td>';
                                            echo '<td>' . $v['cnic'] . '</td>';
                                            echo '<td>' . $v['contact_number'] . '</td>';
                                            echo '<td>' . ucfirst($v['crc_new_old']) . '</td>';
                                            echo '<td>' . ucfirst($v['catchment_area']) . '</td>';
                                            echo '<td>' . ucfirst($v['occupation']) . '</td>';
                                            echo '<td>' . ucfirst($v['education']) . '</td>';
                                            echo '<td>' . $v['age_today'] . '</td>';
                                            echo '<td>' . $v['age_when_married'] . '</td>';
                                            echo '<td>' . $v['visits'] . '</td>';
                                            echo '<td>';
                                            echo '<a class="btn btn-xs btn-info" href="view_client.php?client_id='.$v['pk_id'].'"><i class="fa fa-folder-open-o"></i>  View Details</a>';
                                            if((!empty($v['registered_at']) && $v['registered_at']==$_SESSION['user_warehouse']) || $_SESSION['user_id'] == '9744')
                                            {
                                                echo '<br/><a class="btn btn-xs btn-danger" href="edit_client.php?client_id='.$v['pk_id'].'"><i class="fa fa-pencil"></i> Edit </a>';
                                            }
                                            echo '<br/><a onclick="return confirm(\'Are you sure to mark this client as duplicate?\')" class="btn btn-sm btn-circle default red-sunglo" href="flag_client.php?client_id=' . $v['pk_id'] . '&redirect=duplication_report"><i class="fa fa-flag"></i> Mark as Duplicate</a>';
                                            echo '</td>';
                                            echo '</tr>';
                                        }
                                        echo '</table>';
                                        if($c>2 && $_SESSION['user_id']== '9744'){
                                            echo ' <a class="btn btn-warning" href="merge.php?param='.$param.'&value='.$value.'">Merge All Above</a> ';
                                        }
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>