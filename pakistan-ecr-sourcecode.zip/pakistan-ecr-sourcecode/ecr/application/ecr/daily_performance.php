<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
//echo '<pre>';
//print_r($_SESSION);
//echo '</pre>';
//exit;        
$from_date = date('Y-m-d');
$stk = $_SESSION['user_stakeholder1'];

$district = $_REQUEST['district'];

if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
?>
<script src="<?php echo PUBLIC_URL; ?>assets/chart.min.js"></script>
<script src="<?php echo PUBLIC_URL; ?>assets/utils.js"></script>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> Daily Performance Report  </h3>
                            </div>
                            <div class="widget-body">
                                <form method="GET" name="add_client" id="add_client" action=""  >
                                    <div class="row">
                                        <div class="col-md-12"> 

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="control-label" for="date_of_visit">Date <span class="font-red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="date" required value="<?= $from_date ?>"   max="<?= date('Y-m-d') ?>" min="2022-10-01" id="from_date" name="from_date" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <label class="control-label" for="">&nbsp;</label>
                                                    <div class="controls">
                                                        <input type="submit" value="Search" class="form-control btn btn-success">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </form>


                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <h4>Client Registrations - Performed on <?php echo date('d-M-Y', strtotime($from_date)); ?></h4>
                                        <a class="btn btn-sm btn-success" href="add_client.php">Add New Client</a>
                                        <?php
                                        $totals = array();


                                        $qry2 = "SELECT
                                                tbl_warehouse.wh_id, 
                                                tbl_warehouse.wh_name, 
                                                tbl_warehouse.dist_id, 
                                                tbl_warehouse.ecr_start_month, 
                                                dist.LocName as dist_name
                                        FROM
                                                tbl_warehouse
                                                INNER JOIN
                                                tbl_locations AS dist
                                                ON 
                                                        tbl_warehouse.dist_id = dist.PkLocID
                                        WHERE
                                                tbl_warehouse.ecr_start_month IS NOT NULL
                                                and tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' ";

                                        if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
                                            $qry2 .= " and tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
                                        }
                                        if (!empty($district)) {
                                            $qry2 .= " and tbl_warehouse.dist_id = '" .$district . "' ";
                                        }
//                                        echo $qry2;exit;
                                        $res2 = mysql_query($qry2);
                                        $data_arr = $wh_arr = array();
                                        while ($row = mysql_fetch_assoc($res2)) {
                                            $wh_arr[$row['wh_id']] = $row;
                                            @$totals['total_wh']+=1;
                                        }


                                        $qry = 'SELECT
                                                            ecr_clients.*,
                                                            tbl_warehouse.wh_name
                                                    FROM
                                                            ecr_clients
                                                            INNER JOIN
                                                            tbl_warehouse
                                                            ON 
                                                            ecr_clients.registered_at = tbl_warehouse.wh_id
                                                    WHERE  DATE_FORMAT(created_on,\'%Y-%m-%d\') = "' . $from_date . '" 
                                                        and tbl_warehouse.stkid="'.$_SESSION['user_stakeholder1'].'" and prov_id ="'.$_SESSION['user_province1'].'" 
                                                         ';
                                         if($_SESSION['user_level'] > '2' && !empty($_SESSION['user_district'])){
                                             $qry .= ' and tbl_warehouse.dist_id = \''.$_SESSION['user_district'].'\' ';
                                         }

                                        if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
                                            $qry .= " and tbl_warehouse.wh_id = '".$_SESSION['user_warehouse']."' ";
                                        }
                                        if (!empty($district)) {
                                            $qry .= " and tbl_warehouse.dist_id = '" .$district . "' ";
                                        }
                                        
//                                            echo $qry;exit;
                                        $res = mysql_query($qry);
                                        while ($row = mysql_fetch_assoc($res)) {

                                            @$data_arr[$row['pk_id']] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr class="info">';
                                        echo ' 
                                                <th>#</th>
                                                <th>Registered At</th>
                                                <th>System Registration No.</th>
                                                <th>Clients Name</th>
                                                <th>Father/Husband</th>
                                                <th>CNIC</th>
                                                
                                                <th>Contact</th>
                                                <th>CRC</th>
                                                    <th>Catchment /<br/>Occupation /<br/>Education</th>
                                                <th>Age Today</th>
                                                
                                            ';
                                        echo '</tr>';
                                        foreach ($data_arr as $pk_id => $v) {
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $v['wh_name'] . '</td>';
                                            echo '<td>' . $v['serial_number'] . '</td>';
                                            echo '<td>' . $v['client_name'] . '</td>';
                                            echo '<td>' . $v['father_name'] . '</td>';
                                             echo '<td>';
                                                        
                                            if(!empty($v['cnic'] && $v['cnic'] != '00000-0000000-0')){
                                                echo $v['cnic'];
                                            }
                                            else{
                                                if(!empty($v['foreigner_identity'] && $v['foreigner_identity'] != '')){
                                                    echo $v['foreigner_identity'];
                                                }
                                            }
                                            echo'</td>';
                                            echo '<td>' . $v['contact_number'] . '</td>';
                                            echo '<td>' . ucfirst($v['crc_new_old']) . '</td>';
                                            echo '<td><b>Catchment:</b>' . ucfirst($v['catchment_area']) . '';
                                            echo '<br/><b>Occ:</b>' . ucfirst($v['occupation']) . '';
                                            echo '<br/><b>Occ:</b>' . ucfirst($v['education']) . '</td>';
                                            echo '<td>';
                                            echo '<a class="btn btn-xs btn-success" href="add_visit.php?client_id='.$v['pk_id'].'"><i class="fa fa-plus"></i> Add New Visit</a>';
                                            
                                                        echo '<br/><a class="btn btn-xs btn-info" href="view_client.php?client_id='.$v['pk_id'].'"><i class="fa fa-folder-open-o"></i>  View Clients Details</a>';
                                            if(!empty($v['registered_at']) && $v['registered_at']==$_SESSION['user_warehouse'])
                                            {
                                                echo '<br/><a class="btn btn-xs btn-warning" href="edit_client.php?client_id='.$v['pk_id'].'"><i class="fa fa-pencil"></i> Edit Client</a>';
                                            }
                                            echo '</td>';
                                            echo '</tr>';
                                        }

                                        echo '</table>';
                                        ?>
                                    </div>
                                </div>



                            </div>



                            <div class="widget-body">

                                <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                        <h4>Visits Recorded on <?php echo date('d-M-Y', strtotime($from_date)); ?></h4>
                                        <?php


                                        $qry = 'SELECT
                                                            ecr_client_visits.*,
                                                            ecr_clients.serial_number,
                                                            ecr_clients.client_name,
                                                            ecr_clients.father_name,
                                                            ecr_clients.contact_number,
                                                            ecr_clients.cnic,
                                                            tbl_warehouse.wh_name
                                                    FROM
                                                            ecr_client_visits
                                                    INNER JOIN tbl_warehouse ON ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                                    INNER JOIN ecr_clients ON ecr_clients.pk_id = ecr_client_visits.client_id
                                                    WHERE  DATE_FORMAT(date_of_visit,\'%Y-%m-%d\') = "' . $from_date . '" 
                                                        and tbl_warehouse.stkid="'.$_SESSION['user_stakeholder1'].'" and prov_id ="'.$_SESSION['user_province1'].'" 
                                                         ';

                                        if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
                                            $qry .= " and tbl_warehouse.wh_id = '".$_SESSION['user_warehouse']."' ";
                                        }
                                        if($_SESSION['user_level'] > '2' && !empty($_SESSION['user_district'])){
                                             $qry .= ' and tbl_warehouse.dist_id = \''.$_SESSION['user_district'].'\' ';
                                         }
                                        if (!empty($district)) {
                                            $qry .= " and tbl_warehouse.dist_id = '" .$district . "' ";
                                        }
                                        $qry .= " ORDER BY visit_purpose,client_name";
//                                            echo $qry;exit;
                                        $res = mysql_query($qry);
                                        while ($row = mysql_fetch_assoc($res)) {

                                            @$visits_arr[$row['pk_id']] = $row;
                                        }
                                        $c = 1;

                                        echo '<table class="table table-bordered table-condensed">';
                                        echo '<tr class="info">';
                                        echo ' 
                                                <th>#</th>
                                                <th>Facility</th>
                                                <th>Registration No.</th>
                                                <th>Clients Name</th>
                                                <th>Contact No.</th>
                                                <th>Purpose of Visit</th>
                                                <th>Visit Details</th>
                                                <th>Action</th>
                                               
                                                
                                            ';
                                        echo '</tr>';
                                        foreach ($visits_arr as $pk_id => $v) {
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td>' . $v['wh_name'] . '</td>';
                                            echo '<td>' . $v['serial_number'] . '</td>';
                                            echo '<td>' . $v['client_name'] . '</td>';
                                            echo '<td>' . $v['contact_number'] . '</td>';
                                            echo '<td>' . strtoupper(str_replace('_',' ',$v['visit_purpose'])) . '</td>';
//                                            if($v['visit_purpose']=='fp'){
//                                                echo '<td>' . ucfirst($v['fp_category']) . '</td>';
//                                            }elseif($v['visit_purpose']=='ghs'){
//                                                echo '<td>' . ucfirst($v['gen_health_category']) . '</td>';
//                                            }elseif($v['visit_purpose']=='larc_removal'){
//                                                echo '<td>Method:' . ucfirst($v['larc_method_name']) . '</td>';
//                                            }

                                            echo '<td>';
                                                echo '<span class="badge badge-warning">Purpose of Visit: '.strtoupper($v['visit_purpose']).'</span><br/><br/>';
                                                if($v['visit_purpose']=='fp'){

                                                    echo '<span class="bold">Category:</span><span class="">'.$v['fp_category'].'</span>';
                                                    echo '<br/><span class="bold">Method:</span><span class="">'.$v['fp_method_name'].' : '.$v['fp_qty'].'</span>';
                                                    if(!empty($v['additional_item']) && $v['additional_item'] == '1'){
                                                            echo '<br/><span class="bold">Additional RC:</span><span class="">'.$v['additional_item_qty'].'</span>';
                                                    }
                                                    echo '<br/><span class="bold">Ref by:</span><span class="">'.$v['fp_referred_from'].'('.$v['fp_referred_from_desig'].')</span>';
                                                    echo '<br/><span class="bold">Ref to:</span><span class="">'.$v['fp_referred_to'].'</span>';
                                                    echo '<br/><span class="bold">Ref for:</span><span class="">'.$v['fp_referred_for'].'</span>';
                                                    echo '<br/><span class="bold">Ref Reason:</span><span class="">'.$v['fp_reason_of_referral'].'</span>';

                                                }elseif($v['visit_purpose']=='ghs'){

                                                    echo '<br/><span class="bold">Category:</span>'.$v['gen_health_category'].'';
                                                    echo '<br/><span class="bold">Diagnosis:</span>'.ucfirst($v['gen_health_diagnosis']).'';
                                                    echo '<br/><span class="bold">Treatment:</span>'.ucfirst($v['gen_health_treatment']).'';
                                                    echo '<br/><span class="bold">Ref To:</span>'.$v['gen_health_referred_to'].'</span>';

                                                }elseif($v['visit_purpose']=='larc_removal'){

                                                    echo '<br/><span class="bold">Method:</span>'.$v['larc_method_name'].' ';
                                                    echo '<br/><span class="bold">Period:</span>'.$v['larc_period'].' ';
                                                    echo '<br/><span class="bold">Reason:</span>'.$v['larc_reason'].'</span>';

                                                }
                                            echo '</td>';
                                            
                                            echo '<td>';
                                                echo '<a class="btn btn-xs btn-success" href="view_visit.php?visit_id='.$v['pk_id'].'"><i class="fa fa-file"></i> View this Visit</a>';
                                                echo '<br/><a class="btn btn-xs btn-info" href="view_client.php?client_id='.$v['client_id'].'"><i class="fa fa-folder-open"></i> View all visits of this Client</a>';
                                            if(!empty($v['wh_id']) && $v['wh_id']==$_SESSION['user_warehouse'])
                                            {
                                                
                                                echo '<br/><a class="btn btn-xs btn-warning" href="edit_visit.php?visit_id='.$v['pk_id'].'"><i class="fa fa-pencil"></i> Edit Visit</a>';
                                                echo '<br/><a onclick="return confirm(\'Are you sure to Delete this Visit?\')" class="btn btn-xs btn-danger" href="del_visit_action.php?visit_id='.$v['pk_id'].'&client_id='.$v['client_id'].'"><i class="fa fa-times"></i> Del Visit</a>';

                                            }
                                            echo '</td>';
                                            
                                            echo '</tr>';
                                        }

                                        echo '</table>';
                                        ?>
                                        <hr/>
                                        Report Generated at : <?php echo date('d-M-Y H:i:s A'); ?>
                                        <hr/>
                                    </div>
                                </div>



                            </div>

                        </div>


                    </div>
                </div>

            </div>
        </div>

    </div>
    <!-- // Content END --> 

    <?php
    include PUBLIC_PATH . "/html/footer.php";
    ?>

<!--    <script>
        $(document).ready(function() {
    
    
        });
    </script>-->

</body>
</html>