<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
?>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    table.table thead .sorting_disabled, table.table thead .sorting {
        background: #2272b7 !important;
        color: #FFF !important;
    }
    
</style>
    <link rel="stylesheet" type="text/css" href="../../public/assets/global/plugins/select2/select2.css"/>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

                            <?php
                            if (!is_request_from_mobile()) {
                                ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading"> LARC Report  </h3>
                            </div>
                            <div class="widget-body">
                                    <br>
                                    <div class="panel panel-info" data-toggle="collapse-widget">
                                    <div class="panel-body">
                                    <div class="table-responsive" style="overflow: auto;">
                                        <img src="../../public/images/excel-16.png" <i id="btnExport"  table_id="table_1" class="my_custom_btn_xprt_xls fa fa-file-excel-o" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <img src="../../public/images/print-16.png" <i table_id="table_1" class="my_custom_print" style="font-size:32px;color:#FF0000;float: right;"></i>
                                        <?php
                                        $qry = "SELECT
                                                	sysuser_tab.usrlogin_id, 
                                                	sysuser_tab.sysusr_name,
                                                	tbl_locations.LocName AS dist_name, 
                                                	tbl_warehouse.wh_name, 
                                                	ecr_clients.client_name, 
                                                	ecr_clients.father_name, 
                                                	ecr_clients.address, 
                                                	ecr_clients.cnic, 
                                                	ecr_clients.contact_number, 
                                                	ecr_client_visits.date_of_visit, 
                                                	ecr_client_visits.visit_purpose, 
                                                	ecr_client_visits.fp_category, 
                                                	ecr_client_visits.fp_method_name, 
                                                	ecr_client_visits.fp_qty AS issuance_or_insertions
                                                FROM
                                                	ecr_clients
                                                	INNER JOIN
                                                	ecr_client_visits
                                                	ON 
                                                		ecr_clients.pk_id = ecr_client_visits.client_id
                                                	LEFT JOIN
                                                	tbl_warehouse
                                                	ON 
                                                		ecr_client_visits.wh_id = tbl_warehouse.wh_id
                                                	INNER JOIN
                                                	tbl_locations
                                                	ON 
                                                		tbl_warehouse.dist_id = tbl_locations.PkLocID
                                                	INNER JOIN
                                                	sysuser_tab
                                                	ON 
                                                		ecr_clients.user_id = sysuser_tab.UserID
                                                WHERE
                                                	tbl_warehouse.stkid = 3382 AND
                                                	fp_qty > 0
                                                ORDER BY
                                                	tbl_locations.LocName ASC, 
                                                	tbl_warehouse.wh_name ASC";
//                                        echo $qry;exit;
                                        $res = mysql_query($qry);

                                        echo '<table id="table_1" border="1" class="table table-bordered table-condensed">';
                                        ?>
                                        <thead>
                                        <tr>
                                            <td>Sr No</td>
                                            <td>User</td>
                                            <td>District</td>
                                            <td>Facility</td>
                                            <td>Client Name</td>
                                            <td>Father Name</td>
                                            <td>Address</td>
                                            <td>CNIC</td>
                                            <td>Date of Visit</td>
                                            <td>Visit Purpose</td>
                                            <td>FP Category</td>
                                            <td>FP Method</td>
                                            <td>Issuance/ Insertions</td>
                                        </tr>
                                        </thead>
                                        <?php
                                        echo '<tbody>';
                                        $a = 1;
                                        while ($row = mysql_fetch_assoc($res)) {
                                            echo '<tr>';
                                            echo '<td> '. $a++ .' </td>';
                                            echo '<td>' . $row['sysusr_name'] . '</td>';
                                            echo '<td>' . $row['dist_name'] . '</td>';
                                            echo '<td>' . $row['wh_name'] . '</td>';
                                            echo '<td>' . $row['client_name'] . '</td>';
                                            echo '<td>' . $row['father_name'] . '</td>';
                                            echo '<td>' . $row['address'] . '</td>';
                                            echo '<td>' . $row['cnic'] . '</td>';
                                            echo '<td>' . $row['date_of_visit'] . '</td>';
                                            echo '<td>' . $row['visit_purpose'] . '</td>';
                                            echo '<td>' . $row['fp_category'] . '</td>';
                                            echo '<td>' . $row['fp_method_name'] . '</td>';
                                            echo '<td>' . $row['issuance_or_insertions'] . '</td>';
                                            echo '</tr>';
                                        }
                                        echo '</tbody>';
                                        echo '</table>';
                                        ?>
                                    </div>
                                    </div>
                                </div>

<!--                                --><?php
//                                }
//                                ?>
                            
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
<?php
include PUBLIC_PATH . "/html/footer.php";
?>


    <script type="text/javascript" src="../../public/assets/global/plugins/select2/select2.min.js"></script>

</body>
</html>