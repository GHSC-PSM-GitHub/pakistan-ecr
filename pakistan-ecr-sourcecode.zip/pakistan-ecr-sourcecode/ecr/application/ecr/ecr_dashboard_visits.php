<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";


$from_date = date('2022-10-01');
$to_date = date('Y-m-d');

//$district = $_REQUEST['district'];

if (!empty($_REQUEST['from_date']))
    $from_date = $_REQUEST['from_date'];
if (!empty($_REQUEST['to_date']))
    $to_date = $_REQUEST['to_date'];
?>
<script src="plotly.min.js"></script>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
        <?php
        include PUBLIC_PATH . "html/top.php";
        include PUBLIC_PATH . "html/top_im.php";
        ?>

        <?php
        $totals = array();
        $begin = new DateTime($from_date);
        $end = new DateTime($to_date);
        $date_arr = array();
        for ($i = $begin; $i <= $end; $i->modify('+1 day')) {
            $this_date = $i->format("Y-m-d");
            $date_arr[$this_date] = $this_date;
        }
//                                                echo '<pre>';
//                                                print_r($date_arr);
//                                                echo '</pre>';
//                                                exit;


        $from_date = date('Y-m-d', strtotime($from_date));
        $to_date = date('Y-m-d', strtotime($to_date));


        $qry2 = "SELECT
                                                tbl_warehouse.wh_id, 
                                                tbl_warehouse.wh_name, 
                                                tbl_warehouse.dist_id, 
                                                tbl_warehouse.ecr_start_month, 
                                                dist.LocName as dist_name
                                        FROM
                                                tbl_warehouse
                                                INNER JOIN
                                                tbl_locations AS dist
                                                ON 
                                                        tbl_warehouse.dist_id = dist.PkLocID
                                        WHERE
                                                tbl_warehouse.ecr_start_month IS NOT NULL AND
                                                tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."'";
        if (!empty($district)) {
            $qry2 .= " and tbl_warehouse.dist_id = '" . $district . "' ";
        }
        if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
            $qry2 .= " and tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
        }
//                                        echo $qry2;exit;
        $res2 = mysql_query($qry2);
        $data_arr = $wh_arr = array();
        while ($row = mysql_fetch_assoc($res2)) {
            $wh_arr[$row['wh_id']] = $row;
            @$totals['total_wh']+=1;
        }

        if (!empty($district)) {
            $qry = 'SELECT
                                                    ecr_client_visits.date_of_visit,  
                                                    tbl_warehouse.dist_id, 
                                                    ecr_client_visits.wh_id,visit_purpose, 
                                                    count(ecr_client_visits.pk_id) as total_visits,
                                                    fp_method,
                                                    fp_method_name,
                                                    sum(fp_qty) as fp_qty
                                            FROM
                                                    ecr_client_visits
                                            INNER JOIN
                                            tbl_warehouse
                                            ON 
                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id

                                            WHERE   date_of_visit between "' . $from_date . '" and "' . $to_date . '"
                                                and tbl_warehouse.dist_id = "' . $district . '" ';

            if (!empty($_SESSION['user_level']) && $_SESSION['user_level'] == '7') {
                $qry .= " and tbl_warehouse.wh_id = '" . $_SESSION['user_warehouse'] . "' ";
            }
            $qry .= " and tbl_warehouse.stkid='".$_SESSION['user_stakeholder1']."' and prov_id ='".$_SESSION['user_province1']."' ";

            $qry .='
                                            group by 
                                                    ecr_client_visits.date_of_visit,  
                                                    tbl_warehouse.wh_id,visit_purpose,
                                                    fp_method
                                           order by ecr_client_visits.date_of_visit 
                                        ';
        } else {
            // district wise aggregate
            $qry = 'SELECT
                                                    ecr_client_visits.date_of_visit, 
                                                    tbl_warehouse.dist_id,
                                                    tbl_warehouse.wh_name,
                                                    ecr_client_visits.wh_id,
                                                    visit_purpose, 
                                                    count(ecr_client_visits.pk_id) as total_visits,
                                                    fp_method,
                                                    fp_method_name,
                                                    sum(fp_qty) as fp_qty
                                            FROM
                                                    ecr_client_visits
                                            INNER JOIN
                                            tbl_warehouse
                                            ON 
                                                    ecr_client_visits.wh_id = tbl_warehouse.wh_id

                                            WHERE  date_of_visit between "' . $from_date . '" and "' . $to_date . '" and tbl_warehouse.stkid="'.$_SESSION['user_stakeholder1'].'" and prov_id ="'.$_SESSION['user_province1'].'"
                                            group by 
                                                    ecr_client_visits.date_of_visit,  
                                                    tbl_warehouse.wh_id,visit_purpose,
                                                    fp_method
                                           order by ecr_client_visits.date_of_visit 
                                        ';
        }
//                                        echo $qry;exit;
        $res = mysql_query($qry);
        $data_visits = array();
        $itm_arr = array();
        while ($row = mysql_fetch_assoc($res)) {
            $itm_arr[$row['fp_method']] = $row['fp_method_name'];
            $row['wh_name'] = str_replace('RHS-A', 'RHSA', $row['wh_name']);
            $row['wh_name'] = str_replace('Center', '', $row['wh_name']);
            $row['wh_name'] = str_replace('Centre', '', $row['wh_name']);
            $row['wh_name'] = str_replace('Hospital', ' Hosp', $row['wh_name']);
            $row['wh_name'] = str_replace('Sindh Govt', '', $row['wh_name']);
            $row['wh_name'] = str_replace('Dow Hosp', '', $row['wh_name']);

            @$data_visits[$row['wh_id']][$row['date_of_visit']] += $row['total_visits'];

            @$totals['dist_wise'][$row['dist_id']][$row['visit_purpose']] += $row['total_visits'];

            @$loop_ids[$row['wh_id']] = $row['wh_name'];
            @$totals['loop_wise'][$row['wh_id']][$row['visit_purpose']] += $row['total_visits'];
            @$totals['loop_wise2'][$row['wh_id']][$row['visit_purpose']][$row['fp_method_name']] += $row['fp_qty'];

            @$dist_ids[$row['dist_id']] = $row['dist_id'];
            @$totals['purpose_wise'][$row['visit_purpose']][$row['date_of_visit']] += $row['total_visits'];

            @$totals['visits'][$row['date_of_visit']] +=$row['total_visits'];
            @$totals['date_wise_item_issuance'][$row['date_of_visit']][$row['fp_method_name']] +=$row['fp_qty'];

            @$totals['visits'][$row['wh_id']] +=$row['total_visits'];
            @$totals['visits']['all'] +=$row['total_visits'];
            @$totals['total_purpose'][$row['visit_purpose']] += $row['total_visits'];
        }
        //// removing unwanted items from list                                
        unset($itm_arr['']);
        unset($itm_arr['0']);
        unset($itm_arr['31']);
        unset($itm_arr['32']);
//        echo '<pre>';
//        print_r($itm_arr);
////        print_r($dist_ids);
////        print_r($totals['dist_wise']);
//        echo '</pre>';    
//        exit;
        ?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="font-blue-madison" style="border-bottom: 3px solid #5dcf85;text-align: center"> Trend Line Dashboard ( ECR )</h2>
                         <div class="widgetx" data-toggle="collapse-widgetx">

                            <div class="widget-bodyx">

                                <div class="row">
                                    <div class="col-md-12"> 
                                        <h3 style="border-bottom: 3px solid #5dcf85;text-align: center">Daily Visits Trend</h3>

                                        <div class="col-md-12" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                            <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                <div class="portlet-title">
                                                    <div class="caption"><i class="fa fa-cogs"></i>Total Visits Recorded - Trend Line
                                                    </div>
                                                    <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div id="canvas-holder" style="width:100%">                   
                                                        <div id="visit_trend" style="width:;height:300px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                            <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                <div class="portlet-title">
                                                    <div class="caption"><i class="fa fa-cogs"></i>Purpose Wise Visits  - Trend Line
                                                    </div>
                                                    <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div id="canvas-holder" style="width:100%">                   
                                                        <div id="visit_trend_breakdown" style="width:;height:300px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>    

                                        <h3 style="border-bottom: 3px solid #5dcf85;text-align: center">FP Issuance Daily Trend</h3>

                                        <div class="col-md-12" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                            <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                <div class="portlet-title">
                                                    <div class="caption"><i class="fa fa-cogs"></i>Daily Issuance Trend  - Item Wise Trend
                                                    </div>
                                                    <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div id="canvas-holder" style="width:100%">                   
                                                        <div id="cons_trend" style="width:;height:350px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                        
<!--                                        <h3 style="border-bottom: 3px solid #5dcf85;text-align: center">Facility Wise breakdown - Visits & Issuance</h3>
                                        
                                        <div class="col-md-12" style="margin-left:0px;margin-right: 0px;" id="graph_row_1">
                                            <div class="portlet box blue-steel" data-toggle="collapse-widget">
                                                <div class="portlet-title">
                                                    <div class="caption"><i class="fa fa-cogs"></i>Purpose Wise Visits - Facility Wise Visits & FP Issuance
                                                    </div>
                                                    <div class="tools"><a href="javascript:;" class="collapse" data-original-title="" title=""></a>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div id="canvas-holder" style="width:100%">                   
                                                         <div id="myDiv" style="width:700px;height:750px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        -->
                                        
                                    </div>             
                                </div>             



                               
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    
    include PUBLIC_PATH . "/html/footer.php";
    
    
    $visit_trend_x = '';
    $visit_trend_y = '';
    foreach ($date_arr as $k => $v) {
        $visit_trend_x .= '"' . date('Y-M-d', strtotime($v)) . '",';
        $visit_trend_y .= (!empty($totals['visits'][$v]) ? $totals['visits'][$v] : '0') . ',';

        //$totals['date_wise_item_issuance'][$row['date_of_visit']][$row['fp_method_name']]
        @$issuance_trend_x .= '"' . date('Y-M-d', strtotime($v)) . '",';

        foreach ($itm_arr as $itm_id => $itm_name) {

            @$issuance_trend_y[$itm_id] .= (!empty($totals['date_wise_item_issuance'][$v][$itm_name]) ? $totals['date_wise_item_issuance'][$v][$itm_name] : '0') . ',';
        }


        @$visit_fp_x .= '"' . date('Y-M-d', strtotime($v)) . '",';
        @$visit_fp_y .= (!empty($totals['purpose_wise']['fp'][$v]) ? $totals['purpose_wise']['fp'][$v] : '0') . ',';
        @$visit_gh_x .= '"' . date('Y-M-d', strtotime($v)) . '",';
        @$visit_gh_y .= (!empty($totals['purpose_wise']['ghs'][$v]) ? $totals['purpose_wise']['ghs'][$v] : '0') . ',';
        @$visit_la_x .= '"' . date('Y-M-d', strtotime($v)) . '",';
        @$visit_la_y .= (!empty($totals['purpose_wise']['larc_removal'][$v]) ? $totals['purpose_wise']['larc_removal'][$v] : '0') . ',';
    }

//    echo '<pre>';
//    print_r($totals['date_wise_item_issuance']);
//    print_r($issuance_trend_y);
//    echo '</pre>';
//    exit;

    ?>
    <script>
        visit_trend = document.getElementById('visit_trend');
        Plotly.newPlot( visit_trend, [{
                x: [<?php echo $visit_trend_x; ?>],
                y: [<?php echo $visit_trend_y; ?>] }], {
            margin: { t: 10 } } );
    </script>
    <script>
        visit_trend = document.getElementById('visit_trend_breakdown');
        var trace1 = {
            x: [<?php echo $visit_fp_x; ?>],
            y: [<?php echo $visit_fp_y; ?>],
            type: 'scatter',
            name:'Family Planning'
        };

        var trace2 = {
            x: [<?php echo $visit_gh_x; ?>],
            y: [<?php echo $visit_gh_y; ?>],
            type: 'scatter',
            name:'General Health Services'
        };
        
        var trace3 = {
            x: [<?php echo $visit_la_x; ?>],
            y: [<?php echo $visit_la_y; ?>],
            type: 'scatter',
            name:'LARC Removals'
        };

        var layout = {
            showlegend: true,margin: { t: 15,r:0 }
        }
        var data = [trace1, trace2, trace3];
        Plotly.newPlot( visit_trend, data , layout, {displaylogo: false});
        ///displayModeBar: true,
    </script>


    <!--    consumption trend line graph start here-->

    <script>
        cons_trend = document.getElementById('cons_trend');
        
<?php 
//    foreach ($date_arr as $k => $v) {
        $cons_trend_string = '';
        foreach ($itm_arr as $itm_id => $itm_name) {

            $cons_trend_string .= 'trace' . $itm_id . ',';
//            @$issuance_trend_y[$itm_id];

            echo '';
            echo 'var trace' . $itm_id . ' = {';
            echo 'x: [' . $issuance_trend_x . '],';
            echo 'y: [' . $issuance_trend_y[$itm_id] . '],';
            echo 'type: \'scatter\',';
            echo 'name:\'' . $itm_name . '\'';
            echo '};';
        }
//    }
?>
        


            var layout = {
                showlegend: true,margin: { t: 15,r:0 }
            }
            var data = [<?php echo $cons_trend_string; ?>];
            Plotly.newPlot( cons_trend, data , layout, {displaylogo: false});
            ///displayModeBar: true,
    </script>

    <script>

        var data = [{
                type: "sunburst",
                ids: ["visits",    "fp",        "ghs",      "larc_removal",         <?php
//foreach ($loop_ids as $id => $name) {
//    echo '"' . $id . '_fp",';
//    echo '"' . $id . '_ghs",';
//    echo '"' . $id . '_larc_removal",';
//
//    if (!empty($totals['loop_wise2'][$id]['fp']))
//        foreach ($totals['loop_wise2'][$id]['fp'] as $itm_id => $itm_qty) {
//            echo '"' . $id . '_' . $itm_id . '_fp",';
//            echo '"' . $id . '_' . $itm_id . '_ghs",';
//            echo '"' . $id . '_' . $itm_id . '_larc_removal",';
//        }
//}
?> ],
                                labels: ["Total Visits", "Family Planning Services",        "GHS",      "LARC Removal",        <?php
//foreach ($loop_ids as $id => $name) {
//    echo '"' . $name . '",';
//    echo '"' . $name . '",';
//    echo '"' . $name . '",';
//    if (!empty($totals['loop_wise2'][$id]['fp']))
//        foreach ($totals['loop_wise2'][$id]['fp'] as $itm_id => $itm_qty) {
//            echo '"' . $itm_id . ': ' . $itm_qty . ' ",';
//            echo ',';
//            echo ',';
//        }
//}
?> ],
                                    parents: ["",       "visits",   "visits",   "visits",              <?php
foreach ($loop_ids as $id => $name) {
    echo '"fp",';
    echo '"ghs",';
    echo '"larc_removal",';
    if (!empty($totals['loop_wise2'][$id]['fp']))
        foreach ($totals['loop_wise2'][$id]['fp'] as $itm_id => $itm_qty) {
            echo '"' . $id . '_fp",';
            echo '"' . $id . '_ghs",';
            echo '"' . $id . '_larc_removal",';
        }
}
?> ],
                                        //                values:  [40, 14, 12, 10, 2, 6, 9, 3, 4],
                                        values:  [<?php
echo '' . $totals['visits']['all'] . ',';
echo $totals['total_purpose']['fp'] . ',';
echo $totals['total_purpose']['ghs'] . ',';
echo $totals['total_purpose']['larc_removal'] . ',';
foreach ($loop_ids as $id => $name) {
    echo (!empty($totals['loop_wise'][$id]['fp']) ? $totals['loop_wise'][$id]['fp'] : '0') . ',';
    echo (!empty($totals['loop_wise'][$id]['ghs']) ? $totals['loop_wise'][$id]['ghs'] : '0') . ',';
    echo (!empty($totals['loop_wise'][$id]['larc_removal']) ? $totals['loop_wise'][$id]['larc_removal'] : '0') . ',';

    if (!empty($totals['loop_wise2'][$id]['fp']))
        foreach ($totals['loop_wise2'][$id]['fp'] as $itm_id => $itm_qty) {
            echo (!empty($itm_qty) ? $itm_qty : '0') . ',';
            echo '0,';
            echo '0,';
        }
}
?>],
                                                        outsidetextfont: {size: 20, color: "#377eb8"},
                                                        leaf: {opacity: 0.5},
                                                        marker: {line: {width: 3}},
                                                        //                branchvalues: "total"
                                                    }];

                                                var layout = {
                                                    margin: {l: 0, r: 0, b: 0, t: 0},
                                                    width: 700,
                                                    height: 700,
                                                    extendsunburstcolorway: true
                                                };


//                                                Plotly.newPlot('myDiv', data, layout);
    </script>
</body>
</html>