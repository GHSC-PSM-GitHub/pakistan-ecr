<?php
// header("Cache-Control: no cache");
//  session_cache_limiter("private_no_expire");
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";
$sr = '';

if (!empty($_REQUEST['search_query'])) {
    $sr = htmlspecialchars($_REQUEST['search_query']);

    /// handling incomplete cnic, with and without dashes cnic
    $temp_cnic = explode('-', $sr);
    @$comb_cnic = $temp_cnic[0] . $temp_cnic[1] . $temp_cnic[2];
    $formatted_cnic = substr($comb_cnic, 0, 5) . '-' . substr($comb_cnic, 5, 7) . '-' . substr($comb_cnic, 12, 1);
    $formatted_cnic = rtrim($formatted_cnic, '-');

    ///handling client name and father name combination, 
    $temp_sr = explode(' ', $sr);
    @$possible_cname = $temp_sr[0];
    @$possible_fname = $temp_sr[1];
}

$qry = "SELECT
                list_detail.pk_id,
                list_detail.list_value,
                list_detail.description,
                list_detail.rank,
                list_detail.reference_id,
                list_detail.parent_id,
                list_detail.list_master_id
            FROM
                list_detail
            ORDER BY
                list_detail.rank ,
                list_detail.list_value ASC
        ";
$qryRes = mysql_query($qry);
$list_arr = array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $list_arr[$row['list_master_id']][$row['pk_id']]['name'] = $row['list_value'];
    $list_arr[$row['list_master_id']][$row['pk_id']]['description'] = $row['description'];
}

$client_arr = array();
$msg = '';
$c_count = 0;


if (!empty($_REQUEST['search_query'])) {



    $qry = "SELECT * ,
            (SELECT count(*) from ecr_client_visits where ecr_client_visits.client_id =ecr_clients.pk_id ) as visits
            FROM
                    ecr_clients
                WHERE 
                    (
                        serial_number like '%" . $sr . "%' OR 
                        client_name like '%" . $sr . "%' OR 
                        father_name like '%" . $sr . "%' OR 
                        ( client_name like '%" . $possible_cname . "%' AND father_name like '%" . $possible_fname . "%' )
                        OR 
                        cnic like '%" . $sr . "%' OR 
                        cnic like '%" . $formatted_cnic . "%' OR 
                        foreigner_identity like '%" . $sr . "%' OR 
                        contact_number like '%" . $sr . "%' OR 
                        crc_number like '%" . $sr . "%'
                    ) AND status <> '0'
                ORDER BY 
         CASE `registered_at`
         WHEN '" . $_SESSION['user_warehouse'] . "' THEN 1
         ELSE 2
         END
                limit 60
            ";
//         echo $qry;exit;
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $c_count++;
        $client_arr[$row['pk_id']] = $row;
    }

    if ($c_count == 0)
        $msg = 'No Matching Record Found . !';
}
else {
//        $msg = 'Showing Last 5 Registered Clients at Your Facility. ';
//         $qry = "SELECT * ,
//            (SELECT count(*) from ecr_client_visits where ecr_client_visits.client_id =ecr_clients.pk_id ) as visits
//            FROM
//                    ecr_clients
//             where registered_at = '".$_SESSION['user_warehouse']."'
//            order by pk_id desc
//            limit 5
//            ";
////         echo $qry;
//        $qryRes = mysql_query($qry);
//        while($row = mysql_fetch_assoc($qryRes))
//        {
//            $c_count++;
//            $client_arr[$row['pk_id']]=$row;
//        }

    if ($c_count == 0)
        $msg = 'Please enter any keyword to search . !';
}

?>
</head>
<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
<?php
include PUBLIC_PATH . "html/top.php";
include PUBLIC_PATH . "html/top_im.php";
?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-blue-chambray">ELECTRONIC CLIENT RECORDS

<?php
if (!is_request_from_mobile()) {
    ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>


                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Search Information - Clients / Visits </h3>
                            </div>
                            <div class="widget-body">
                                <form method="POST" name="add_client" id="add_client" action="search_clients.php" >
                                    <div class="row">
                                        <div class="col-md-12">
<?php
if (!empty($_REQUEST['show_msg']) && !empty($msg_array[$_REQUEST['show_msg']]['txt'])) {
    if (!empty($msg_array[$_REQUEST['show_msg']]['cls'])) {
        $cls = $msg_array[$_REQUEST['show_msg']]['cls'];
    } else {
        $cls = 'success';
    }
    echo '<div class="col-md-12 col-lg-12">
                                                                <div class="note note-' . $cls . '" >' . $msg_array[$_REQUEST['show_msg']]['txt'] . '<i class="fa fa-check font-green"></i></div>  
                                                        </div>';
}
?>

                                            <div class="col-md-6">
                                                <div class="control-group">
                                                    <label class="control-label" for="textinput"></label>  
                                                    <div class="controls">
                                                        <input id="search_query" autofocus index="0" placeholder="Search by : Registration No. / Name / CNIC / Contact No / CRC " name="search_query" type="text" value="<?php echo $sr; ?>" class="form-control input-md"> 
                                                    </div>
                                                </div>
                                            </div>



                                            <div class="col-md-4">
                                                <div class="control-group">
                                                    <label class="control-label" for="button1id">&nbsp;</label>
                                                    <div class="controls">
                                                        <button id="button1id" index="2" name="button1id" class="btn btn-success"><i class="fa fa-search"></i> Search</button>
                                                        <a class="btn btn-warning pull-right" href="add_client.php"><i class="fa fa-plus"></i> Add New Client</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </form>




                                <div class="row">
                                    <div class="col-md-12 table-responsive">
<?php
echo $msg;



if (is_request_from_mobile()) {
    ////// table for mobile version
    ?>
                                            <table class="table table-bordered table-condensed table-hover">
                                                <tr class="bg-success">
                                                    <th>Client Info.</th>
    <!--                                                    <th>Father/Husband</th>-->
                                                    <th>CNIC / Contact</th>

                                                    <th>Action</th>
                                                </tr>
    <?php
    foreach ($client_arr as $k => $v) {

        $cls = '';
        if (!empty($v['registered_at']) && $v['registered_at'] == $_SESSION['user_warehouse']) {
            $cls = 'bg-success';
        }

        echo '<tr class="' . $cls . '">';
        echo '<td> <b>Sr No:</b>' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['serial_number']) . ' ';
        echo '<br/><br/><b>' . ucfirst($v['crc_new_old']) . (!empty($v['crc_new_old']) ? '</b>:' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['crc_number']) : '') . '';
        echo '<br/> <b>Name:</b> ' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['client_name']) . '';
        echo '<br/> <b>d/o w/o:</b>' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['father_name']) . '</td>';
        echo '<td> <b>CNIC:</b>' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['cnic']) . '';
        echo '<br/> <b>Phone:</b> ' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['contact_number']) . '';
        echo '<br/> <b>Visits:</b> ' . ($v['visits']) . '';
        echo '</td>';
        echo '<td>';
        if($_SESSION['user_level']== 3 || $_SESSION['user_level']== 7 ){
            echo '<a class="btn btn-xs btn-success" href="add_visit.php?client_id=' . $v['pk_id'] . '"><i class="fa fa-sign-in"></i> Add Visit </a>';
        }
        echo '<br/><a class="btn btn-xs btn-info" href="view_client.php?client_id=' . $v['pk_id'] . '"><i class="fa fa-folder-open-o"></i>  View  Details</a>';
        if (!empty($v['registered_at']) && $v['registered_at'] == $_SESSION['user_warehouse']) {
            echo '<br/><a class="btn btn-xs btn-danger" href="edit_client.php?client_id=' . $v['pk_id'] . '"><i class="fa fa-pencil"></i> Edit Client</a>';
        }

        echo '</td>';
        echo '</tr>';
    }
    ?>
                                            </table>

                                                <?php
                                            } else {
                                                ////// table for desktop version
                                                ?>
                                            <table class="table table-bordered table-condensed table-hover">
                                                <tr class="bg-info">
                                                    <th>Computerized Registration No.</th>
                                                    <th>Clients Name</th>
                                                    <th>Father/Husband</th>
                                                    <th>CNIC / Foreign ID</th>
                                                    <th>Contact</th>
                                                    <th>CRC</th>

                                                    <th>Catchment /<br/>Occupation /<br/>Education</th>

                                                    <th>Age Today</th>
    <!--                                                    <th>Years of Marriage</th>-->
                                                    <th>Visits / History</th>
                                                    <th>Action</th>
                                                </tr>
    <?php
    foreach ($client_arr as $k => $v) {
        $cls = '';
        if (!empty($v['registered_at']) && $v['registered_at'] == $_SESSION['user_warehouse']) {
            $cls = 'bg-success';
        }
        echo '<tr class="' . $cls . '">';
        echo '<td>' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['serial_number']) . '</td>';
        echo '<td>' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['client_name']);
        if(!empty($v['status']) && $v['status'] == '2'){
            echo '<a class=" pull-right">( <i class="fa fa-flag font-red"></i> Marked Duplicate ) </a>';
        }
        echo '</td>';
        echo '<td>' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['father_name']) . '</td>';
        echo '<td>';

        if (!isset($v['nationality']) || $v['nationality'] != 'other') {
            echo preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['cnic']);
        } else {
            echo preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['foreigner_identity']);
        }
        echo'</td>';
        echo '<td>' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['contact_number']) . '</td>';
        echo '<td><b>' . ucfirst($v['crc_new_old']) . (!empty($v['crc_new_old']) ? '</b>:' . preg_replace("/" . $sr . "/i", '<b style="background:yellow">$0</b>', $v['crc_number']) : '') . '</td>';

        echo '<td><b>Catchment:</b>' . ucfirst($v['catchment_area']) . '';
        echo '<br/><b>Occ:</b>' . ucfirst($v['occupation']) . '';
        echo '<br/><b>Edu:</b>' . ucfirst($v['education']) . '</td>';

        echo '<td>' . $v['age_today'] . '</td>';
//                                                        echo '<td>'.$v['age_when_married'].'</td>';
        echo '<td>' . ($v['visits']);
        if(!empty($v['visits'])){
            echo '<a class="client_history pull-right" data-client-id="' . $v['pk_id'] . '" data-serial="'.$v['serial_number'].'" data-client-name="'.$v['client_name'].'"><i class="fa fa-history font-blue"></i></a>';
        }
        echo '</td>';
        echo '<td>';
        if($_SESSION['user_level']== 3 || $_SESSION['user_level']== 7 ){
            echo '<a class="btn btn-sm btn-circle green-meadow" href="add_visit.php?client_id=' . $v['pk_id'] . '"><i class="fa fa-sign-in"></i> Add Visit</a>';
        }
        echo '<a class="btn  btn-sm btn-circle default green-stripe" href="view_client.php?client_id=' . $v['pk_id'] . '"><i class="fa fa-folder-open-o font-blue"></i>  View Details</a>';
        if (!empty($v['registered_at']) && $v['registered_at'] == $_SESSION['user_warehouse']) {
            echo '<br/><a class="btn btn-xs btn-circle purple-plum" href="edit_client.php?client_id=' . $v['pk_id'] . '"><i class="fa fa-pencil"></i> Edit Client Info</a>';
            echo '<br/><a onclick="return confirm(\'Are you sure to mark this client as duplicate?\')" class="btn btn-xs btn-circle default red-sunglo" href="flag_client.php?client_id=' . $v['pk_id'] . '"><i class="fa fa-flag"></i> Mark as Duplicate</a>';
        }
        echo '</td>';
        echo '</tr>';
    }
    ?>
                                            </table>

                                                <?php
                                            }
                                            ?>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

                <span class="note note-info">NOTE: You may search data, by entering any of these : Computerized Registration Number, Client Name, Husband / Father Name, CNIC, Contact Number, CRC: </span>
            </div>
        </div>
        <!-- // Content END --> 

    </div>
                                        <?php
                                        include PUBLIC_PATH . "/html/footer.php";
                                        ?>

    <div class="modal  bs-modal-lg fade" id="ecr_details_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                    <h4 class="modal-title" id="ecr_details_modal_title">title</h4>
                </div>
                <div class="modal-body" id="ecr_details_modal_body">
                    Body
                </div>
                <div class="modal-footer">
<!--                    <button type="button" class="btn blue"></button>-->
                    <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>


</body>
</html>

<link rel="stylesheet" type="text/css" href="../../public/assets/admin/pages/css/timeline.css"/>
<script>
    
$('.client_history').click(function(){
    $('#ecr_details_modal').modal('show');
    $('#ecr_details_modal_title').html('').html('Client History');
    $('#ecr_details_modal_body').html('').html('Loading ...');
    
    var $this_id = $(this).data('client-id');
    var this_ser = $(this).data('serial');
    var this_name = $(this).data('client-name');
    
    $('#ecr_details_modal_title').html('').html('Client History of '+this_name + ' ('+this_ser+')');
    $('#ecr_details_modal_body').html('').html('ID:'+$this_id);
    
    
    $.ajax({
            url: "ajax_client_history.php?client_id="+$this_id,
            cache: false,
            success: function(html){
                $("#ecr_details_modal_body").html(html);
            }
        });
    
});

</script>