<?php
include("../includes/classes/AllClasses.php");
include(PUBLIC_PATH . "html/header.php");
include "../includes/styling/dynamic_theme_color.php";
include "ecr_common.php";

$id = '';

if (!empty($_REQUEST['ids'])) {
    $id = htmlspecialchars($_REQUEST['ids']);
    $id = trim($id, ",");
    $temp_ids = str_replace(",", "','", $id);
    $ids = "'" . $temp_ids . "'";
}


$qry = "SELECT
                list_detail.pk_id,
                list_detail.list_value,
                list_detail.description,
                list_detail.rank,
                list_detail.reference_id,
                list_detail.parent_id,
                list_detail.list_master_id
            FROM
                list_detail
            ORDER BY
                list_detail.rank ,
                list_detail.list_value ASC
        ";
$qryRes = mysql_query($qry);
$list_arr = array();
while ($row = mysql_fetch_assoc($qryRes)) {
    $list_arr[$row['list_master_id']][$row['pk_id']]['name'] = $row['list_value'];
    $list_arr[$row['list_master_id']][$row['pk_id']]['description'] = $row['description'];
}

$client_arr = $visit_arr = array();

if (!empty($ids)) {

    $qry = "SELECT
	ecr_client_visits.*, 
	ecr_clients.client_name, 
	ecr_clients.father_name
FROM
	ecr_client_visits
	INNER JOIN
	ecr_clients
	ON 
		ecr_client_visits.client_id = ecr_clients.pk_id
                WHERE 
                    ecr_client_visits.pk_id in (" . $ids . ")
                        ORDER BY  client_id , date_of_visit,visit_purpose,fp_method_name
            ";
    $qryRes = mysql_query($qry);
    while ($row = mysql_fetch_assoc($qryRes)) {
        $visit_arr[] = $row;
    }



    $cols_arr = array();
    $cols_arr['info']['client_name'] = 'client_name';
    $cols_arr['info']['father_name'] = 'father_name';
    $cols_arr['info']['date_of_visit'] = 'date_of_visit';
    $cols_arr['info']['wh_name'] = 'Facility Visited';
    $cols_arr['info']['visit_purpose'] = 'visit_purpose';

    $cols_arr['last_procedure']['parity_alive'] = 'parity_alive';
    $cols_arr['last_procedure']['parity_death'] = 'parity_death';
    $cols_arr['last_procedure']['outcome_last_preg'] = 'outcome_last_preg';
    $cols_arr['last_procedure']['period_from_last_preg'] = 'period_from_last_preg';

    $cols_arr['activity']['activity_under'] = 'activity_under';
    $cols_arr['activity']['activity_uc'] = 'activity_uc';
    $cols_arr['activity']['activity_num'] = 'activity_num';

    $cols_arr['fp']['fp_method_name'] = 'fp_method_name';
    $cols_arr['fp']['fp_qty'] = 'fp_qty';
    $cols_arr['fp']['additional_item'] = 'additional_item';
    $cols_arr['fp']['additional_item_qty'] = 'additional_item_qty';
    $cols_arr['fp']['fp_referred_from'] = 'fp_referred_from';
    $cols_arr['fp']['fp_referred_from_desig'] = 'fp_referred_from_desig';
    $cols_arr['fp']['fp_counseling'] = 'fp_counseling';
    $cols_arr['fp']['fp_referred_to'] = 'fp_referred_to';
    $cols_arr['fp']['fp_category'] = 'fp_category';
    $cols_arr['fp']['fp_referred_for'] = 'fp_referred_for';
    $cols_arr['fp']['fp_reason_of_referral'] = 'fp_reason_of_referral';

    $cols_arr['larc_removal']['larc_method_name'] = 'larc_method_name';
    $cols_arr['larc_removal']['larc_period'] = 'larc_period';
    $cols_arr['larc_removal']['larc_reason'] = 'larc_reason';

//    $cols_arr['ghs']['gen_health_patient_type'] = 'gen_health_patient_type'; 
    $cols_arr['ghs']['gen_health_category'] = 'gen_health_category';
    $cols_arr['ghs']['gen_health_diagnosis'] = 'gen_health_diagnosis';
    $cols_arr['ghs']['gen_health_treatment'] = 'gen_health_treatment';
    $cols_arr['ghs']['gen_health_referred_to'] = 'gen_health_referred_to';
}
?>
</head>

<body class="page-header-fixed page-quick-sidebar-over-content">
    <div class="page-container">
<?php
include PUBLIC_PATH . "html/top.php";
include PUBLIC_PATH . "html/top_im.php";
?>
        <div class="page-content-wrapper">
            <div class="page-content"> 
                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="font-green">ELECTRONIC CLIENT RECORDS

<?php
if (!is_request_from_mobile()) {
    ?>
                                <a class="btn btn-info pull-right"  download href="../../public/docs/fp_client_register.xlsx"><i class="fa fa-download"></i> Download FP Client Register</a>
                                <?php
                            }
                            ?>
                        </h3>

                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Visits Details</h3>
                            </div>
                            <div class="widget-body">
                                <div class="table-responsive">
                                    <table class="table table-condensed table-bordered table-hover"  style="table-layout: scroll" >
                                        <thead>
                                            <tr class="bg-success">
                                                <th  >#</th>
<?php
foreach ($cols_arr as $sec => $s_obj) {

    echo '<td align="center" colspan="' . count($s_obj) . '">' . $sec . '</td>';
}
?>
                                            </tr>
                                            <tr class="bg-success">
                                                <th  >#</th>
                                                <?php
                                                foreach ($cols_arr as $sec => $s_obj) {
                                                    foreach ($s_obj as $col_id => $col_name) {
                                                        echo '<td>' . $col_name . '</td>';
                                                    }
                                                }
                                                ?>
                                            </tr>

                                        </thead>
                                        <tbody>

                                                <?php
                                                $c = 1;
                                                foreach ($visit_arr as $k => $v) {
                                                    echo '<tr>';
                                                    echo '<td>' . $c++ . '</td>';
                                                    foreach ($cols_arr as $sec => $s_obj) {

                                                        $cls = '';
                                                        if ($v['visit_purpose'] == $sec)
                                                            $cls = 'bg-info';
                                                        foreach ($s_obj as $col_id => $col_name) {
                                                            echo '<td class="' . $cls . '">' . $v[$col_id] . '</td>';
                                                        }
                                                    }

                                                    echo '<td>';

                                                    echo '</tr>';
                                                }
                                                ?>
                                        </tbody>
                                    </table>



                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- // Content END --> 

    </div>
<?php
include PUBLIC_PATH . "/html/footer.php";
?>

</body>
</html>