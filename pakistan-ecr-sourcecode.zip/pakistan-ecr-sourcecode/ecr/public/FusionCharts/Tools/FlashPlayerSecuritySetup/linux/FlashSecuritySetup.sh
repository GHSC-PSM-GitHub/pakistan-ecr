mkdir -p ~/.macromedia/Flash_Player/#Security/FlashPlayerTrust/
echo `pwd` >> ~/.macromedia/Flash_Player/#Security/FlashPlayerTrust/FusionCharts.cfg

