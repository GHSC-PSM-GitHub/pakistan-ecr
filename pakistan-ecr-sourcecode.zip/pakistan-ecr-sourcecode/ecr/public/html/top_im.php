<link href="<?php echo PUBLIC_URL;?>common/theme/css/glyphicons.css" rel="stylesheet" />
<!-- Uniform Pretty Checkboxes -->
<link href="<?php echo PUBLIC_URL;?>common/theme/scripts/plugins/forms/pixelmatrix-uniform/css/uniform.default.css" rel="stylesheet" />
<!-- PrettyPhoto -->
<link href="<?php echo PUBLIC_URL;?>common/theme/scripts/plugins/gallery/prettyphoto/css/prettyPhoto.css" rel="stylesheet" />
<!-- DateTimePicker Plugin -->
<link href="<?php echo PUBLIC_URL;?>common/theme/scripts/plugins/forms/bootstrap-datetimepicker/css/datetimepicker.css" rel="stylesheet" />
	<!-- JQueryUI -->
<link href="<?php echo PUBLIC_URL;?>common/theme/scripts/plugins/system/jquery-ui/css/smoothness/jquery-ui-1.9.2.custom.min.css" rel="stylesheet" />

<link href="<?php echo PUBLIC_URL;?>common/theme/scripts/plugins/tables/DataTables/extras/TableTools/media/css/TableTools.css" rel="stylesheet" />
<link href="<?php echo PUBLIC_URL;?>common/theme/scripts/plugins/tables/DataTables/extras/TableTools/media/css/TableTools_JUI.css" rel="stylesheet" />

<!-- Main Theme Stylesheet :: CSS -->
<link href="<?php echo PUBLIC_URL;?>css/TableTools.css" rel="stylesheet" />
<link href="<?php echo PUBLIC_URL;?>css/TableTools_JUI.css" rel="stylesheet" />
<link href="<?php echo PUBLIC_URL;?>css/jquery.notyfy.css" rel="stylesheet" />
<link href="<?php echo PUBLIC_URL;?>css/style-light.css" rel="stylesheet" type="text/css" />